<?php
// Kiswahili strings. Missing keys fall back to English automatically.
return [
    'nav.home' => 'Nyumbani', 'nav.about' => 'Kuhusu', 'nav.how' => 'Jinsi inavyofanya kazi', 'nav.eligibility' => 'Vigezo',
    'nav.period' => 'Kipindi cha maombi', 'nav.announcements' => 'Matangazo', 'nav.transparency' => 'Uwazi',
    'nav.contact' => 'Wasiliana nasi', 'nav.concern' => 'Ripoti tatizo', 'nav.login' => 'Ingia au omba',
    'home.title' => 'Omba basari kwa simu yako. Ona kila shilingi inavyotumika.',
    'home.lead' => 'Familia za Kitui West zinaomba mtandaoni, zinafuatilia kila hatua na kupokea SMS shule inapolipwa. Hakuna fomu za kununua, hakuna foleni, hakuna madalali.',
    'home.apply' => 'Anza maombi', 'home.track' => 'Ingia kufuatilia',
];
