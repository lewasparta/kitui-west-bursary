<?php
// English strings. Add a key here, then translate it in sw.php.
return [
    'nav.home' => 'Home', 'nav.about' => 'About', 'nav.how' => 'How it works', 'nav.eligibility' => 'Eligibility',
    'nav.period' => 'Application period', 'nav.announcements' => 'Announcements', 'nav.transparency' => 'Transparency',
    'nav.contact' => 'Contact', 'nav.concern' => 'Report a concern', 'nav.login' => 'Log in or apply',
    'home.title' => 'Apply for a bursary from your phone. See where every shilling goes.',
    'home.lead' => 'Kitui West families apply online, track each step and receive an SMS when the institution is paid. No forms to buy, no queues, no middlemen.',
    'home.apply' => 'Start an application', 'home.track' => 'Log in to track',
];
