#!/usr/bin/env bash
# Daily encrypted backup of the database (and local documents, if STORAGE_DRIVER=local).
# Cron (02:30 daily):  30 2 * * * /var/www/kwb/scripts/backup.sh >> /var/www/kwb/storage/logs/backup.log 2>&1
# Requires: mysqldump, gzip, openssl. Set BACKUP_PASSPHRASE_FILE to a root-only file holding the passphrase.
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
set -a; source "$APP_DIR/.env"; set +a
DEST="${BACKUP_DIR:-$APP_DIR/storage/backups}"
PASSFILE="${BACKUP_PASSPHRASE_FILE:-/etc/kwb-backup.pass}"
KEEP_DAYS="${BACKUP_KEEP_DAYS:-30}"
STAMP="$(date +%Y%m%d-%H%M%S)"
mkdir -p "$DEST"; chmod 700 "$DEST"
[ -r "$PASSFILE" ] || { echo "Missing passphrase file $PASSFILE"; exit 1; }

# --single-transaction gives a consistent snapshot without locking the live system;
# --routines/--triggers keep the append-only and sealed-document protections.
# MySQL 8 needs --set-gtid-purged=OFF; MariaDB (XAMPP) does not know that option.
GTID=""; mysqldump --help 2>/dev/null | grep -q "set-gtid-purged" && GTID="--set-gtid-purged=OFF"
MYSQL_PWD="$DB_PASSWORD" mysqldump -h "$DB_HOST" -P "${DB_PORT:-3306}" -u "$DB_USERNAME" \
  --single-transaction --no-tablespaces --routines --triggers --hex-blob $GTID "$DB_DATABASE" \
  | sed -E 's/DEFINER=`[^`]+`@`[^`]+`//g' \
  | gzip -9 | openssl enc -aes-256-cbc -pbkdf2 -salt -pass "file:$PASSFILE" -out "$DEST/db-$STAMP.sql.gz.enc"

if [ "${STORAGE_DRIVER:-local}" = "local" ]; then
  SRC="${STORAGE_LOCAL_PATH:-$APP_DIR/storage/private}"
  tar -C "$SRC" -czf - . | openssl enc -aes-256-cbc -pbkdf2 -salt -pass "file:$PASSFILE" -out "$DEST/files-$STAMP.tar.gz.enc"
fi
sha256sum "$DEST"/*-"$STAMP".* > "$DEST/SHA256-$STAMP.txt"

# Copy off the server (strongly recommended). Example with rclone to a separate bucket/account:
if [ -n "${BACKUP_RCLONE_REMOTE:-}" ]; then
  rclone copy "$DEST" "$BACKUP_RCLONE_REMOTE" --include "*-$STAMP*"
fi
find "$DEST" -type f -mtime +"$KEEP_DAYS" -delete
echo "$(date -Is) backup $STAMP complete"
