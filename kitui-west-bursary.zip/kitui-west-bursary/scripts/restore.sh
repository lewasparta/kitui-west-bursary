#!/usr/bin/env bash
# Restore a backup made by backup.sh.
#   scripts/restore.sh storage/backups/db-20261001-023000.sql.gz.enc [storage/backups/files-20261001-023000.tar.gz.enc]
# Restores into the database named in .env. Take the site offline first (maintenance page).
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
set -a; source "$APP_DIR/.env"; set +a
PASSFILE="${BACKUP_PASSPHRASE_FILE:-/etc/kwb-backup.pass}"
DB_FILE="${1:?Give the db-*.sql.gz.enc file}"
FILES_FILE="${2:-}"
read -r -p "This REPLACES database '$DB_DATABASE'. Type RESTORE to continue: " ok
[ "$ok" = "RESTORE" ] || exit 1
openssl enc -d -aes-256-cbc -pbkdf2 -pass "file:$PASSFILE" -in "$DB_FILE" | gunzip \
  | MYSQL_PWD="$DB_PASSWORD" mysql -h "$DB_HOST" -P "${DB_PORT:-3306}" -u "$DB_USERNAME" "$DB_DATABASE"
if [ -n "$FILES_FILE" ]; then
  DEST="${STORAGE_LOCAL_PATH:-$APP_DIR/storage/private}"
  mkdir -p "$DEST"
  openssl enc -d -aes-256-cbc -pbkdf2 -pass "file:$PASSFILE" -in "$FILES_FILE" | tar -C "$DEST" -xzf -
fi
php "$APP_DIR/scripts/verify-audit.php"
echo "Restore complete. The audit chain check above must say INTACT."
