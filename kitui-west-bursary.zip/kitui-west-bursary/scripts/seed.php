<?php
/**
 * Demo / starter data for Kitui West Digital Bursary.
 *   php scripts/seed.php            -> wards, institutions, an open cycle, FAQs, mentorship, demo staff
 *   php scripts/seed.php --no-demo  -> everything except demo users (use for production; then create
 *                                      the first administrator with scripts/create-admin.php)
 * Safe to run once on an empty database created from database/schema.sql.
 */
declare(strict_types=1);
require dirname(__DIR__) . '/app/bootstrap.php';

if (PHP_SAPI !== 'cli') {
    exit('CLI only');
}
if (DB::val('SELECT COUNT(*) FROM wards') > 0) {
    fwrite(STDERR, "Database already has wards; seed skipped.\n");
    exit(1);
}
$demo = !in_array('--no-demo', $argv, true);

Installer::seed($demo);
Installer::markInstalled();
echo "Seed complete" . ($demo ? " (demo accounts, password Demo@2026pass)" : '') . ".\n";
