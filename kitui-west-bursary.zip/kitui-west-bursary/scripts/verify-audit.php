<?php
/** Check the hash-chained audit trail (run after restores, or daily from cron). Exit code 1 if broken. */
declare(strict_types=1);
require dirname(__DIR__) . '/app/bootstrap.php';
[$ok, $n, $broken] = Audit::verify();
echo $ok ? "Audit trail INTACT ($n entries checked).\n" : "Audit trail BROKEN" . ($broken ? " at entry $broken" : ' (tip mismatch)') . " after $n good entries.\n";
exit($ok ? 0 : 1);
