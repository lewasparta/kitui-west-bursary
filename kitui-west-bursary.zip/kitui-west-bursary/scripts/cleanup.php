<?php
/** Hourly cron: remove abandoned upload chunks, expired reset codes and old rate-limit rows. */
declare(strict_types=1);
require dirname(__DIR__) . '/app/bootstrap.php';
$dir = BASE_PATH . '/storage/uploads';
$n = 0;
foreach (DB::all('SELECT token FROM upload_sessions WHERE created_at < NOW() - INTERVAL 2 DAY') as $s) {
    @unlink("$dir/{$s['token']}.part");
    $n++;
}
DB::run('DELETE FROM upload_sessions WHERE created_at < NOW() - INTERVAL 2 DAY');
foreach (glob("$dir/*.part") ?: [] as $f) {
    if (filemtime($f) < time() - 3 * 86400) {
        @unlink($f);
    }
}
DB::run('DELETE FROM password_resets WHERE expires_at < NOW() - INTERVAL 1 DAY');
DB::run('DELETE FROM rate_limits WHERE window_start < ?', [time() - 86400]);
echo "Cleanup done ($n stale uploads).\n";
