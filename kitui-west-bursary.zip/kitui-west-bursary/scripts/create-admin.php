<?php
/** Create the first administrator: php scripts/create-admin.php "Full Name" 07XXXXXXXX */
declare(strict_types=1);
require dirname(__DIR__) . '/app/bootstrap.php';
if (PHP_SAPI !== 'cli' || $argc < 3) {
    exit("Usage: php scripts/create-admin.php \"Full Name\" 07XXXXXXXX\n");
}
$phone = normalize_phone($argv[2]);
if (DB::val('SELECT 1 FROM users WHERE phone = ?', [$phone])) {
    exit("A user with that phone already exists.\n");
}
$temp = 'Kw-' . bin2hex(random_bytes(5)) . random_int(10, 99);
$id = DB::insert('users', ['full_name' => $argv[1], 'phone' => $phone, 'password_hash' => Auth::hashPassword($temp), 'account_type' => 'staff', 'must_change_password' => 1]);
DB::run("INSERT INTO user_roles (user_id, role_id) SELECT ?, id FROM roles WHERE slug = 'admin'", [$id]);
Audit::log('config', 'admin_created_cli', 'user', $id, [], null);
echo "Administrator created. Temporary password: $temp\nOn first login you must change it and set up two-step login.\n";
