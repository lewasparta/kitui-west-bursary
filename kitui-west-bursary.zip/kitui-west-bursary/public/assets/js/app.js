/* Kitui West Bursary — small, dependency-free enhancements. Everything works as plain forms;
   JavaScript only adds autosave, resumable uploads, QR drawing and conveniences. */
(function () {
  'use strict';

  function csrf() {
    var m = document.querySelector('meta[name="csrf-token"]');
    return m ? m.getAttribute('content') : '';
  }

  var BASE = (function () { var m = document.querySelector('meta[name="app-base"]'); return m ? m.getAttribute('content') : ''; })();

  function post(url, data) {
    if (url.charAt(0) === '/' && BASE && url.indexOf(BASE + '/') !== 0) { url = BASE + url; }
    var body = data instanceof FormData ? data : (function () { var f = new FormData(); Object.keys(data).forEach(function (k) { f.append(k, data[k]); }); return f; })();
    return fetch(url, { method: 'POST', body: body, credentials: 'same-origin', headers: { 'X-CSRF-Token': csrf(), 'Accept': 'application/json' } })
      .then(function (r) { return r.json().catch(function () { return { ok: false, error: 'Unexpected response (' + r.status + ').' }; }).then(function (j) { j._status = r.status; return j; }); });
  }

  /* ---------- QR codes (sheets, 2FA) ---------- */
  function drawQr() {
    if (typeof window.qrcode !== 'function') { return; }
    document.querySelectorAll('[data-qr]').forEach(function (el) {
      if (el.dataset.drawn) { return; }
      try {
        var q = window.qrcode(0, 'M');
        q.addData(el.getAttribute('data-qr'));
        q.make();
        el.innerHTML = q.createSvgTag({ cellSize: 4, margin: 2, scalable: true });
        el.dataset.drawn = '1';
      } catch (e) { el.textContent = el.getAttribute('data-qr'); }
    });
  }

  /* ---------- Confirm prompts ---------- */
  document.addEventListener('submit', function (ev) {
    var f = ev.target;
    var msg = f.getAttribute('data-confirm');
    if (msg && !window.confirm(msg)) { ev.preventDefault(); return; }
    var btn = ev.submitter || f.querySelector('button[type="submit"], button:not([type])');
    if (btn && !btn.disabled) {
      setTimeout(function () { btn.disabled = true; btn.classList.add('busy'); }, 0);
      setTimeout(function () { btn.disabled = false; btn.classList.remove('busy'); }, 15000);
    }
  });

  /* ---------- Print ---------- */
  document.addEventListener('click', function (ev) {
    var p = ev.target.closest('[data-print]');
    if (p) { ev.preventDefault(); window.print(); }
  });

  /* ---------- Select-all checkboxes ---------- */
  document.querySelectorAll('[data-check-all]').forEach(function (all) {
    all.addEventListener('change', function () {
      var table = all.closest('table');
      table.querySelectorAll('tbody input[type="checkbox"]').forEach(function (c) { c.checked = all.checked; });
    });
  });

  /* ---------- Institution list filtered by level ---------- */
  document.querySelectorAll('[data-filter-target]').forEach(function (sel) {
    var target = document.getElementById(sel.getAttribute('data-filter-target'));
    if (!target) { return; }
    function apply() {
      var lvl = sel.value;
      Array.prototype.forEach.call(target.options, function (o) {
        if (!o.value) { return; }
        var show = !lvl || o.getAttribute('data-level') === lvl;
        o.hidden = !show; o.disabled = !show;
      });
      if (target.selectedOptions[0] && target.selectedOptions[0].disabled) { target.value = ''; }
    }
    sel.addEventListener('change', apply);
    apply();
  });

  /* ---------- Autosave wizard drafts ---------- */
  document.querySelectorAll('form[data-autosave]').forEach(function (form) {
    var status = form.querySelector('.autosave');
    var timer = null, dirty = false, inflight = false;
    function save() {
      if (!dirty || inflight) { return; }
      dirty = false; inflight = true;
      var fd = new FormData(form);
      fd.set('step', form.getAttribute('data-step'));
      if (status) { status.textContent = 'Saving…'; }
      post(form.getAttribute('data-autosave'), fd).then(function (j) {
        inflight = false;
        if (status) { status.textContent = j.ok ? 'Draft saved at ' + j.saved_at : 'Not saved yet — your connection may be slow.'; }
        if (!j.ok) { dirty = true; }
      }).catch(function () {
        inflight = false; dirty = true;
        if (status) { status.textContent = 'Offline — we will save when you are back online.'; }
      });
    }
    form.addEventListener('input', function () { dirty = true; clearTimeout(timer); timer = setTimeout(save, 1500); });
    form.addEventListener('change', function () { dirty = true; clearTimeout(timer); timer = setTimeout(save, 600); });
    window.addEventListener('online', save);
    document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') { save(); } });
  });

  /* ---------- Resumable chunked uploads ---------- */
  var CHUNK = 512 * 1024;

  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function withRetry(fn, tries) {
    return fn().then(function (j) {
      if (!j.ok && j._status >= 500 && tries > 0) { return sleep(2000).then(function () { return withRetry(fn, tries - 1); }); }
      return j;
    }).catch(function (e) {
      if (tries > 0) { return sleep(3000).then(function () { return withRetry(fn, tries - 1); }); }
      throw e;
    });
  }

  function upload(box, file) {
    var bar = box.querySelector('.progress i');
    var msg = box.querySelector('.upload-msg');
    var max = parseInt(box.getAttribute('data-max'), 10) || 8388608;
    var okTypes = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];
    function say(t, bad) { msg.textContent = t; msg.classList.toggle('field-error', !!bad); }
    if (file.type && okTypes.indexOf(file.type) === -1) { say('Please choose a photo (JPG, PNG, WebP) or a PDF.', true); return; }
    if (file.size > max) { say('This file is too large. The limit is ' + Math.round(max / 1048576) + ' MB.', true); return; }
    box.classList.add('uploading');
    say('Starting upload…');
    var token, offset;
    withRetry(function () {
      return post('/upload/start', { application_id: box.getAttribute('data-app'), document_type_id: box.getAttribute('data-type'), file_name: file.name, size: file.size });
    }, 3).then(function (j) {
      if (!j.ok) { throw new Error(j.error || 'Could not start the upload.'); }
      token = j.token; offset = j.received;
      function next() {
        bar.style.width = Math.round(offset / file.size * 100) + '%';
        if (offset >= file.size) { return Promise.resolve(); }
        say('Uploading… ' + Math.round(offset / file.size * 100) + '%');
        var fd = new FormData();
        fd.append('token', token);
        fd.append('offset', offset);
        fd.append('chunk', file.slice(offset, Math.min(offset + CHUNK, file.size)), 'chunk');
        return withRetry(function () { return post('/upload/chunk', fd); }, 5).then(function (r) {
          if (!r.ok) { throw new Error(r.error || 'Upload interrupted.'); }
          offset = r.received;
          return next();
        });
      }
      return next();
    }).then(function () {
      say('Checking the file…');
      return withRetry(function () { return post('/upload/finish', { token: token }); }, 3);
    }).then(function (j) {
      if (!j.ok) { throw new Error(j.error || 'The file could not be saved.'); }
      bar.style.width = '100%';
      box.classList.remove('uploading');
      box.classList.add('ok');
      say('Uploaded ✓ — refreshing…');
      setTimeout(function () { window.location.reload(); }, 700);
    }).catch(function (e) {
      box.classList.remove('uploading');
      say((e && e.message ? e.message : 'Upload failed.') + ' Choose the same file again to continue where it stopped.', true);
    });
  }

  document.querySelectorAll('[data-upload]').forEach(function (box) {
    var input = box.querySelector('input[type="file"]');
    if (!input) { return; }
    input.addEventListener('change', function () { if (input.files && input.files[0]) { upload(box, input.files[0]); input.value = ''; } });
  });

  /* ---------- GPS for field visits ---------- */
  document.querySelectorAll('[data-geolocate]').forEach(function (btn) {
    var form = btn.closest('form');
    var status = form.querySelector('[data-gps-status]');
    btn.addEventListener('click', function () {
      if (!navigator.geolocation) { status.textContent = 'Location is not available on this device.'; return; }
      status.textContent = 'Getting location…';
      navigator.geolocation.getCurrentPosition(function (p) {
        form.querySelector('[data-gps="lat"]').value = p.coords.latitude.toFixed(6);
        form.querySelector('[data-gps="lng"]').value = p.coords.longitude.toFixed(6);
        status.textContent = 'Saved: ' + p.coords.latitude.toFixed(5) + ', ' + p.coords.longitude.toFixed(5) + ' (±' + Math.round(p.coords.accuracy) + ' m)';
      }, function () { status.textContent = 'Could not get location. You can still record the visit.'; }, { enableHighAccuracy: true, timeout: 20000 });
    });
  });

  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', drawQr); } else { drawQr(); }
  window.addEventListener('load', drawQr);
})();
