<?php
declare(strict_types=1);

// PHP built-in server (development): let it serve real static files directly.
if (PHP_SAPI === 'cli-server' && is_file(__DIR__ . parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH))) {
    return false;
}

require dirname(__DIR__) . '/app/bootstrap.php';

// First run: until the one-click installer has finished, every page shows it.
if (!Installer::installed() && !Installer::adoptExisting()) {
    require APP_PATH . '/controllers/install.php';
    install_handle();
}
Installer::migrate(); // upgrades older databases automatically (no manual SQL needed)

$routes = [
    // Public website
    ['GET', '/', 'public@home'],
    ['GET', '/about', 'public@about'],
    ['GET', '/how-it-works', 'public@how'],
    ['GET', '/eligibility', 'public@eligibility'],
    ['GET', '/application-period', 'public@period'],
    ['GET', '/faqs', 'public@faqs'],
    ['GET', '/announcements', 'public@announcements'],
    ['GET', '/announcements/{id}', 'public@announcement'],
    ['GET', '/contact', 'public@contact'],
    ['GET', '/transparency', 'public@transparency'],
    ['GET', '/verify', 'public@verify'],
    ['GET', '/report-concern', 'concern@form'],
    ['POST', '/report-concern', 'concern@submit'],
    ['GET', '/report-concern/track', 'concern@track'],
    ['POST', '/report-concern/track', 'concern@trackPost'],
    ['GET', '/lang/{code}', 'public@lang'],

    // Accounts
    ['GET', '/login', 'auth@loginForm'],
    ['POST', '/login', 'auth@login'],
    ['POST', '/logout', 'auth@logout'],
    ['GET', '/register', 'auth@registerForm'],
    ['POST', '/register', 'auth@register'],
    ['GET', '/register/verify', 'auth@verifyPhoneForm'],
    ['POST', '/register/verify', 'auth@verifyPhone'],
    ['POST', '/register/resend', 'auth@resendCode'],
    ['GET', '/privacy', 'public@privacy'],
    ['GET', '/2fa', 'auth@twofaForm'],
    ['POST', '/2fa', 'auth@twofa'],
    ['GET', '/forgot-password', 'auth@forgotForm'],
    ['POST', '/forgot-password', 'auth@forgot'],
    ['GET', '/reset-password', 'auth@resetForm'],
    ['POST', '/reset-password', 'auth@reset'],
    ['GET', '/account/password', 'auth@passwordForm'],
    ['POST', '/account/password', 'auth@password'],
    ['GET', '/account/2fa', 'auth@setup2faForm'],
    ['POST', '/account/2fa', 'auth@setup2fa'],

    // Parent / student portal
    ['GET', '/portal', 'applicant@dashboard'],
    ['POST', '/portal/apply', 'applicant@start'],
    ['GET', '/portal/applications/{id}', 'applicant@show'],
    ['GET', '/portal/applications/{id}/step/{step}', 'applicant@step'],
    ['POST', '/portal/applications/{id}/step/{step}', 'applicant@saveStep'],
    ['POST', '/portal/applications/{id}/autosave', 'applicant@autosave'],
    ['POST', '/portal/applications/{id}/submit', 'applicant@submit'],
    ['POST', '/portal/applications/{id}/delete-draft', 'applicant@deleteDraft'],
    ['GET', '/portal/history', 'applicant@history'],
    ['GET', '/portal/notifications', 'applicant@notifications'],
    ['GET', '/portal/profile', 'applicant@profile'],
    ['POST', '/portal/profile', 'applicant@saveProfile'],

    // Files & uploads (resumable, chunked)
    ['POST', '/upload/start', 'files@start'],
    ['POST', '/upload/chunk', 'files@chunk'],
    ['POST', '/upload/finish', 'files@finish'],
    ['GET', '/files/{id}', 'files@serve'],

    // Sealed official sheets
    ['GET', '/sheets/{kind}/{id}', 'sheets@show'],

    // Mentorship
    ['GET', '/mentorship', 'mentorship@index'],
    ['POST', '/mentorship/events/{id}/register', 'mentorship@register'],
    ['POST', '/mentorship/registrations/{id}/feedback', 'mentorship@feedback'],
    ['GET', '/staff/mentorship', 'mentorship@staffIndex'],
    ['GET', '/staff/mentorship/events/{id}', 'mentorship@attendance'],
    ['POST', '/staff/mentorship/events/{id}', 'mentorship@saveAttendance'],

    // Staff workflow
    ['GET', '/staff', 'staff@dashboard'],
    ['GET', '/staff/queue/{duty}', 'staff@queue'],
    ['GET', '/staff/committee', 'staff@committee'],
    ['GET', '/staff/search', 'staff@search'],
    ['GET', '/staff/applications/{id}', 'staff@show'],
    ['POST', '/staff/applications/{id}/coi', 'staff@coi'],
    ['POST', '/staff/applications/{id}/documents/{doc}', 'staff@reviewDocument'],
    ['POST', '/staff/applications/{id}/doc-check', 'staff@docCheck'],
    ['POST', '/staff/applications/{id}/verify', 'staff@verify'],
    ['POST', '/staff/applications/{id}/field-visit', 'staff@fieldVisit'],
    ['POST', '/staff/applications/{id}/committee', 'staff@committeeReview'],
    ['POST', '/staff/applications/{id}/approve', 'staff@approve'],
    ['POST', '/staff/applications/{id}/amend', 'staff@amend'],
    ['POST', '/staff/amendments/{id}', 'staff@reviewAmendment'],
    ['POST', '/staff/applications/{id}/flags/{flag}', 'staff@resolveFlag'],
    ['POST', '/staff/applications/{id}/audit-sample', 'staff@auditSample'],

    // Finance
    ['GET', '/finance', 'finance@index'],
    ['POST', '/finance/queue', 'finance@queue'],
    ['POST', '/finance/batches', 'finance@createBatch'],
    ['GET', '/finance/batches/{id}', 'finance@batch'],
    ['POST', '/finance/batches/{id}/authorize', 'finance@authorize'],
    ['POST', '/finance/batches/{id}/cancel', 'finance@cancel'],
    ['POST', '/finance/payments/{id}/record', 'finance@record'],
    ['POST', '/finance/payments/{id}/requeue', 'finance@requeue'],
    ['POST', '/finance/payments/{id}/reconcile', 'finance@reconcile'],

    // Audit & reports
    ['GET', '/audit', 'audit@index'],
    ['GET', '/audit/logs', 'audit@logs'],
    ['GET', '/audit/applications/{id}', 'audit@application'],
    ['GET', '/audit/concerns', 'audit@concerns'],
    ['GET', '/audit/concerns/{id}', 'audit@concern'],
    ['POST', '/audit/concerns/{id}', 'audit@updateConcern'],
    ['GET', '/reports', 'reports@index'],
    ['GET', '/reports/{name}', 'reports@download'],

    // Administration
    ['GET', '/admin', 'admin@index'],
    ['GET', '/admin/users', 'admin@users'],
    ['GET', '/admin/users/new', 'admin@userForm'],
    ['GET', '/admin/users/{id}', 'admin@userForm'],
    ['POST', '/admin/users/save', 'admin@saveUser'],
    ['GET', '/admin/settings', 'admin@settings'],
    ['GET', '/admin/security', 'admin@security'],
    ['POST', '/admin/settings', 'admin@saveSettings'],
    ['GET', '/admin/sms', 'admin@smsLog'],
    ['GET', '/admin/r/{res}', 'admin@list'],
    ['GET', '/admin/r/{res}/new', 'admin@form'],
    ['GET', '/admin/r/{res}/{id}', 'admin@form'],
    ['POST', '/admin/r/{res}/save', 'admin@save'],
];

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$path = rawurldecode(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/');
if (BASE_URL !== '' && str_starts_with($path, BASE_URL)) {
    $path = substr($path, strlen(BASE_URL)) ?: '/';
}
if (BASE_URL !== '' && str_starts_with($path, '/public/')) {
    $path = substr($path, 7); // tolerate /folder/public/... links
}
$path = $path !== '/' ? rtrim($path, '/') : '/';

if ($method === 'POST') {
    csrf_check();
}

foreach ($routes as [$m, $pattern, $handler]) {
    if ($m !== $method) {
        continue;
    }
    $regex = '#^' . preg_replace('#\{[a-z]+\}#', '([A-Za-z0-9_\-]+)', $pattern) . '$#';
    if (preg_match($regex, $path, $mm)) {
        array_shift($mm);
        [$file, $fn] = explode('@', $handler);
        require_once APP_PATH . '/controllers/' . $file . '.php';
        $fn = $file . '_' . $fn;
        $fn(...$mm);
        exit;
    }
}
abort(404);
