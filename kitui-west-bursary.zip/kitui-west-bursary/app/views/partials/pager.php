<?php if ($p['pages'] > 1): $q = $_GET; ?>
<nav class="pager" aria-label="Pages">
  <?php if ($p['page'] > 1): $q['page'] = $p['page'] - 1; ?><a href="?<?= e(http_build_query($q)) ?>" aria-label="Previous page">‹</a><?php endif; ?>
  <span class="cur"><?= $p['page'] ?></span><span class="muted">of <?= $p['pages'] ?></span>
  <?php if ($p['page'] < $p['pages']): $q['page'] = $p['page'] + 1; ?><a href="?<?= e(http_build_query($q)) ?>" aria-label="Next page">›</a><?php endif; ?>
</nav>
<?php endif; ?>
