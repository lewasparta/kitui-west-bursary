<?php $tabs = ['pending' => 'Awaiting committee', 'recommended' => 'Awaiting approval', 'decided' => 'Decided']; ?>
<h1>Committee dashboard</h1>
<p class="muted">Requested, recommended, approved and paid amounts are kept separate. Amounts recommended by the committee must still be approved by an authorised approver.</p>
<form method="get" class="filters">
  <div class="field"><label for="cycle">Cycle</label><select id="cycle" name="cycle"><?php foreach ($cycles as $c): ?><option value="<?= (int)$c['id'] ?>"<?= selected($cycle, $c['id']) ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></div>
  <div class="field"><label for="ward">Ward</label><select id="ward" name="ward"><option value="">All wards</option><?php foreach ($wards as $w): ?><option value="<?= (int)$w['id'] ?>"<?= selected($ward, $w['id']) ?>><?= e($w['name']) ?></option><?php endforeach; ?></select></div>
  <input type="hidden" name="view" value="<?= e($view) ?>"><button class="btn btn-line">Filter</button>
</form>
<nav class="btn-row" style="margin-bottom:1rem"><?php foreach ($tabs as $k => $l): ?><a class="btn btn-sm <?= $view === $k ? '' : 'btn-quiet' ?>" href="?<?= e(http_build_query(['view' => $k, 'cycle' => $cycle, 'ward' => $ward])) ?>"><?= e($l) ?></a><?php endforeach; ?></nav>
<div class="amounts"><div><span>Requested</span><b><?= money($totals['req']) ?></b></div><div><span>Recommended</span><b><?= money($totals['rec']) ?></b></div><div><span>Approved</span><b><?= money($totals['appr']) ?></b></div><div><span>Paid</span><b><?= money($totals['paid']) ?></b></div></div>
<?php if (!$p['rows']): ?><div class="panel empty">No applications in this view.</div><?php else: ?>
<div class="table-wrap"><table class="cards">
<thead><tr><th>Applicant / student</th><th>Institution</th><th>Ward</th><th class="r">Requested</th><th class="r">Recommended</th><th class="r">Approved</th><th class="r">Previous support</th><th>Verification</th><th>Documents</th><th>Risk flags</th><th></th></tr></thead><tbody>
<?php foreach ($p['rows'] as $r): ?>
<tr>
  <td data-label="Student"><b><?= e($r['first_name'] . ' ' . $r['last_name']) ?></b><div class="small muted num"><?= e($r['reference']) ?></div></td>
  <td data-label="Institution"><?= e($r['institution_name']) ?><div class="small muted"><?= e(level_label($r['level'])) ?></div></td>
  <td data-label="Ward"><?= e($r['ward_name']) ?></td>
  <td data-label="Requested" class="r"><?= money($r['amount_requested']) ?></td>
  <td data-label="Recommended" class="r"><?= money($r['amount_recommended']) ?></td>
  <td data-label="Approved" class="r"><?= money($r['amount_approved']) ?></td>
  <td data-label="Previous support" class="r"><?= money($r['previous_support']) ?></td>
  <td data-label="Verification"><?= $r['field_outcome'] ? 'Field: ' . e(str_replace('_', ' ', $r['field_outcome'])) : ($r['field_visit_required'] ? '<span class="sev-medium">Visit pending</span>' : 'Desk verified') ?></td>
  <td data-label="Documents"><?= (int)$r['docs_ok'] ?>/<?= (int)$r['docs_all'] ?> verified</td>
  <td data-label="Risk flags" class="small"><?= $r['flags'] ? '<span class="sev-medium">' . e($r['flags']) . '</span>' : '—' ?></td>
  <td><a class="btn btn-sm" href="/staff/applications/<?= (int)$r['id'] ?>">Review</a></td>
</tr>
<?php endforeach; ?></tbody></table></div>
<?= partial('pager', ['p' => $p]) ?>
<?php endif; ?>
<?php if ($budgets): ?>
<div class="panel" style="margin-top:1.25rem"><h2>Ward budgets</h2>
<?php foreach ($budgets as $b): $pct = $b['amount'] > 0 ? min(100, round($b['committed'] / $b['amount'] * 100)) : 0; ?>
  <div class="bar-row"><span><?= e($b['name']) ?></span><div class="bar-track"><div class="bar-fill<?= $pct > 90 ? ' gold' : '' ?>" style="width:<?= $pct ?>%"></div></div><span class="small num"><?= $pct ?>% of <?= e(number_format((float)$b['amount'])) ?></span></div>
<?php endforeach; ?></div>
<?php endif; ?>
