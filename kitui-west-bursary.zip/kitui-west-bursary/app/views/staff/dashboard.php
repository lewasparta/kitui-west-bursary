<?php $names = Workflow::DUTY_NAMES; ?>
<div class="panel-head welcome"><div><p class="eyebrow eyebrow-gold">Staff workspace · <?= e(date("l j F")) ?></p><h1>Good <?= (int)date('G') < 12 ? 'morning' : ((int)date('G') < 17 ? 'afternoon' : 'evening') ?>, <?= e(explode(' ', $u['full_name'])[0]) ?></h1>
<p class="muted">Your work queues. You can only act on steps your role allows, and never on more than one step of the same application.</p></div></div>

<?php if ($noTotp): ?><div class="flash flash-info">Protect your account: <a href="/account/2fa">turn on two-step login</a> with an authenticator app.</div><?php endif; ?>

<?php if ($cards || $amend !== null || $flags !== null): ?>
<div class="stats">
  <?php foreach ($cards as $duty => $n): ?>
    <a class="stat" href="/staff/queue/<?= e($duty) ?>" style="text-decoration:none;color:inherit"><b><?= $n ?></b><span><?= e($names[$duty]) ?> waiting</span></a>
  <?php endforeach; ?>
  <?php if ($amend !== null): ?><a class="stat gold" href="#amendments" style="text-decoration:none;color:inherit"><b><?= $amend ?></b><span>Amendments to check</span></a><?php endif; ?>
  <?php if ($flags !== null): ?><div class="stat gold"><b><?= $flags ?></b><span>Open risk flags</span></div><?php endif; ?>
</div>
<?php endif; ?>

<div class="two-col">
<div>
<?php if ($stats): ?>
<div class="panel"><div class="panel-head"><h2><?= e($cycle['name']) ?></h2><span class="small muted"><?= e(ucfirst($cycle['status'])) ?> · closes <?= e(fmt_date($cycle['closes_at'])) ?></span></div>
  <div class="amounts" style="margin:0"><div><span>Submitted</span><b><?= (int)$stats['submitted'] ?></b></div><div><span>Approved</span><b><?= (int)$stats['approved'] ?></b></div><div><span>Approved amount</span><b><?= money($stats['approved_amt']) ?></b></div><div><span>Paid</span><b><?= money($stats['paid_amt']) ?></b></div></div>
</div>
<?php endif; ?>
<div class="panel"><h2>Where to start</h2>
  <div class="stack">
  <?php if (in_array('doc_officer', $roles, true)): ?><p><a class="btn btn-line" href="/staff/queue/doc_check">Check documents</a> Open each document, compare it with the details and mark it verified or rejected. School ID cards confirm enrolment.</p><?php endif; ?>
  <?php if (in_array('ward_officer', $roles, true)): ?><p><a class="btn btn-line" href="/staff/queue/verification">Verify applications</a> Confirm residence and need, resolve flags, and visit homes selected for field verification.</p><?php endif; ?>
  <?php if (in_array('committee', $roles, true)): ?><p><a class="btn btn-line" href="/staff/committee">Committee dashboard</a> Review verified applications and recommend amounts.</p><?php endif; ?>
  <?php if (in_array('approver', $roles, true)): ?><p><a class="btn btn-line" href="/staff/committee?view=recommended">Approve recommendations</a> Within your approval limit of <b><?= money($u['approval_limit']) ?></b>.</p><?php endif; ?>
  <?php if (in_array('finance', $roles, true)): ?><p><a class="btn btn-line" href="/finance">Finance</a> Queue approved awards, build batches, authorise and record payments.</p><?php endif; ?>
  <?php if (in_array('auditor', $roles, true)): ?><p><a class="btn btn-line" href="/audit">Audit</a> Audit trail integrity, reconciliation, secondary audits and concerns.</p><?php endif; ?>
  <?php if (in_array('admin', $roles, true)): ?><p><a class="btn btn-line" href="/admin">Administration</a> Users, cycles, budgets, documents and settings.</p><?php endif; ?>
  </div>
</div>
</div>
<div>
<?php if ($amendRows): ?><div class="panel panel-gold" id="amendments"><h2>Amendments to check</h2><p class="small">Requested by another approver. Open the application to confirm or reject.</p>
<ul class="timeline"><?php foreach ($amendRows as $m): ?><li><a href="/staff/applications/<?= (int)$m['application_id'] ?>#amend"><?= e($m['reference']) ?></a>: <?= money($m['old_amount']) ?> → <?= money($m['new_amount']) ?><div class="small muted">by <?= e($m['requester']) ?></div></li><?php endforeach; ?></ul></div><?php endif; ?>
<div class="panel"><h2>Your recent actions</h2>
<?php if (!$recent): ?><p class="muted">Nothing yet.</p><?php else: ?><ul class="timeline"><?php foreach ($recent as $r): ?><li><time><?= e(fmt_date($r['created_at'], 'j M, g:ia')) ?></time><a href="/staff/applications/<?= (int)$r['id'] ?>"><?= e($r['reference']) ?></a> — <?= e(str_replace('_', ' ', $r['action'])) ?></li><?php endforeach; ?></ul><?php endif; ?>
</div>
</div>
</div>
