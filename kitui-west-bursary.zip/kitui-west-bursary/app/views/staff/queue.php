<p class="crumbs"><a href="/staff">Dashboard</a> › Queue</p>
<h1><?= e($title) ?></h1>
<p class="muted"><?= (int)$p['total'] ?> application(s), oldest first.</p>
<?php if (!$p['rows']): ?><div class="panel empty">Nothing waiting. Well done.</div><?php else: ?>
<div class="table-wrap"><table class="cards">
<thead><tr><th>Reference</th><th>Student</th><th>Ward</th><th>Institution</th><th>Status</th><th class="r">Requested</th><th>Flags</th><th></th></tr></thead><tbody>
<?php foreach ($p['rows'] as $r): ?>
<tr>
  <td data-label="Reference" class="num"><?= e($r['reference']) ?><?= $r['field_visit_required'] ? ' <span class="badge badge-draft">Field visit</span>' : '' ?><?= $r['is_continuation'] ? ' <span class="badge badge-muted">Continuing</span>' : '' ?></td>
  <td data-label="Student"><?= e($r['first_name'] . ' ' . $r['last_name']) ?></td>
  <td data-label="Ward"><?= e($r['ward_name']) ?></td>
  <td data-label="Institution"><?= e($r['institution_name']) ?></td>
  <td data-label="Status"><?= status_badge($r['status']) ?></td>
  <td data-label="Requested" class="r"><?= money($r['amount_requested']) ?></td>
  <td data-label="Flags"><?= $r['open_flags'] ? '<span class="sev-high">' . (int)$r['open_flags'] . ' open</span>' : '—' ?></td>
  <td><?php if ($r['_block']): ?><span class="small muted" title="<?= e($r['_block']) ?>">Locked for you</span><?php else: ?><a class="btn btn-sm" href="/staff/applications/<?= (int)$r['id'] ?>">Open</a><?php endif; ?></td>
</tr>
<?php endforeach; ?>
</tbody></table></div>
<?= partial('pager', ['p' => $p]) ?>
<?php endif; ?>
