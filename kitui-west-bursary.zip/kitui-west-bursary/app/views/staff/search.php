<h1>Find an application</h1>
<form method="get" class="filters"><div class="field"><label for="q">Reference, student name, birth certificate / UPI or guardian phone</label><input type="search" id="q" name="q" value="<?= e($q) ?>" autofocus></div><button class="btn">Search</button></form>
<?php if ($q !== ''): ?>
  <?php if (!$rows): ?><div class="panel empty">No matching applications.</div><?php else: ?>
  <div class="table-wrap"><table class="cards"><thead><tr><th>Reference</th><th>Student</th><th>Cycle</th><th>Ward</th><th>Institution</th><th>Status</th></tr></thead><tbody>
  <?php foreach ($rows as $r): ?><tr><td data-label="Reference"><a href="/staff/applications/<?= (int)$r['id'] ?>"><?= e($r['reference']) ?></a></td><td data-label="Student"><?= e($r['first_name'] . ' ' . $r['last_name']) ?></td><td data-label="Cycle"><?= e($r['cycle_name']) ?></td><td data-label="Ward"><?= e($r['ward_name']) ?></td><td data-label="Institution"><?= e($r['institution_name']) ?></td><td data-label="Status"><?= status_badge($r['status']) ?></td></tr><?php endforeach; ?>
  </tbody></table></div><p class="small muted">Searches are recorded in the audit trail.</p><?php endif; ?>
<?php endif; ?>
