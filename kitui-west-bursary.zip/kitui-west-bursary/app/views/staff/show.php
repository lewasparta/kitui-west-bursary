<?php
$id = (int)$a['id'];
$can = fn(string $d) => array_key_exists($d, $duties) && $duties[$d] === null;
$needsCoi = in_array('coi_required', $duties, true);
$canFlags = $can('doc_check') || $can('verification') || $can('audit_sample');
$student = trim($a['first_name'] . ' ' . ($a['middle_name'] ? $a['middle_name'] . ' ' : '') . $a['last_name']);
$age = $a['date_of_birth'] ? date_diff(date_create($a['date_of_birth']), date_create())->y : null;
?>
<p class="crumbs"><a href="/staff">Dashboard</a> › <?= e($a['reference']) ?></p>
<div class="panel-head">
  <div><h1><?= e($student) ?></h1><p class="muted"><span class="num"><?= e($a['reference']) ?></span> · <?= e($a['cycle_name']) ?> · <?= e($a['ward_name']) ?> ward<?= $a['is_continuation'] ? ' · continuing student' : '' ?></p></div>
  <div class="btn-row"><?= status_badge($a['status']) ?><?php if ($a['field_visit_required']): ?><span class="badge badge-draft">Field visit selected</span><?php endif; ?><?php if ($a['secondary_audit']): ?><span class="badge badge-draft">Secondary audit sample</span><?php endif; ?></div>
</div>

<?php if ($needsCoi && !$coi): ?>
<form method="post" action="/staff/applications/<?= $id ?>/coi" class="panel panel-gold"><?= csrf_field() ?>
  <h2>Conflict of interest declaration</h2>
  <p>Before you work on this application, declare whether you know the student or family personally, are related to them, or have any interest in the outcome. Your declaration is recorded permanently.</p>
  <div class="choice-list">
    <label class="check"><input type="radio" name="has_conflict" value="0" required>I have no conflict of interest with this student, family or institution.</label>
    <label class="check"><input type="radio" name="has_conflict" value="1">I have a conflict of interest (I will not handle this application).</label>
  </div><p></p>
  <div class="field"><label for="coi-d">Details if you have a conflict</label><input type="text" id="coi-d" name="details" maxlength="255"></div>
  <button class="btn">Record declaration</button>
</form>
<?php endif; ?>

<?php $blocked = array_filter($duties, fn($r) => $r !== null && $r !== 'coi_required'); if ($blocked): ?>
<details class="faq"><summary>Why some actions are not available to you (<?= count($blocked) ?>)</summary><div><ul><?php foreach ($blocked as $d => $r): ?><li><b><?= e(Workflow::DUTY_NAMES[$d]) ?>:</b> <?= e($r) ?></li><?php endforeach; ?></ul></div></details>
<?php endif; ?>

<div class="amounts"><div><span>Requested</span><b><?= money($a['amount_requested']) ?></b></div><div><span>Recommended</span><b><?= money($a['amount_recommended']) ?></b></div><div><span>Approved</span><b><?= money($a['amount_approved']) ?></b></div><div><span>Paid</span><b><?= money($a['amount_paid']) ?></b></div></div>

<div class="two-col">
<div>
  <div class="panel"><h2>Application details</h2>
    <div class="grid-2">
      <dl class="facts"><dt>Student</dt><dd><?= e($student) ?></dd><dt>Gender / age</dt><dd><?= e(ucfirst((string)$a['gender'])) ?>, <?= e((string)$age) ?> yrs (<?= e(fmt_date($a['date_of_birth'])) ?>)</dd><dt>Birth cert.</dt><dd><?= e($a['birth_cert_no'] ?: '—') ?></dd><dt>UPI / NEMIS</dt><dd><?= e($a['upi_no'] ?: '—') ?></dd><dt>Home</dt><dd><?= e($a['village'] . ', ' . $a['sub_location'] . ', ' . $a['ward_name']) ?></dd><dt>Disability</dt><dd><?= $a['has_disability'] ? 'Yes' : 'No' ?></dd></dl>
      <dl class="facts"><dt>Guardian</dt><dd><?= e($a['guardian_name']) ?> (<?= e($a['guardian_relationship']) ?>)</dd><dt>Guardian phone</dt><dd><?= e($a['guardian_phone']) ?></dd><dt>Guardian ID</dt><dd><?= e($a['guardian_nid']) ?></dd><dt>Occupation</dt><dd><?= e($a['guardian_occupation'] ?: '—') ?></dd><dt>Applied by</dt><dd><?= e($a['applicant_name']) ?>, <?= e($a['applicant_phone']) ?></dd></dl>
      <dl class="facts"><dt>Institution</dt><dd><?= e($a['institution_name']) ?></dd><dt>Level / class</dt><dd><?= e(level_label($a['level'])) ?>, <?= e($a['class_year']) ?></dd><dt>Admission no.</dt><dd><?= e($a['admission_no']) ?></dd><dt>Annual fees</dt><dd><?= money($a['annual_fees']) ?></dd><dt>Fee balance</dt><dd><?= money($a['fee_balance']) ?></dd></dl>
      <dl class="facts"><dt>Parents</dt><dd><?= e(str_replace('_', ' ', (string)$a['parental_status'])) ?></dd><dt>Household</dt><dd><?= (int)$a['household_size'] ?> people, <?= (int)$a['siblings_in_school'] ?> others in school</dd><dt>Income</dt><dd><?= e(str_replace('_', ' ', (string)$a['income_band'])) ?></dd><dt>Submitted</dt><dd><?= e(fmt_date($a['submitted_at'], 'j M Y, g:ia')) ?></dd></dl>
    </div>
    <?php if ($a['special_circumstances']): ?><p style="margin-top:1rem"><b>Circumstances:</b> <?= nl2br(e($a['special_circumstances'])) ?></p><?php endif; ?>
    <p class="btn-row" style="margin-top:1rem"><a class="btn btn-sm btn-quiet" href="/sheets/application_receipt/<?= $id ?>">Receipt</a>
      <?php if ((float)$a['amount_approved'] > 0): ?><a class="btn btn-sm btn-quiet" href="/sheets/award_letter/<?= $id ?>">Award letter</a><?php endif; ?>
      <?php if (Auth::has('auditor')): ?><a class="btn btn-sm btn-quiet" href="/audit/applications/<?= $id ?>">Full audit reconstruction</a><?php endif; ?></p>
  </div>

  <div class="panel" id="documents"><div class="panel-head"><h2>Documents</h2><span class="small muted">Every view is logged</span></div>
    <p class="small muted">Check each document by eye against the details above. Automated text reading is not used to reject anyone — your judgement decides. A school ID showing the current year is strong evidence of enrolment.</p>
    <?php $have = array_column($docs, 'document_type_id'); foreach ($required as $r): if (!in_array($r['id'], $have)): ?><div class="flash flash-error">Missing required document: <?= e($r['name']) ?></div><?php endif; endforeach; ?>
    <?php foreach ($docs as $d): ?>
      <div class="upload-item<?= $d['status'] === 'verified' ? ' ok' : '' ?>" id="doc-<?= (int)$d['id'] ?>">
        <div class="meta"><b><?= e($d['type_name']) ?></b><?= status_badge($d['status'] === 'pending' ? 'submitted' : $d['status']) ?></div>
        <?php if (str_starts_with($d['mime'], 'image/')): ?><a href="/files/<?= (int)$d['id'] ?>" target="_blank" rel="noopener"><img class="doc-thumb" src="/files/<?= (int)$d['id'] ?>" alt="<?= e($d['type_name']) ?>" loading="lazy"></a>
        <?php else: ?><p><a class="btn btn-sm btn-line" href="/files/<?= (int)$d['id'] ?>" target="_blank" rel="noopener">Open PDF</a></p><?php endif; ?>
        <div class="small muted"><?= e($d['original_name']) ?> · <?= e(number_format($d['size_bytes'] / 1024)) ?> KB · uploaded <?= e(fmt_date($d['created_at'], 'j M, g:ia')) ?><?= $d['verifier'] ? ' · checked by ' . e($d['verifier']) : '' ?><?= $d['rejection_reason'] ? ' · ' . e($d['rejection_reason']) : '' ?></div>
        <?php if ($can('doc_check') && !$d['staff_only']): ?>
        <form method="post" action="/staff/applications/<?= $id ?>/documents/<?= (int)$d['id'] ?>" class="btn-row" style="margin-top:.6rem"><?= csrf_field() ?>
          <input type="text" name="reason" placeholder="Reason if rejecting (applicant sees this)" maxlength="255" style="flex:1;min-width:200px">
          <button class="btn btn-sm" name="decision" value="verified">Verify</button><button class="btn btn-sm btn-danger" name="decision" value="rejected">Reject</button>
        </form>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
    <?php if (!$docs): ?><p class="muted">No documents.</p><?php endif; ?>
  </div>

  <div class="panel" id="field"><h2>Field verification</h2>
    <?php foreach ($visits as $v): ?>
      <div class="upload-item ok"><div class="meta"><b><?= e(fmt_date($v['visit_date'])) ?> — <?= e($v['officer']) ?></b><?= status_badge($v['outcome'] === 'confirmed' ? 'confirmed' : ($v['outcome'] === 'not_confirmed' ? 'failed' : 'submitted')) ?></div>
      <p class="small"><b>Household:</b> <?= e($v['household_observation']) ?><br><b>Findings:</b> <?= e($v['findings']) ?><?= $v['gps_lat'] ? '<br><b>GPS:</b> ' . e($v['gps_lat'] . ', ' . $v['gps_lng']) : '' ?></p></div>
    <?php endforeach; ?>
    <?php if (!$visits): ?><p class="muted"><?= $a['field_visit_required'] ? 'Selected for a field visit; none recorded yet.' : 'No field visit required so far.' ?></p><?php endif; ?>
    <?php if ($can('verification') && $a['status'] === 'field_verification'):
      $photoType = (int)DB::val("SELECT id FROM document_types WHERE code = 'homestead_photo'");
      $pending = (int)DB::val('SELECT COUNT(*) FROM documents WHERE application_id = ? AND document_type_id = ? AND field_visit_id IS NULL AND uploaded_by = ?', [$id, $photoType, Auth::id()]); ?>
      <div class="upload-item" data-upload data-app="<?= $id ?>" data-type="<?= $photoType ?>" data-max="<?= (int)setting('max_upload_mb', '8') * 1048576 ?>">
        <div class="meta"><b>Homestead photos</b><label class="btn btn-sm btn-line file-btn">Take / add photo<input type="file" accept="image/jpeg,image/png,image/webp" capture="environment"></label></div>
        <div class="small muted"><?= $pending ?> photo(s) ready to attach to this visit. Photos are stored privately and never published.</div>
        <div class="progress"><i></i></div><div class="small upload-msg" aria-live="polite"></div>
      </div>
      <form method="post" action="/staff/applications/<?= $id ?>/field-visit"><?= csrf_field() ?>
        <div class="grid-2"><div class="field"><label for="vd">Visit date</label><input type="date" id="vd" name="visit_date" value="<?= date('Y-m-d') ?>" max="<?= date('Y-m-d') ?>" required></div>
        <div class="field"><label for="oc">Outcome</label><select id="oc" name="outcome" required><option value="confirmed">Details confirmed</option><option value="concerns">Confirmed with concerns</option><option value="not_confirmed">Could not confirm</option></select></div></div>
        <div class="field"><label for="ho">What you observed at the home</label><textarea id="ho" name="household_observation" required minlength="10"></textarea></div>
        <div class="field"><label for="fi">Findings and who you spoke to</label><textarea id="fi" name="findings" required minlength="10"></textarea></div>
        <input type="hidden" name="gps_lat" data-gps="lat"><input type="hidden" name="gps_lng" data-gps="lng">
        <div class="btn-row"><button type="button" class="btn btn-sm btn-quiet" data-geolocate>Add my GPS location</button><span class="small muted" data-gps-status></span></div><p></p>
        <button class="btn">Record field visit</button>
      </form>
    <?php endif; ?>
  </div>

  <?php if ($reviews || $approvals || $amendments): ?>
  <div class="panel" id="amend"><h2>Committee and approval</h2>
    <ul class="timeline">
      <?php foreach ($reviews as $r): ?><li><time><?= e(fmt_date($r['created_at'], 'j M Y, g:ia')) ?></time><b>Committee — <?= e($r['member']) ?>:</b> <?= e(str_replace('_', ' ', $r['decision'])) ?><?= $r['recommended_amount'] !== null ? ' ' . money($r['recommended_amount']) : '' ?><?= $r['need_score'] ? ' · need score ' . (int)$r['need_score'] . '/10' : '' ?><div class="small"><?= e($r['comment']) ?></div></li><?php endforeach; ?>
      <?php foreach ($approvals as $r): ?><li><time><?= e(fmt_date($r['created_at'], 'j M Y, g:ia')) ?></time><b>Approver — <?= e($r['approver']) ?>:</b> <?= e(status_label($r['decision'])) ?> <?= money($r['amount']) ?><?= $r['comment'] ? '<div class="small">' . e($r['comment']) . '</div>' : '' ?></li><?php endforeach; ?>
      <?php foreach ($amendments as $m): ?><li><time><?= e(fmt_date($m['created_at'], 'j M Y, g:ia')) ?></time><b>Amendment by <?= e($m['requester']) ?>:</b> <?= money($m['old_amount']) ?> → <?= money($m['new_amount']) ?> <?= status_badge($m['status']) ?><div class="small"><?= e($m['reason']) ?><?= $m['reviewer'] ? ' · reviewed by ' . e($m['reviewer']) . ($m['review_note'] ? ': ' . e($m['review_note']) : '') : '' ?></div>
        <?php if ($m['status'] === 'pending' && $can('approval') && (int)$m['requested_by'] !== (int)$u['id']): ?>
          <form method="post" action="/staff/amendments/<?= (int)$m['id'] ?>" class="btn-row" style="margin-top:.5rem"><?= csrf_field() ?><input type="text" name="note" placeholder="Note" maxlength="255" style="flex:1;min-width:160px"><button class="btn btn-sm" name="decision" value="confirm">Confirm</button><button class="btn btn-sm btn-danger" name="decision" value="reject">Reject</button></form>
        <?php endif; ?></li><?php endforeach; ?>
    </ul>
  </div>
  <?php endif; ?>

  <?php if ($payments): ?>
  <div class="panel"><h2>Payments</h2><div class="table-wrap"><table class="cards"><thead><tr><th>Batch</th><th class="r">Amount</th><th>Status</th><th>Reference</th><th>Reconciliation</th></tr></thead><tbody>
  <?php foreach ($payments as $p): ?><tr><td data-label="Batch"><?= e($p['batch_ref']) ?></td><td data-label="Amount" class="r"><?= money($p['amount']) ?></td><td data-label="Status"><?= status_badge($p['status']) ?></td><td data-label="Reference"><?= e($p['payment_reference'] ?? $p['failure_reason'] ?? '—') ?></td><td data-label="Reconciliation"><?= status_badge($p['reconciliation_status']) ?></td></tr><?php endforeach; ?>
  </tbody></table></div></div>
  <?php endif; ?>

  <div class="panel"><h2>Full history</h2>
    <ul class="timeline"><?php foreach ($history as $h): ?><li><time><?= e(fmt_date($h['created_at'], 'j M Y, g:ia')) ?> · <?= e(Workflow::DUTY_NAMES[$h['duty']] ?? $h['duty']) ?> · <?= e($h['actor'] ?? 'System') ?></time><?= e(ucfirst(str_replace('_', ' ', $h['action']))) ?><?= $h['to_status'] && $h['to_status'] !== $h['from_status'] ? ' → ' . e(status_label($h['to_status'])) : '' ?><?= $h['comment'] ? '<div class="small muted">' . e($h['comment']) . '</div>' : '' ?></li><?php endforeach; ?></ul>
  </div>
</div>

<div>
  <?php if ($can('doc_check')): ?>
  <form method="post" action="/staff/applications/<?= $id ?>/doc-check" class="panel panel-gold"><?= csrf_field() ?>
    <h2>Document check decision</h2>
    <p class="small">Pass only when every required document is verified. Return it if anything is missing, unreadable or does not match.</p>
    <div class="field"><label for="dc-c">Note <span class="hint">Required when returning; the applicant sees it</span></label><textarea id="dc-c" name="comment"></textarea></div>
    <div class="btn-row"><button class="btn" name="decision" value="pass">Pass to verification</button><button class="btn btn-danger" name="decision" value="return">Return to applicant</button></div>
  </form>
  <?php endif; ?>

  <?php if ($can('verification')): ?>
  <form method="post" action="/staff/applications/<?= $id ?>/verify" class="panel panel-gold"><?= csrf_field() ?>
    <h2>Verification decision</h2>
    <p class="small">Confirm residence, family status and enrolment. <?= $a['field_visit_required'] ? '<b>This application must have a field visit.</b>' : 'You may also order a field visit if anything is doubtful.' ?></p>
    <div class="field"><label for="vf-c">Findings</label><textarea id="vf-c" name="comment" required minlength="10"></textarea></div>
    <div class="btn-row">
      <button class="btn" name="decision" value="committee">Verified — send to committee</button>
      <?php if ($a['status'] === 'verification'): ?><button class="btn btn-line" name="decision" value="field">Needs field visit</button><?php endif; ?>
      <button class="btn btn-danger" name="decision" value="return">Return to applicant</button>
    </div>
  </form>
  <?php endif; ?>

  <?php if ($can('committee')): ?>
  <form method="post" action="/staff/applications/<?= $id ?>/committee" class="panel panel-gold"><?= csrf_field() ?>
    <h2>Committee review</h2>
    <?php if ($rule): ?><p class="small">Allowed for <?= e(level_label($a['level'])) ?>: <?= money($rule['min_amount']) ?> – <?= money($rule['max_amount']) ?>. Fee balance: <?= money($a['fee_balance']) ?>.</p><?php endif; ?>
    <div class="grid-2"><div class="field"><label for="cr-a">Recommended amount (KES)</label><input type="text" inputmode="numeric" id="cr-a" name="recommended_amount" value="<?= (int)$a['amount_requested'] ?>"></div>
    <div class="field"><label for="cr-s">Need score (1–10)</label><input type="number" min="1" max="10" id="cr-s" name="need_score"></div></div>
    <div class="field"><label for="cr-c">Reasons</label><textarea id="cr-c" name="comment" required minlength="10"></textarea></div>
    <div class="btn-row"><button class="btn" name="decision" value="recommend">Recommend</button><button class="btn btn-line" name="decision" value="not_recommend">Do not recommend</button><button class="btn btn-danger" name="decision" value="return">Return for clarification</button></div>
  </form>
  <?php endif; ?>

  <?php if ($can('approval') && $a['status'] === 'recommended'): ?>
  <form method="post" action="/staff/applications/<?= $id ?>/approve" class="panel panel-gold"><?= csrf_field() ?>
    <h2>Approval</h2>
    <p class="small">Committee recommended <b><?= money($a['amount_recommended']) ?></b>. Your approval limit: <b><?= money($u['approval_limit']) ?></b>. Ward budget is checked automatically.</p>
    <?php if ((float)$a['amount_recommended'] > 0): ?><div class="field"><label for="ap-a">Amount to approve (KES)</label><input type="text" inputmode="numeric" id="ap-a" name="amount" value="<?= (int)$a['amount_recommended'] ?>"></div><?php endif; ?>
    <div class="field"><label for="ap-c">Comment <span class="hint">Required when not approving; the applicant sees it</span></label><textarea id="ap-c" name="comment"></textarea></div>
    <div class="btn-row"><?php if ((float)$a['amount_recommended'] > 0): ?><button class="btn" name="decision" value="approve">Approve</button><?php endif; ?><button class="btn btn-danger" name="decision" value="not_approved">Not approved</button></div>
  </form>
  <?php endif; ?>

  <?php if ($can('approval') && in_array($a['status'], ['approved', 'partially_approved'], true)): ?>
  <form method="post" action="/staff/applications/<?= $id ?>/amend" class="panel"><?= csrf_field() ?>
    <h2>Request an amendment</h2>
    <p class="small">Changes to an approved amount need a second approver to confirm. Allowed only before payment is queued.</p>
    <div class="field"><label for="am-n">New amount (KES)</label><input type="text" inputmode="numeric" id="am-n" name="new_amount"></div>
    <div class="field"><label for="am-r">Reason</label><textarea id="am-r" name="reason" required minlength="15"></textarea></div>
    <button class="btn btn-line">Request amendment</button>
  </form>
  <?php endif; ?>

  <?php if ($can('audit_sample') && $a['secondary_audit'] && !DB::val("SELECT 1 FROM application_events WHERE application_id = ? AND action = 'secondary_audit_done'", [$id])): ?>
  <form method="post" action="/staff/applications/<?= $id ?>/audit-sample" class="panel panel-gold"><?= csrf_field() ?>
    <h2>Secondary audit</h2><p class="small">Randomly selected. Independently re-check documents, verification and decisions.</p>
    <div class="field"><label for="au-n">What you checked</label><textarea id="au-n" name="note" required minlength="10"></textarea></div>
    <div class="btn-row"><button class="btn" name="outcome" value="no_issues">No issues</button><button class="btn btn-danger" name="outcome" value="issues">Issues found</button></div>
  </form>
  <?php endif; ?>

  <div class="panel" id="flags"><h2>Risk flags</h2>
    <p class="small muted">Flags come from automatic duplicate and risk checks. They alert officers; they never reject anyone automatically.</p>
    <?php if (!$flags): ?><p>None.</p><?php endif; ?>
    <?php foreach ($flags as $f): ?>
      <div class="upload-item<?= $f['status'] !== 'open' ? ' ok' : '' ?>"><div class="meta"><b class="sev-<?= e($f['severity']) ?>"><?= e(strtoupper($f['severity'])) ?> · <?= e($f['code']) ?></b><?= status_badge($f['status']) ?></div>
        <p class="small"><?= e($f['details']) ?><?= $f['resolution_note'] ? '<br><b>' . e($f['resolver']) . ':</b> ' . e($f['resolution_note']) : '' ?></p>
        <?php if ($f['status'] === 'open' && $canFlags): ?>
          <form method="post" action="/staff/applications/<?= $id ?>/flags/<?= (int)$f['id'] ?>"><?= csrf_field() ?><div class="field"><input type="text" name="note" placeholder="How you checked it" required minlength="10" maxlength="500"></div>
          <div class="btn-row"><button class="btn btn-sm" name="status" value="cleared">Clear</button><button class="btn btn-sm btn-danger" name="status" value="confirmed">Confirm problem</button></div></form>
        <?php endif; ?></div>
    <?php endforeach; ?>
  </div>

  <div class="panel"><h2>Previous support</h2>
    <?php if (!$prev): ?><p class="muted">First application.</p><?php else: ?><ul class="timeline"><?php foreach ($prev as $p): ?><li><a href="/staff/applications/<?= (int)$p['id'] ?>"><?= e($p['reference']) ?></a> · <?= e($p['cycle_name']) ?><div class="small"><?= status_badge($p['status']) ?> approved <?= money($p['amount_approved']) ?>, paid <?= money($p['amount_paid']) ?></div></li><?php endforeach; ?></ul><?php endif; ?>
  </div>
  <?php if ($coi): ?><p class="small muted">Your declaration: <?= $coi['has_conflict'] ? 'conflict declared' : 'no conflict' ?> (<?= e(fmt_date($coi['created_at'], 'j M, g:ia')) ?>).</p><?php endif; ?>
</div>
</div>
