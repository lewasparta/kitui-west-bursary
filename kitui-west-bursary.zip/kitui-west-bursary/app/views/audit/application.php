<?php $sec = fn($t) => '<h2 style="margin-top:1.5rem">' . e($t) . '</h2>'; ?>
<p class="crumbs"><a href="/audit">Audit</a> › Reconstruction</p>
<div class="panel-head"><div><h1>Reconstruction: <?= e($a['reference'] ?? 'Draft #' . $a['id']) ?></h1><p class="muted"><?= e(trim($a['first_name'] . ' ' . $a['last_name'])) ?> · <?= e($a['cycle_name']) ?> · current status <?= status_badge($a['status']) ?></p></div><?php if (!in_array($a['status'], ['draft', 'withdrawn'], true)): ?><a class="btn btn-sm btn-quiet" href="/staff/applications/<?= (int)$a['id'] ?>">Case page</a><?php endif; ?></div>
<div class="amounts"><div><span>Requested</span><b><?= money($a['amount_requested']) ?></b></div><div><span>Recommended</span><b><?= money($a['amount_recommended']) ?></b></div><div><span>Approved</span><b><?= money($a['amount_approved']) ?></b></div><div><span>Paid</span><b><?= money($a['amount_paid']) ?></b></div></div>

<div class="panel">
<?= $sec('Who did what (workflow events)') ?>
<div class="table-wrap"><table class="cards"><thead><tr><th>When</th><th>Duty</th><th>Officer</th><th>Action</th><th>Status</th><th>Comment</th></tr></thead><tbody>
<?php foreach ($events as $e): ?><tr><td data-label="When" class="small"><?= e(substr($e['created_at'], 0, 19)) ?></td><td data-label="Duty"><?= e(Workflow::DUTY_NAMES[$e['duty']] ?? $e['duty']) ?></td><td data-label="Officer"><?= e($e['actor'] ?? 'System') ?></td><td data-label="Action"><?= e($e['action']) ?></td><td data-label="Status"><?= e(($e['from_status'] ?? '') . ($e['to_status'] ? ' → ' . $e['to_status'] : '')) ?></td><td data-label="Comment" class="small"><?= e($e['comment']) ?></td></tr><?php endforeach; ?>
</tbody></table></div>

<?= $sec('Conflict-of-interest declarations') ?>
<?php if (!$coi): ?><p class="muted">None.</p><?php else: ?><ul><?php foreach ($coi as $c): ?><li><?= e($c['full_name']) ?> — <?= $c['has_conflict'] ? '<b class="sev-high">conflict</b>: ' . e($c['details']) : 'no conflict' ?> (<?= e(fmt_date($c['created_at'], 'j M Y, g:ia')) ?>)</li><?php endforeach; ?></ul><?php endif; ?>

<?= $sec('Documents, including replaced versions') ?>
<div class="table-wrap"><table class="cards"><thead><tr><th>Type</th><th>File</th><th>SHA-256</th><th>Uploaded</th><th>Status</th><th>Checked by</th></tr></thead><tbody>
<?php foreach ($docs as $d): ?><tr><td data-label="Type"><?= e($d['type_name']) ?></td><td data-label="File"><a href="/files/<?= (int)$d['id'] ?>" target="_blank" rel="noopener"><?= e($d['original_name']) ?></a></td><td data-label="SHA-256" class="small num"><?= e(substr($d['sha256'], 0, 16)) ?>…</td><td data-label="Uploaded" class="small"><?= e($d['uploader']) ?>, <?= e(fmt_date($d['created_at'], 'j M Y g:ia')) ?></td><td data-label="Status"><?= status_badge($d['status']) ?></td><td data-label="Checked by"><?= e($d['verifier'] ?? '—') ?></td></tr><?php endforeach; ?>
</tbody></table></div>
<p class="small muted"><?= count($docLogs) ?> document view/upload record(s):</p>
<ul class="small"><?php foreach (array_slice($docLogs, -30) as $l): ?><li><?= e(substr($l['created_at'], 0, 19)) ?> — <?= e($l['full_name'] ?? '?') ?> <?= e($l['action']) ?> document <?= e($l['entity_id']) ?></li><?php endforeach; ?></ul>

<?= $sec('Risk flags') ?>
<?php if (!$flags): ?><p class="muted">None.</p><?php else: ?><ul><?php foreach ($flags as $f): ?><li><b class="sev-<?= e($f['severity']) ?>"><?= e($f['code']) ?></b> <?= status_badge($f['status']) ?> <?= e($f['details']) ?><?= $f['resolver'] ? ' — ' . e($f['resolver']) . ': ' . e($f['resolution_note']) : '' ?></li><?php endforeach; ?></ul><?php endif; ?>

<?= $sec('Field visits') ?>
<?php if (!$visits): ?><p class="muted">None.</p><?php else: foreach ($visits as $v): ?><p><b><?= e(fmt_date($v['visit_date'])) ?>, <?= e($v['officer']) ?>:</b> <?= e($v['outcome']) ?> — <?= e($v['findings']) ?><?= $v['gps_lat'] ? ' (GPS ' . e($v['gps_lat'] . ',' . $v['gps_lng']) . ')' : '' ?></p><?php endforeach; endif; ?>

<?= $sec('Committee, approvals and amendments') ?>
<ul>
<?php foreach ($reviews as $r): ?><li>Committee — <?= e($r['full_name']) ?>: <?= e($r['decision']) ?> <?= money($r['recommended_amount']) ?> (<?= e(fmt_date($r['created_at'], 'j M Y g:ia')) ?>) — <?= e($r['comment']) ?></li><?php endforeach; ?>
<?php foreach ($approvals as $r): ?><li>Approval — <?= e($r['full_name']) ?>: <?= e($r['decision']) ?> <?= money($r['amount']) ?> (<?= e(fmt_date($r['created_at'], 'j M Y g:ia')) ?>)</li><?php endforeach; ?>
<?php foreach ($amendments as $m): ?><li>Amendment — requested by <?= e($m['requester']) ?>, <?= money($m['old_amount']) ?> → <?= money($m['new_amount']) ?>, <?= e($m['status']) ?><?= $m['reviewer'] ? ' by ' . e($m['reviewer']) : '' ?>: <?= e($m['reason']) ?></li><?php endforeach; ?>
<?php if (!$reviews && !$approvals && !$amendments): ?><li class="muted">None.</li><?php endif; ?>
</ul>

<?= $sec('Payments') ?>
<?php if (!$payments): ?><p class="muted">None.</p><?php else: ?><div class="table-wrap"><table class="cards"><thead><tr><th>Batch</th><th class="r">Amount</th><th>Status</th><th>Prepared</th><th>Authorised</th><th>Recorded</th><th>Bank ref.</th><th>Reconciled</th></tr></thead><tbody>
<?php foreach ($payments as $p): ?><tr><td data-label="Batch"><?= e($p['batch_ref']) ?></td><td data-label="Amount" class="r"><?= money($p['amount']) ?></td><td data-label="Status"><?= status_badge($p['status']) ?></td><td data-label="Prepared"><?= e($p['preparer']) ?></td><td data-label="Authorised"><?= e($p['authoriser'] ?? '—') ?></td><td data-label="Recorded"><?= e($p['recorder'] ?? '—') ?></td><td data-label="Bank ref."><?= e($p['payment_reference'] ?? $p['failure_reason'] ?? '—') ?></td><td data-label="Reconciled"><?= status_badge($p['reconciliation_status']) ?> <?= e($p['reconciler'] ?? '') ?></td></tr><?php endforeach; ?>
</tbody></table></div><?php endif; ?>

<?= $sec('Sealed sheets issued') ?>
<?php if (!$sheets): ?><p class="muted">None.</p><?php else: ?><ul><?php foreach ($sheets as $s): ?><li><span class="num"><?= e($s['code']) ?></span> <?= e(Seal::KINDS[$s['kind']]) ?> — issued <?= e(fmt_date($s['issued_at'], 'j M Y g:ia')) ?>, checked <?= (int)$s['verify_count'] ?> time(s)<?= $s['revoked_at'] ? ' — <b>revoked</b>: ' . e($s['revoked_reason']) : '' ?></li><?php endforeach; ?></ul><?php endif; ?>

<?= $sec('SMS sent') ?>
<?php if (!$sms): ?><p class="muted">None.</p><?php else: ?><ul class="small"><?php foreach ($sms as $s): ?><li><?= e(substr($s['created_at'], 0, 16)) ?> — <?= e(mask_phone($s['phone'])) ?> — <?= e($s['status']) ?>: <?= e($s['body']) ?></li><?php endforeach; ?></ul><?php endif; ?>

<?= $sec('Raw audit records for this application') ?>
<ul class="small"><?php foreach ($logs as $l): ?><li>#<?= (int)$l['id'] ?> <?= e(substr($l['created_at'], 0, 19)) ?> — <?= e($l['full_name'] ?? 'system') ?> — <?= e($l['action']) ?> <code><?= e($l['details']) ?></code></li><?php endforeach; ?></ul>
</div>
