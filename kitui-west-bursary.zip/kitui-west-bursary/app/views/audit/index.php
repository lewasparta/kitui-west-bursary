<h1>Audit</h1>
<div class="verify-result <?= $ok ? 'valid' : 'bad' ?>">
  <h2><?= $ok ? 'Audit trail intact' : 'Audit trail integrity FAILURE' ?></h2>
  <p><?= $ok ? 'All ' . number_format($checked) . ' audit records were re-hashed just now and the chain is unbroken. No record has been edited or removed.' : 'The hash chain breaks' . ($broken ? ' at record #' . (int)$broken : ' at the end of the log') . '. A record was altered or deleted directly in the database. Escalate immediately and restore from backup for comparison.' ?></p>
</div>
<div class="stats">
  <div class="stat"><b><?= $counts['flags'] ?></b><span>Open high-risk flags</span></div>
  <a class="stat" href="/audit/concerns" style="text-decoration:none;color:inherit"><b><?= $counts['concerns'] ?></b><span>Open concerns</span></a>
  <a class="stat gold" href="/finance#reconcile" style="text-decoration:none;color:inherit"><b><?= $counts['unrec'] ?></b><span>Payments to reconcile</span></a>
  <div class="stat"><b><?= $counts['discrepancy'] ?></b><span>Payment discrepancies</span></div>
  <a class="stat" href="/staff/queue/audit_sample" style="text-decoration:none;color:inherit"><b><?= $counts['samples'] ?></b><span>Secondary audits due</span></a>
  <div class="stat"><b><?= $counts['sod'] ?></b><span>Blocked actions (30 days)</span></div>
  <div class="stat"><b><?= $counts['seal'] ?></b><span>Sheet seal failures</span></div>
</div>
<div class="two-col">
<div class="panel"><div class="panel-head"><h2>Security and access events</h2><a href="/audit/logs?category=security">Full log</a></div>
<?php if (!$security): ?><p class="muted">None.</p><?php else: ?><ul class="timeline"><?php foreach ($security as $s): ?><li><time><?= e(fmt_date($s['created_at'], 'j M, g:ia')) ?> · <?= e($s['full_name'] ?? 'anonymous') ?> · <?= e($s['ip']) ?></time><?= e(str_replace('_', ' ', $s['action'])) ?> <?= $s['entity_type'] ? e($s['entity_type'] . ' ' . $s['entity_id']) : '' ?></li><?php endforeach; ?></ul><?php endif; ?>
</div>
<div class="panel"><h2>Open risk flags</h2>
<?php if (!$flags): ?><p class="muted">None.</p><?php else: ?><ul class="timeline"><?php foreach ($flags as $f): ?><li><a href="/audit/applications/<?= (int)$f['application_id'] ?>"><?= e($f['reference']) ?></a> <span class="sev-<?= e($f['severity']) ?>"><?= e($f['code']) ?></span><div class="small"><?= e($f['details']) ?></div></li><?php endforeach; ?></ul><?php endif; ?>
</div>
</div>
<div class="panel"><h2>Reconstruct an application</h2><form method="get" action="/staff/search" class="filters"><div class="field"><label for="q">Reference or name</label><input type="search" id="q" name="q"></div><button class="btn btn-line">Find</button></form>
<p class="small muted">Open the application, then choose “Full audit reconstruction”. <a href="/reports">Reports</a> include a downloadable audit report.</p></div>
