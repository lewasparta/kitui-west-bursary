<p class="crumbs"><?= Auth::has('auditor') ? '<a href="/audit">Audit</a>' : '<a href="/admin">Administration</a>' ?> › Trail</p>
<h1>Audit trail</h1>
<form method="get" class="filters">
  <div class="field"><label for="cat">Category</label><select id="cat" name="category"><option value="">All</option><?php foreach (['workflow','data','security','access','finance','config','report'] as $c): ?><option<?= selected(input('category'), $c) ?>><?= $c ?></option><?php endforeach; ?></select></div>
  <div class="field"><label for="usr">Staff member</label><select id="usr" name="user"><option value="">Anyone</option><?php foreach ($users as $u): ?><option value="<?= (int)$u['id'] ?>"<?= selected(input('user'), $u['id']) ?>><?= e($u['full_name']) ?></option><?php endforeach; ?></select></div>
  <div class="field"><label for="et">Entity</label><input type="text" id="et" name="entity_type" value="<?= e(input('entity_type')) ?>" placeholder="application"></div>
  <div class="field"><label for="eid">Entity id</label><input type="text" id="eid" name="entity_id" value="<?= e(input('entity_id')) ?>"></div>
  <div class="field"><label for="fr">From</label><input type="date" id="fr" name="from" value="<?= e(input('from')) ?>"></div>
  <div class="field"><label for="to">To</label><input type="date" id="to" name="to" value="<?= e(input('to')) ?>"></div>
  <button class="btn btn-line">Filter</button>
</form>
<div class="table-wrap"><table class="cards"><thead><tr><th>#</th><th>When</th><th>Who</th><th>Category</th><th>Action</th><th>Entity</th><th>Details</th><th>Hash</th></tr></thead><tbody>
<?php foreach ($p['rows'] as $l): ?><tr><td data-label="#" class="num"><?= (int)$l['id'] ?></td><td data-label="When" class="small"><?= e(substr($l['created_at'], 0, 19)) ?></td><td data-label="Who"><?= e($l['full_name'] ?? '—') ?><div class="small muted"><?= e($l['ip']) ?></div></td><td data-label="Category"><?= e($l['category']) ?></td><td data-label="Action"><?= e($l['action']) ?></td>
<td data-label="Entity"><?php if ($l['entity_type'] === 'application' && Auth::has('auditor')): ?><a href="/audit/applications/<?= (int)$l['entity_id'] ?>">application <?= e($l['entity_id']) ?></a><?php else: ?><?= e($l['entity_type'] . ' ' . $l['entity_id']) ?><?php endif; ?></td>
<td data-label="Details" class="small"><code style="overflow-wrap:anywhere"><?= e($l['details']) ?></code></td><td data-label="Hash" class="small num"><?= e(substr($l['hash'], 0, 10)) ?>…</td></tr><?php endforeach; ?>
</tbody></table></div>
<?= partial('pager', ['p' => $p]) ?>
