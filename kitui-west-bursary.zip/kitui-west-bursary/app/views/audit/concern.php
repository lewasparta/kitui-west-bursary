<p class="crumbs"><a href="/audit/concerns">Concerns</a> › <?= e($c['reference']) ?></p>
<div class="panel-head"><h1><?= e($c['reference']) ?></h1><?= status_badge($c['status']) ?></div>
<div class="two-col">
<div>
<div class="panel"><dl class="facts"><dt>Category</dt><dd><?= e(str_replace('_', ' ', $c['category'])) ?></dd><dt>Received</dt><dd><?= e(fmt_date($c['created_at'], 'j M Y, g:ia')) ?></dd><dt>Ward</dt><dd><?= e($c['ward_name'] ?? '—') ?></dd>
<dt>Reporter</dt><dd><?= $c['is_anonymous'] ? 'Anonymous' : e($c['reporter_name'] . ', ' . $c['reporter_phone']) ?></dd><dt>Related application</dt><dd><?= $related ? '<a href="/audit/applications/' . (int)$related['id'] . '">' . e($related['reference']) . '</a>' : e($c['related_reference'] ?? '—') ?></dd></dl>
<h3 style="margin-top:1rem">What was reported</h3><p><?= nl2br(e($c['description'])) ?></p></div>
<div class="panel"><h2>Investigation notes</h2><?php if (!$updates): ?><p class="muted">None yet.</p><?php else: ?><ul class="timeline"><?php foreach ($updates as $u): ?><li><time><?= e(fmt_date($u['created_at'], 'j M Y, g:ia')) ?> · <?= e($u['full_name']) ?><?= $u['is_public'] ? ' · visible to reporter' : ' · internal' ?></time><?= e($u['note']) ?></li><?php endforeach; ?></ul><?php endif; ?></div>
</div>
<form method="post" action="/audit/concerns/<?= (int)$c['id'] ?>" class="panel panel-gold"><?= csrf_field() ?>
  <h2>Update</h2>
  <div class="field"><label for="st">Status</label><select id="st" name="status"><?php foreach (['received','under_review','investigating','resolved','closed'] as $s): ?><option value="<?= $s ?>"<?= selected($c['status'], $s) ?>><?= e(ucfirst(str_replace('_', ' ', $s))) ?></option><?php endforeach; ?></select></div>
  <div class="field"><label for="as">Assigned auditor</label><select id="as" name="assigned_to"><option value="">—</option><?php foreach ($auditors as $a): ?><option value="<?= (int)$a['id'] ?>"<?= selected($c['assigned_to'], $a['id']) ?>><?= e($a['full_name']) ?></option><?php endforeach; ?></select></div>
  <div class="field"><label for="nt">Note</label><textarea id="nt" name="note" required></textarea></div>
  <label class="check"><input type="checkbox" name="is_public" value="1">Show this note to the reporter when they track the concern</label><p></p>
  <button class="btn">Save update</button>
</form>
</div>
