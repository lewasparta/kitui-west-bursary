<h1>Finance</h1>
<p class="muted">Payments go only to institutions’ bank accounts. A batch prepared by one officer must be authorised by another, and no application is marked paid without a bank reference.</p>

<?php if ($isFinance): ?>
<form method="post" action="/finance/queue" class="panel"><?= csrf_field() ?>
  <div class="panel-head"><h2>1. Approved — confirm for payment</h2><span class="small muted"><?= count($approved) ?> waiting</span></div>
  <?php if (!$approved): ?><p class="muted">No newly approved applications.</p><?php else: ?>
  <div class="table-wrap"><table class="cards"><thead><tr><th><input type="checkbox" data-check-all aria-label="Select all"></th><th>Reference</th><th>Student</th><th>Institution</th><th>Account</th><th class="r">Approved</th></tr></thead><tbody>
  <?php foreach ($approved as $r): ?><tr><td><input type="checkbox" name="ids[]" value="<?= (int)$r['id'] ?>" aria-label="Select <?= e($r['reference']) ?>"></td><td data-label="Reference"><?= e($r['reference']) ?></td><td data-label="Student"><?= e($r['first_name'] . ' ' . $r['last_name']) ?></td><td data-label="Institution"><?= e($r['institution_name']) ?></td><td data-label="Account"><?= $r['account_no'] ? e($r['account_no']) : '<span class="sev-high">No bank account on file</span>' ?></td><td data-label="Approved" class="r"><?= money($r['amount_approved']) ?></td></tr><?php endforeach; ?>
  </tbody></table></div><p></p><button class="btn">Mark selected ready for payment</button>
  <?php endif; ?>
</form>

<form method="post" action="/finance/batches" class="panel"><?= csrf_field() ?>
  <div class="panel-head"><h2>2. Ready for payment — build a batch</h2><span class="small muted"><?= count($ready) ?> ready</span></div>
  <?php if (!$ready): ?><p class="muted">Nothing ready.</p><?php else: ?>
  <div class="table-wrap"><table class="cards"><thead><tr><th><input type="checkbox" data-check-all aria-label="Select all"></th><th>Reference</th><th>Student</th><th>Institution</th><th class="r">Amount</th></tr></thead><tbody>
  <?php foreach ($ready as $r): ?><tr><td><input type="checkbox" name="ids[]" value="<?= (int)$r['id'] ?>"<?= $r['account_no'] ? '' : ' disabled' ?> aria-label="Select <?= e($r['reference']) ?>"></td><td data-label="Reference"><?= e($r['reference']) ?></td><td data-label="Student"><?= e($r['first_name'] . ' ' . $r['last_name']) ?></td><td data-label="Institution"><?= e($r['institution_name']) ?><?= $r['account_no'] ? '' : ' <span class="sev-high">(add bank details first)</span>' ?></td><td data-label="Amount" class="r"><?= money($r['amount_approved']) ?></td></tr><?php endforeach; ?>
  </tbody></table></div><p></p><button class="btn">Create payment batch</button>
  <?php endif; ?>
</form>
<?php endif; ?>

<div class="panel"><h2>3. Batches</h2>
<?php if (!$batches): ?><p class="muted">No batches yet.</p><?php else: ?>
<div class="table-wrap"><table class="cards"><thead><tr><th>Batch</th><th>Status</th><th class="r">Total</th><th>Payments</th><th>Prepared by</th><th>Authorised by</th><th></th></tr></thead><tbody>
<?php foreach ($batches as $b): ?><tr><td data-label="Batch" class="num"><?= e($b['reference']) ?></td><td data-label="Status"><?= status_badge($b['status'] === 'completed' ? 'closed' : $b['status']) ?></td><td data-label="Total" class="r"><?= money($b['total_amount']) ?></td><td data-label="Payments"><?= (int)$b['paid_n'] ?>/<?= (int)$b['n'] ?> paid</td><td data-label="Prepared by"><?= e($b['creator']) ?></td><td data-label="Authorised by"><?= e($b['authoriser'] ?? '—') ?></td><td><a class="btn btn-sm" href="/finance/batches/<?= (int)$b['id'] ?>">Open</a></td></tr><?php endforeach; ?>
</tbody></table></div><?php endif; ?>
</div>

<?php if ($failed && $isFinance): ?>
<div class="panel panel-alert"><h2>Failed payments</h2>
<?php foreach ($failed as $f): ?><form method="post" action="/finance/payments/<?= (int)$f['id'] ?>/requeue" class="btn-row" style="margin-bottom:.5rem"><?= csrf_field() ?><span><b><?= e($f['reference']) ?></b> <?= money($f['amount']) ?> — <?= e($f['failure_reason']) ?></span><button class="btn btn-sm btn-line">Re-queue</button></form><?php endforeach; ?>
</div>
<?php endif; ?>

<div class="panel" id="reconcile"><h2>4. Reconciliation</h2>
<p class="small muted">Match each recorded payment against the bank statement. You cannot reconcile a payment you recorded yourself.</p>
<?php if (!$unrec): ?><p class="muted">All recorded payments are reconciled.</p><?php else: ?>
<?php foreach ($unrec as $p): ?>
<form method="post" action="/finance/payments/<?= (int)$p['id'] ?>/reconcile" class="upload-item"><?= csrf_field() ?>
  <div class="meta"><b><?= e($p['reference']) ?> · <?= e($p['institution_name']) ?></b><span class="num"><?= money($p['amount']) ?> · <?= e(strtoupper((string)$p['payment_method'])) ?> <?= e($p['payment_reference']) ?> · <?= e(fmt_date($p['paid_on'])) ?></span></div>
  <div class="small muted">Recorded by <?= e($p['recorder']) ?></div>
  <?php if (!$p['_block']): ?>
  <div class="btn-row" style="margin-top:.5rem"><input type="text" name="note" placeholder="Bank statement line / note" maxlength="255" style="flex:1;min-width:200px"><button class="btn btn-sm" name="result" value="reconciled">Matches statement</button><button class="btn btn-sm btn-danger" name="result" value="discrepancy">Discrepancy</button></div>
  <?php else: ?><p class="small lock-note">Another officer or an auditor must reconcile this one<?= $p['_block'] === 'coi_required' ? '' : ': ' . e($p['_block']) ?></p><?php endif; ?>
</form>
<?php endforeach; endif; ?>
</div>
