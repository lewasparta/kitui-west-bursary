<p class="crumbs"><a href="/finance">Finance</a> › <?= e($b['reference']) ?></p>
<div class="panel-head"><div><h1>Payment batch <?= e($b['reference']) ?></h1><p class="muted">Prepared by <?= e($b['creator']) ?> on <?= e(fmt_date($b['created_at'], 'j M Y, g:ia')) ?><?= $b['authoriser'] ? ' · authorised by ' . e($b['authoriser']) . ' on ' . e(fmt_date($b['authorized_at'], 'j M Y, g:ia')) : '' ?></p></div>
<div class="btn-row"><?= status_badge($b['status'] === 'completed' ? 'closed' : $b['status']) ?><a class="btn btn-sm btn-quiet" href="/reports/payment_schedule?batch=<?= (int)$b['id'] ?>&format=print">Print schedule</a><a class="btn btn-sm btn-quiet" href="/reports/payment_schedule?batch=<?= (int)$b['id'] ?>&format=xls">Excel</a></div></div>
<div class="stats"><div class="stat"><b><?= count($rows) ?></b><span>Payments</span></div><div class="stat gold"><b><?= money($b['total_amount']) ?></b><span>Batch total</span></div></div>

<?php if ($b['status'] === 'draft' && $isFinance): ?>
<div class="panel panel-gold">
  <?php if ((int)$b['created_by'] === (int)$u['id']): ?>
    <p><b>Waiting for authorisation.</b> Another finance officer must check this batch against the award records and authorise it. You prepared it, so you cannot.</p>
    <form method="post" action="/finance/batches/<?= (int)$b['id'] ?>/cancel" data-confirm="Cancel this draft batch?"><?= csrf_field() ?><button class="btn btn-sm btn-quiet">Cancel draft batch</button></form>
  <?php else: ?>
    <p>Check every line against the approved award and the institution’s bank details, then authorise.</p>
    <form method="post" action="/finance/batches/<?= (int)$b['id'] ?>/authorize" data-confirm="Authorise payment of <?= e(money($b['total_amount'])) ?>?" class="btn-row"><?= csrf_field() ?><button class="btn btn-gold">Authorise batch</button></form>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php foreach ($rows as $r): ?>
<div class="upload-item<?= $r['status'] === 'paid' ? ' ok' : '' ?>">
  <div class="meta"><b><?= e($r['reference']) ?> · <?= e($r['first_name'] . ' ' . $r['last_name']) ?></b><span><?= status_badge($r['status']) ?> <b class="num"><?= money($r['amount']) ?></b></span></div>
  <div class="small"><?= e($r['institution_name']) ?> — <?= e($r['bank_name'] ?? '?') ?>, <?= e($r['bank_branch'] ?? '') ?>, A/C <?= e($r['account_name'] ?? '') ?> <b class="num"><?= e($r['account_no'] ?? '') ?></b></div>
  <?php if ($r['status'] === 'paid'): ?><div class="small">Paid <?= e(fmt_date($r['paid_on'])) ?> · <?= e(strtoupper((string)$r['payment_method'])) ?> <?= e($r['payment_reference']) ?> · recorded by <?= e($r['recorder']) ?> · <?= status_badge($r['reconciliation_status']) ?></div>
  <?php elseif ($r['status'] === 'failed'): ?><div class="small sev-high">Failed: <?= e($r['failure_reason']) ?></div><?php endif; ?>
  <?php if ($r['status'] === 'processing' && $isFinance && $r['_block']): ?>
    <p class="small lock-note">Another finance officer must record this payment: <?= e($r['_block'] === 'coi_required' ? 'you have not declared a conflict of interest for this application.' : $r['_block']) ?></p>
  <?php elseif ($r['status'] === 'processing' && $isFinance): ?>
    <form method="post" action="/finance/payments/<?= (int)$r['id'] ?>/record" style="margin-top:.6rem"><?= csrf_field() ?>
      <div class="grid-3">
        <div class="field"><label>Method</label><select name="payment_method"><option value="eft">EFT</option><option value="rtgs">RTGS</option><option value="cheque">Cheque</option></select></div>
        <div class="field"><label>Bank reference</label><input type="text" name="payment_reference" maxlength="60" class="code-input"></div>
        <div class="field"><label>Date paid</label><input type="date" name="paid_on" max="<?= date('Y-m-d') ?>" value="<?= date('Y-m-d') ?>"></div>
      </div>
      <div class="btn-row"><button class="btn btn-sm" name="outcome" value="paid">Record as paid</button>
        <input type="text" name="failure_reason" placeholder="If failed: reason from bank" maxlength="255" style="flex:1;min-width:180px"><button class="btn btn-sm btn-danger" name="outcome" value="failed">Record failure</button></div>
    </form>
  <?php endif; ?>
</div>
<?php endforeach; ?>
