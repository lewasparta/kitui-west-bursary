<?php $qr = true; ?>
<div class="narrow">
  <div class="panel">
    <h1>Turn on two-step verification</h1>
    <p>Scan with your authenticator app, then enter the 6-digit code to confirm.</p>
    <div class="qr-box" data-qr="<?= e($uri) ?>"></div>
    <p class="small muted">Key: <b class="num"><?= e(chunk_split($secret, 4, ' ')) ?></b></p>
    <form method="post" action="/account/2fa"><?= csrf_field() ?>
      <div class="field<?= isset($errors['code']) ? ' has-error' : '' ?>"><label for="code">Code</label><input id="code" name="code" inputmode="numeric" maxlength="7" required><?= field_error($errors, 'code') ?></div>
      <button class="btn">Turn on</button>
    </form>
  </div>
</div>
