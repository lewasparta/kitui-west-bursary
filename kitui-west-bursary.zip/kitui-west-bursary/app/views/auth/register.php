<div class="wrap section narrow">
  <div class="panel">
    <h1>Create an account</h1>
    <p class="muted">Use a number you can receive SMS on. All updates about the application go to this number.</p>
    <form method="post" action="/register" novalidate>
      <?= csrf_field() ?>
      <fieldset><legend>I am applying as</legend><div class="choice-list">
        <label class="check"><input type="radio" name="account_type" value="parent"<?= checked(($_SESSION['old']['account_type'] ?? 'parent') === 'parent') ?>><span><b>Parent or guardian</b><br><span class="small muted">You can add more than one child.</span></span></label>
        <label class="check"><input type="radio" name="account_type" value="student"<?= checked(($_SESSION['old']['account_type'] ?? '') === 'student') ?>><span><b>Student</b><br><span class="small muted">For students applying for themselves, usually at college or university.</span></span></label>
      </div><?= field_error($errors, 'account_type') ?></fieldset>
      <div class="field<?= isset($errors['full_name']) ? ' has-error' : '' ?>"><label for="full_name">Full name</label><input id="full_name" name="full_name" value="<?= old('full_name') ?>" autocomplete="name" required><?= field_error($errors, 'full_name') ?></div>
      <div class="grid-2">
        <div class="field<?= isset($errors['phone']) ? ' has-error' : '' ?>"><label for="phone">Mobile number</label><input type="tel" id="phone" name="phone" value="<?= old('phone') ?>" inputmode="tel" placeholder="0712345678" required><?= field_error($errors, 'phone') ?></div>
        <div class="field<?= isset($errors['national_id']) ? ' has-error' : '' ?>"><label for="national_id">National ID number <span class="hint">Optional for students under 18</span></label><input id="national_id" name="national_id" value="<?= old('national_id') ?>" inputmode="numeric"><?= field_error($errors, 'national_id') ?></div>
      </div>
      <div class="field<?= isset($errors['email']) ? ' has-error' : '' ?>"><label for="email">Email <span class="hint">Optional</span></label><input type="email" id="email" name="email" value="<?= old('email') ?>" autocomplete="email"><?= field_error($errors, 'email') ?></div>
      <div class="grid-2">
        <div class="field<?= isset($errors['password']) ? ' has-error' : '' ?>"><label for="password">Password <span class="hint">At least 10 characters with letters and numbers</span></label><input type="password" id="password" name="password" autocomplete="new-password" required><?= field_error($errors, 'password') ?></div>
        <div class="field<?= isset($errors['password_confirmation']) ? ' has-error' : '' ?>"><label for="password_confirmation">Repeat password</label><input type="password" id="password_confirmation" name="password_confirmation" autocomplete="new-password" required><?= field_error($errors, 'password_confirmation') ?></div>
      </div>
      <label class="check"><input type="checkbox" name="consent" value="1"><span>I agree that the information I give will be used only to assess and pay bursaries, and will be seen only by authorised officers. <a href="/privacy" target="_blank">Read the privacy notice</a>.</span></label>
      <?= field_error($errors, 'consent') ?>
      <p></p><button class="btn">Create account</button>
    </form>
  </div>
  <p>Already have an account? <a href="/login">Log in</a>.</p>
</div>
