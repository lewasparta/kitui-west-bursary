<div class="wrap section narrow">
  <div class="panel">
    <p class="eyebrow">Step 2 of 2</p>
    <h1>Confirm your phone number</h1>
    <p>We sent a 6-digit code by SMS to <b><?= e(mask_phone($phone)) ?></b>. This makes sure nobody can open an account with your number.</p>
    <?php if ($testCode): ?>
      <div class="flash flash-info"><b>Test mode:</b> no SMS provider is set up yet, so the code is shown here on this computer only: <code class="test-code"><?= e($testCode) ?></code></div>
    <?php endif; ?>
    <form method="post" action="/register/verify"><?= csrf_field() ?>
      <div class="field<?= isset($errors['code']) ? ' has-error' : '' ?>"><label for="code">Verification code</label>
        <input id="code" name="code" inputmode="numeric" maxlength="6" autocomplete="one-time-code" class="code-input" required autofocus><?= field_error($errors, 'code') ?></div>
      <button class="btn btn-lg">Confirm and create my account</button>
    </form>
    <form method="post" action="/register/resend" class="inline"><?= csrf_field() ?><button class="btn btn-quiet btn-sm">Send a new code</button></form>
    <a class="small" href="/register">Change the phone number</a>
  </div>
</div>
