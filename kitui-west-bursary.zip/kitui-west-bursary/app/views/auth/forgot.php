<div class="wrap section narrow">
  <div class="panel">
    <h1>Reset your password</h1>
    <p>We will send a 6-digit code to your registered mobile number.</p>
    <form method="post" action="/forgot-password"><?= csrf_field() ?>
      <div class="field"><label for="phone">Mobile number</label><input type="tel" id="phone" name="phone" inputmode="tel" required></div>
      <button class="btn">Send code</button>
    </form>
  </div>
</div>
