<?php $qr = true; ?>
<div class="wrap section narrow">
  <div class="panel">
    <h1>Two-step verification</h1>
    <?php if ($enrol): ?>
      <p>Staff accounts with administrator access must use an authenticator app (Google Authenticator, Microsoft Authenticator or similar). Scan this code, then enter the 6-digit number the app shows.</p>
      <div class="qr-box" data-qr="<?= e($uri) ?>"></div>
      <p class="small muted">Can’t scan? Enter this key in the app: <b class="num"><?= e(chunk_split((string)$secret, 4, ' ')) ?></b></p>
    <?php else: ?>
      <p>Enter the 6-digit code from your authenticator app.</p>
    <?php endif; ?>
    <form method="post" action="/2fa">
      <?= csrf_field() ?>
      <div class="field<?= isset($errors['code']) ? ' has-error' : '' ?>"><label for="code">Code</label><input id="code" name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="7" required autofocus><?= field_error($errors, 'code') ?></div>
      <button class="btn">Verify</button>
    </form>
  </div>
</div>
