<div class="narrow">
  <div class="panel">
    <h1>Change password</h1>
    <form method="post" action="/account/password"><?= csrf_field() ?>
      <div class="field<?= isset($errors['current_password']) ? ' has-error' : '' ?>"><label for="current_password">Current password</label><input type="password" id="current_password" name="current_password" autocomplete="current-password" required><?= field_error($errors, 'current_password') ?></div>
      <div class="field<?= isset($errors['password']) ? ' has-error' : '' ?>"><label for="password">New password</label><input type="password" id="password" name="password" autocomplete="new-password" required><?= field_error($errors, 'password') ?></div>
      <div class="field<?= isset($errors['password_confirmation']) ? ' has-error' : '' ?>"><label for="password_confirmation">Repeat new password</label><input type="password" id="password_confirmation" name="password_confirmation" autocomplete="new-password" required><?= field_error($errors, 'password_confirmation') ?></div>
      <button class="btn">Save password</button>
    </form>
  </div>
</div>
