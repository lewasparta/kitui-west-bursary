<div class="wrap section narrow">
  <div class="panel">
    <h1>Choose a new password</h1>
    <?php if (!empty($_SESSION['test_code'])): ?><div class="flash flash-info"><b>Test mode:</b> no SMS provider is set up yet, so the code is shown on this computer only: <code class="test-code"><?= e($_SESSION['test_code']) ?></code></div><?php endif; ?>
    <form method="post" action="/reset-password"><?= csrf_field() ?>
      <div class="field"><label for="phone">Mobile number</label><input type="tel" id="phone" name="phone" value="<?= e($phone) ?>" required></div>
      <div class="field<?= isset($errors['code']) ? ' has-error' : '' ?>"><label for="code">6-digit code from SMS</label><input id="code" name="code" inputmode="numeric" maxlength="6" autocomplete="one-time-code" required><?= field_error($errors, 'code') ?></div>
      <div class="field<?= isset($errors['password']) ? ' has-error' : '' ?>"><label for="password">New password</label><input type="password" id="password" name="password" autocomplete="new-password" required><?= field_error($errors, 'password') ?></div>
      <div class="field<?= isset($errors['password_confirmation']) ? ' has-error' : '' ?>"><label for="password_confirmation">Repeat new password</label><input type="password" id="password_confirmation" name="password_confirmation" autocomplete="new-password" required><?= field_error($errors, 'password_confirmation') ?></div>
      <div class="btn-row"><button class="btn">Save new password</button><a href="/forgot-password">Send a new code</a></div>
    </form>
  </div>
</div>
