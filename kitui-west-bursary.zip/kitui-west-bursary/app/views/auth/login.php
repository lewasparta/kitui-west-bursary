<div class="wrap section narrow">
  <div class="panel">
    <h1>Log in</h1>
    <p class="muted">Parents, students and bursary staff all log in here.</p>
    <?php if (!empty($errors['form'])): ?><div class="flash flash-error" role="alert"><?= e($errors['form']) ?></div><?php endif; ?>
    <form method="post" action="/login" novalidate>
      <?= csrf_field() ?>
      <div class="field"><label for="phone">Mobile number</label><input type="tel" id="phone" name="phone" value="<?= old('phone') ?>" autocomplete="username" inputmode="tel" required></div>
      <div class="field"><label for="password">Password</label><input type="password" id="password" name="password" autocomplete="current-password" required></div>
      <div class="btn-row"><button class="btn">Log in</button><a href="/forgot-password">Forgot password?</a></div>
    </form>
  </div>
  <p>New here? <a href="/register">Create an account to apply</a>.</p>
</div>
