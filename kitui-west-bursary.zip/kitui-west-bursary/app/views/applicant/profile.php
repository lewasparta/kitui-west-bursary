<h1>Profile</h1>
<div class="two-col">
<div>
<div class="panel">
  <h2>Account</h2>
  <dl class="facts"><dt>Name</dt><dd><?= e($u['full_name']) ?></dd><dt>Mobile</dt><dd><?= e($u['phone']) ?></dd><dt>Account type</dt><dd><?= e(ucfirst($u['account_type'])) ?></dd></dl>
  <p class="small muted" style="margin-top:1rem">Your name and mobile number are used to verify applications, so they can only be changed by the bursary office. Visit or call with your ID.</p>
  <form method="post" action="/portal/profile"><?= csrf_field() ?><input type="hidden" name="action" value="email">
    <div class="field<?= isset($errors['email']) ? ' has-error' : '' ?>"><label for="email">Email <span class="hint">Optional</span></label><input type="email" id="email" name="email" value="<?= e($u['email']) ?>"><?= field_error($errors, 'email') ?></div>
    <button class="btn">Save</button> <a class="btn btn-quiet" href="/account/password">Change password</a>
  </form>
</div>
</div>
<div>
<?php if ($u['account_type'] === 'student'): ?>
<div class="panel panel-gold">
  <h2>Link your student record</h2>
  <?php if ($linked): ?><p>Linked to: <b><?= e($linked[0]['first_name'] . ' ' . $linked[0]['last_name']) ?></b>. You can see its applications, support history and mentorship.</p>
  <?php else: ?>
  <p class="small">If a parent or guardian applied for you, ask them for the application reference and the 8-character <b>student access code</b> shown on their application page.</p>
  <form method="post" action="/portal/profile"><?= csrf_field() ?><input type="hidden" name="action" value="link">
    <div class="field"><label for="reference">Application reference</label><input id="reference" name="reference" class="code-input" placeholder="KWB-2026-000001" required></div>
    <div class="field"><label for="code">Student access code</label><input id="code" name="code" class="code-input" maxlength="8" required></div>
    <button class="btn">Link record</button>
  </form>
  <?php endif; ?>
</div>
<?php endif; ?>
<div class="panel"><h2>Your data</h2><p class="small">Your information is used only to assess and pay bursaries. Officers can see it only when working on your application, and every view of documents is recorded. Public statistics never show names, phone numbers, IDs or home details.</p></div>
</div>
</div>
