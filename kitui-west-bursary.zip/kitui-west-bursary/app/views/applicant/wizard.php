<?php
$id = (int)$a['id'];
$val = function (string $key, mixed $saved = '') use ($draft): string {
    if (array_key_exists($key, $_POST)) { return e($_POST[$key]); }
    if (array_key_exists($key, $draft)) { return e($draft[$key]); }
    return e($saved ?? '');
};
$err = fn(string $f) => field_error($errors, $f);
$cls = fn(string $f) => 'field' . (isset($errors[$f]) ? ' has-error' : '');
$autosave = $step <= 4 ? ' data-autosave="/portal/applications/' . $id . '/autosave" data-step="' . $step . '"' : '';
?>
<p class="crumbs"><a href="/portal">Applications</a> › <?= e($a['reference'] ?? 'New application') ?></p>
<div class="panel-head"><h1><?= e(WIZARD[$step]) ?></h1><span class="muted small">Step <?= $step ?> of 7</span></div>

<?php if ($a['status'] === 'returned' && $a['return_reason']): ?>
  <div class="flash flash-error"><b>The officer asked you to fix this:</b> <?= e($a['return_reason']) ?></div>
<?php endif; ?>

<ol class="wizard-steps">
<?php foreach (WIZARD as $n => $label): ?>
  <li class="<?= $n === $step ? 'cur' : ($n <= (int)$a['wizard_step'] ? 'done' : '') ?>">
    <?php if ($n === $step): ?><span><?= $n ?>. <?= e($label) ?></span>
    <?php elseif ($n <= (int)$a['wizard_step']): ?><a href="/portal/applications/<?= $id ?>/step/<?= $n ?>"><?= $n ?>. <?= e($label) ?></a>
    <?php else: ?><span><?= $n ?>. <?= e($label) ?></span><?php endif; ?>
  </li>
<?php endforeach; ?>
</ol>

<?php if ($errors && $step !== 7): ?><div class="flash flash-error" role="alert">Please correct the highlighted fields.</div><?php endif; ?>

<?php if ($step <= 6): ?>
<form method="post" action="/portal/applications/<?= $id ?>/step/<?= $step ?>" class="panel" novalidate<?= $autosave ?>>
<?= csrf_field() ?>

<?php if ($step === 1): ?>
  <p class="muted">The parent or guardian who is responsible for the student. We use this number to confirm the application.</p>
  <div class="grid-2">
    <div class="<?= $cls('guardian_full_name') ?>"><label for="gfn">Full name</label><input type="text" id="gfn" name="guardian_full_name" value="<?= $val('guardian_full_name', $a['guardian_name'] ?? ($u['account_type'] === 'parent' ? $u['full_name'] : '')) ?>" autocomplete="name"><?= $err('guardian_full_name') ?></div>
    <div class="<?= $cls('guardian_relationship') ?>"><label for="grel">Relationship to the student</label>
      <select id="grel" name="guardian_relationship"><option value="">Choose…</option>
      <?php $rv = html_entity_decode($val('guardian_relationship', $a['guardian_relationship'])); foreach (['mother' => 'Mother', 'father' => 'Father', 'guardian' => 'Guardian', 'grandparent' => 'Grandparent', 'sibling' => 'Older sibling', 'other' => 'Other'] as $k => $l): ?>
        <option value="<?= $k ?>"<?= selected($rv, $k) ?>><?= $l ?></option><?php endforeach; ?>
      </select><?= $err('guardian_relationship') ?></div>
    <div class="<?= $cls('guardian_phone') ?>"><label for="gph">Mobile number</label><input type="tel" inputmode="tel" id="gph" name="guardian_phone" value="<?= $val('guardian_phone', $a['guardian_phone'] ?? ($u['account_type'] === 'parent' ? $u['phone'] : '')) ?>"><?= $err('guardian_phone') ?></div>
    <div class="<?= $cls('guardian_national_id') ?>"><label for="gid">National ID number</label><input type="text" inputmode="numeric" id="gid" name="guardian_national_id" value="<?= $val('guardian_national_id', $a['guardian_nid']) ?>"><?= $err('guardian_national_id') ?></div>
    <div class="<?= $cls('guardian_occupation') ?>"><label for="gocc">Occupation <span class="hint">Optional</span></label><input type="text" id="gocc" name="guardian_occupation" value="<?= $val('guardian_occupation', $a['guardian_occupation']) ?>"><?= $err('guardian_occupation') ?></div>
  </div>

<?php elseif ($step === 2): ?>
  <?php if ($student && $student['verified_at']): ?>
    <div class="lock-note"><span aria-hidden="true">🔒</span><div><b><?= e($student['first_name'] . ' ' . $student['last_name']) ?></b> — identity details were verified in an earlier application and are locked. Update only the location if it changed.</div></div><p></p>
    <div class="grid-2">
      <div class="<?= $cls('sub_location') ?>"><label for="sl">Sub-location</label><input type="text" id="sl" name="sub_location" value="<?= $val('sub_location', $student['sub_location']) ?>"><?= $err('sub_location') ?></div>
      <div class="<?= $cls('village') ?>"><label for="vil">Village</label><input type="text" id="vil" name="village" value="<?= $val('village', $student['village']) ?>"><?= $err('village') ?></div>
    </div>
  <?php else: ?>
    <?php if ($children && !$student): ?>
      <div class="field<?= isset($errors['existing_student']) ? ' has-error' : '' ?>"><label for="ex">Apply for a student you added before <span class="hint">Or leave this and fill in a new student below</span></label>
        <select id="ex" name="existing_student"><option value="">— New student —</option><?php foreach ($children as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['first_name'] . ' ' . $c['last_name']) ?><?= $c['verified_at'] ? ' (verified)' : '' ?></option><?php endforeach; ?></select><?= $err('existing_student') ?></div>
    <?php endif; ?>
    <?php $s = $student ?? []; ?>
    <div class="grid-3">
      <div class="<?= $cls('first_name') ?>"><label for="fn">First name</label><input type="text" id="fn" name="first_name" value="<?= $val('first_name', $s['first_name'] ?? '') ?>"><?= $err('first_name') ?></div>
      <div class="<?= $cls('middle_name') ?>"><label for="mn">Middle name <span class="hint">Optional</span></label><input type="text" id="mn" name="middle_name" value="<?= $val('middle_name', $s['middle_name'] ?? '') ?>"><?= $err('middle_name') ?></div>
      <div class="<?= $cls('last_name') ?>"><label for="ln">Surname</label><input type="text" id="ln" name="last_name" value="<?= $val('last_name', $s['last_name'] ?? '') ?>"><?= $err('last_name') ?></div>
    </div>
    <div class="grid-2">
      <fieldset class="<?= $cls('gender') ?>"><legend>Gender</legend><div class="btn-row"><?php $gv = html_entity_decode($val('gender', $s['gender'] ?? '')); foreach (['female' => 'Female', 'male' => 'Male'] as $k => $l): ?><label class="check"><input type="radio" name="gender" value="<?= $k ?>"<?= checked($gv === $k) ?>><?= $l ?></label><?php endforeach; ?></div><?= $err('gender') ?></fieldset>
      <div class="<?= $cls('date_of_birth') ?>"><label for="dob">Date of birth</label><input type="date" id="dob" name="date_of_birth" value="<?= $val('date_of_birth', $s['date_of_birth'] ?? '') ?>"><?= $err('date_of_birth') ?></div>
      <div class="<?= $cls('birth_cert_no') ?>"><label for="bc">Birth certificate number</label><input type="text" id="bc" name="birth_cert_no" value="<?= $val('birth_cert_no', $s['birth_cert_no'] ?? '') ?>"><?= $err('birth_cert_no') ?></div>
      <div class="<?= $cls('upi_no') ?>"><label for="upi">NEMIS / UPI number <span class="hint">From the school, if known</span></label><input type="text" id="upi" name="upi_no" value="<?= $val('upi_no', $s['upi_no'] ?? '') ?>"><?= $err('upi_no') ?></div>
      <div class="<?= $cls('ward_id') ?>"><label for="ward">Ward (home)</label><select id="ward" name="ward_id"><option value="">Choose…</option><?php $wv = html_entity_decode($val('ward_id', $s['ward_id'] ?? '')); foreach ($wards as $w): ?><option value="<?= (int)$w['id'] ?>"<?= selected($wv, $w['id']) ?>><?= e($w['name']) ?></option><?php endforeach; ?></select><?= $err('ward_id') ?></div>
      <div class="<?= $cls('sub_location') ?>"><label for="sl">Sub-location</label><input type="text" id="sl" name="sub_location" value="<?= $val('sub_location', $s['sub_location'] ?? '') ?>"><?= $err('sub_location') ?></div>
      <div class="<?= $cls('village') ?>"><label for="vil">Village</label><input type="text" id="vil" name="village" value="<?= $val('village', $s['village'] ?? '') ?>"><?= $err('village') ?></div>
    </div>
    <label class="check"><input type="checkbox" name="has_disability" value="1"<?= checked(html_entity_decode($val('has_disability', $s['has_disability'] ?? '')) === '1') ?>>The student has a disability</label>
  <?php endif; ?>

<?php elseif ($step === 3): ?>
  <?php if ($levels): ?><p class="small muted">Amounts you may request this cycle:
    <?= e(implode(' · ', array_map(fn($l) => level_label($l['level']) . ' ' . money($l['min_amount']) . '–' . number_format((float)$l['max_amount']), $levels))) ?></p><?php endif; ?>
  <div class="grid-2">
    <div class="<?= $cls('level') ?>"><label for="lvl">Level of education</label><select id="lvl" name="level" data-filter-target="inst"><option value="">Choose…</option><?php $lv = html_entity_decode($val('level', $a['level'])); foreach ($levels as $l): ?><option value="<?= e($l['level']) ?>"<?= selected($lv, $l['level']) ?>><?= e(level_label($l['level'])) ?></option><?php endforeach; ?></select><?= $err('level') ?></div>
    <div class="<?= $cls('institution_id') ?>"><label for="inst">Institution <span class="hint">Not listed? Call the bursary office to have it added.</span></label><select id="inst" name="institution_id"><option value="">Choose…</option><?php $iv = html_entity_decode($val('institution_id', $a['institution_id'])); foreach ($institutions as $i): ?><option value="<?= (int)$i['id'] ?>" data-level="<?= e($i['level']) ?>"<?= selected($iv, $i['id']) ?>><?= e($i['name']) ?></option><?php endforeach; ?></select><?= $err('institution_id') ?></div>
    <div class="<?= $cls('class_year') ?>"><label for="cy">Class, form or year</label><input type="text" id="cy" name="class_year" placeholder="e.g. Form 3 or Year 2" value="<?= $val('class_year', $a['class_year']) ?>"><?= $err('class_year') ?></div>
    <div class="<?= $cls('admission_no') ?>"><label for="adm">Admission / registration number</label><input type="text" id="adm" name="admission_no" value="<?= $val('admission_no', $a['admission_no']) ?>"><?= $err('admission_no') ?></div>
    <div class="<?= $cls('annual_fees') ?>"><label for="af">Annual fees (KES)</label><input type="text" inputmode="numeric" id="af" name="annual_fees" value="<?= $val('annual_fees', $a['annual_fees'] !== null ? (int)$a['annual_fees'] : '') ?>"><?= $err('annual_fees') ?></div>
    <div class="<?= $cls('fee_balance') ?>"><label for="fb">Current fee balance (KES)</label><input type="text" inputmode="numeric" id="fb" name="fee_balance" value="<?= $val('fee_balance', $a['fee_balance'] !== null ? (int)$a['fee_balance'] : '') ?>"><?= $err('fee_balance') ?></div>
    <div class="<?= $cls('amount_requested') ?>"><label for="ar">Amount requested (KES)</label><input type="text" inputmode="numeric" id="ar" name="amount_requested" value="<?= $val('amount_requested', $a['amount_requested'] !== null ? (int)$a['amount_requested'] : '') ?>"><?= $err('amount_requested') ?></div>
  </div>
  <p class="small muted">Bursaries are paid directly to the institution, never to a person.</p>

<?php elseif ($step === 4): ?>
  <div class="grid-2">
    <div class="<?= $cls('parental_status') ?>"><label for="ps">Parents</label><select id="ps" name="parental_status"><option value="">Choose…</option><?php $pv = html_entity_decode($val('parental_status', $a['parental_status'])); foreach (['both_parents' => 'Both parents alive', 'single_parent' => 'Single parent', 'partial_orphan' => 'One parent deceased', 'total_orphan' => 'Both parents deceased', 'other' => 'Other'] as $k => $l): ?><option value="<?= $k ?>"<?= selected($pv, $k) ?>><?= $l ?></option><?php endforeach; ?></select><?= $err('parental_status') ?></div>
    <div class="<?= $cls('income_band') ?>"><label for="ib">Total monthly household income</label><select id="ib" name="income_band"><option value="">Choose…</option><?php $bv = html_entity_decode($val('income_band', $a['income_band'])); foreach (['none' => 'No regular income', 'below_5k' => 'Below KES 5,000', '5k_15k' => 'KES 5,000 – 15,000', '15k_30k' => 'KES 15,000 – 30,000', 'above_30k' => 'Above KES 30,000'] as $k => $l): ?><option value="<?= $k ?>"<?= selected($bv, $k) ?>><?= $l ?></option><?php endforeach; ?></select><?= $err('income_band') ?></div>
    <div class="<?= $cls('household_size') ?>"><label for="hs">People living in the household</label><input type="number" min="1" max="40" id="hs" name="household_size" value="<?= $val('household_size', $a['household_size']) ?>"><?= $err('household_size') ?></div>
    <div class="<?= $cls('siblings_in_school') ?>"><label for="sib">Other children in school or college</label><input type="number" min="0" max="30" id="sib" name="siblings_in_school" value="<?= $val('siblings_in_school', $a['siblings_in_school']) ?>"><?= $err('siblings_in_school') ?></div>
  </div>
  <div class="<?= $cls('special_circumstances') ?>"><label for="sc">Anything else the committee should know <span class="hint">Optional — illness, disability, disaster, loss of income</span></label><textarea id="sc" name="special_circumstances" maxlength="1500"><?= $val('special_circumstances', $a['special_circumstances']) ?></textarea><?= $err('special_circumstances') ?></div>

<?php elseif ($step === 5): ?>
  <p class="muted">Take clear photos in good light, or upload PDFs. Files up to <?= (int)$maxMb ?> MB. Photos are compressed automatically; stamps and signatures stay readable. Uploads resume if your connection drops.</p>
  <div class="panel panel-gold">
    <b>Chief’s recommendation form.</b> Only the form printed from this system is accepted — it carries a unique code and QR that the office checks. Forms typed or edited elsewhere will fail the check.
    <?php if (empty($missing_1to4 = array_intersect_key(applicant_missing($a), [1 => 1, 2 => 1, 3 => 1, 4 => 1]))): ?>
      <p style="margin:.6rem 0 0"><a class="btn btn-sm" href="/sheets/recommendation_form/<?= $id ?>">Print the recommendation form</a> <span class="small muted">Take it to your chief or assistant chief, then upload a photo of the signed and stamped form below.</span></p>
    <?php else: ?><p class="small" style="margin:.6rem 0 0">Complete steps 1–4 first; the form is printed with those details.</p><?php endif; ?>
  </div>
  <noscript><div class="flash flash-error">Uploading needs JavaScript. Please enable it or use another browser.</div></noscript>
  <?php foreach ($docTypes as $t): $have = $docs[$t['id']] ?? []; $ok = (bool)array_filter($have, fn($d) => $d['status'] !== 'rejected'); ?>
    <div class="upload-item<?= $ok ? ' ok' : '' ?>" data-upload data-app="<?= $id ?>" data-type="<?= (int)$t['id'] ?>" data-max="<?= (int)$maxMb * 1048576 ?>">
      <div class="meta"><b><?= e($t['name']) ?><?= $t['is_required'] ? '' : ' <span class="muted small">(optional)</span>' ?></b>
        <label class="btn btn-sm <?= $ok ? 'btn-quiet' : 'btn-line' ?> file-btn"><?= $ok ? 'Replace' : 'Choose file' ?><input type="file" accept="image/jpeg,image/png,image/webp,application/pdf" capture="environment"></label></div>
      <div class="small muted"><?= e($t['description']) ?></div>
      <?php foreach ($have as $d): ?><div class="small">📎 <?= e($d['original_name']) ?> · <?= ($d['status'] === 'pending' ? '<span class="badge badge-ok">Uploaded ✓</span>' : status_badge($d['status'])) ?><?= $d['status'] === 'rejected' ? ' — ' . e($d['rejection_reason']) : '' ?></div><?php endforeach; ?>
      <div class="progress"><i></i></div><div class="small upload-msg" aria-live="polite"></div>
    </div>
  <?php endforeach; ?>

<?php elseif ($step === 6): ?>
  <?php if ($missing): ?><div class="flash flash-error"><b>Still needed before you can submit:</b><ul><?php foreach ($missing as $n => $m): ?><li><a href="/portal/applications/<?= $id ?>/step/<?= $n ?>"><?= e($m) ?></a></li><?php endforeach; ?></ul></div><?php endif; ?>
  <div class="grid-2">
    <div><h3>Parent / guardian <a class="small" href="/portal/applications/<?= $id ?>/step/1">Edit</a></h3><dl class="facts"><dt>Name</dt><dd><?= e($a['guardian_name']) ?></dd><dt>Relationship</dt><dd><?= e(ucfirst((string)$a['guardian_relationship'])) ?></dd><dt>Mobile</dt><dd><?= e($a['guardian_phone']) ?></dd><dt>ID number</dt><dd><?= e($a['guardian_nid']) ?></dd></dl></div>
    <div><h3>Student <a class="small" href="/portal/applications/<?= $id ?>/step/2">Edit</a></h3><dl class="facts"><dt>Name</dt><dd><?= e(trim($a['first_name'] . ' ' . $a['middle_name'] . ' ' . $a['last_name'])) ?></dd><dt>Date of birth</dt><dd><?= e(fmt_date($a['date_of_birth'])) ?></dd><dt>Birth cert / UPI</dt><dd><?= e(($a['birth_cert_no'] ?: '—') . ' / ' . ($a['upi_no'] ?: '—')) ?></dd><dt>Home</dt><dd><?= e($a['village'] . ', ' . $a['sub_location'] . ', ' . $a['ward_name']) ?></dd></dl></div>
    <div><h3>Education <a class="small" href="/portal/applications/<?= $id ?>/step/3">Edit</a></h3><dl class="facts"><dt>Institution</dt><dd><?= e($a['institution_name']) ?></dd><dt>Level / class</dt><dd><?= e(level_label($a['level']) . ', ' . $a['class_year']) ?></dd><dt>Admission no.</dt><dd><?= e($a['admission_no']) ?></dd><dt>Annual fees</dt><dd><?= money($a['annual_fees']) ?></dd><dt>Fee balance</dt><dd><?= money($a['fee_balance']) ?></dd><dt>Requested</dt><dd><b><?= money($a['amount_requested']) ?></b></dd></dl></div>
    <div><h3>Household <a class="small" href="/portal/applications/<?= $id ?>/step/4">Edit</a></h3><dl class="facts"><dt>Parents</dt><dd><?= e(ucfirst(str_replace('_', ' ', (string)$a['parental_status']))) ?></dd><dt>Household size</dt><dd><?= e($a['household_size']) ?></dd><dt>Others in school</dt><dd><?= e($a['siblings_in_school']) ?></dd><dt>Income</dt><dd><?= e(str_replace('_', ' ', (string)$a['income_band'])) ?></dd></dl></div>
  </div>
  <h3>Documents <a class="small" href="/portal/applications/<?= $id ?>/step/5">Edit</a></h3>
  <ul><?php foreach ($docTypes as $t): $have = $docs[$t['id']] ?? []; ?><li><?= e($t['name']) ?>: <?= $have ? e(count($have) . ' file(s)') : '<span class="muted">none</span>' ?></li><?php endforeach; ?></ul>
<?php endif; ?>

  <div class="savebar">
    <span class="autosave" aria-live="polite"><?= $step <= 4 ? 'Changes save automatically as you type.' : '' ?></span>
    <div class="btn-row">
      <button class="btn btn-quiet" name="go" value="exit">Save and exit</button>
      <?php if (!($step === 6 && $missing)): ?><button class="btn" name="go" value="next">Save and continue</button><?php endif; ?>
    </div>
  </div>
</form>

<?php else: ?>
<form method="post" action="/portal/applications/<?= $id ?>/submit" class="panel" data-confirm="Submit this application now? You will not be able to change it unless an officer returns it to you.">
  <?= csrf_field() ?>
  <?php if (!empty($missing)): ?><div class="flash flash-error">Complete these first: <?php foreach ($missing as $n => $m): ?><a href="/portal/applications/<?= $id ?>/step/<?= $n ?>"><?= e($m) ?></a>. <?php endforeach; ?></div><?php endif; ?>
  <p>Before submitting, read and confirm each statement.</p>
  <?php if (isset($errors['declaration'])): ?><div class="flash flash-error"><?= e($errors['declaration']) ?></div><?php endif; ?>
  <div class="choice-list">
    <label class="check"><input type="checkbox" name="declaration_true" value="1">I confirm that the information and documents in this application are true and complete.</label>
    <label class="check"><input type="checkbox" name="declaration_consent" value="1">I agree that the bursary office may verify this information with the school, the local administration and by a home visit, and may keep the records as the law requires.</label>
    <label class="check"><input type="checkbox" name="declaration_fraud" value="1">I understand that false information or forged documents lead to disqualification, recovery of funds and possible prosecution, and that no officer may ask me for money.</label>
  </div>
  <div class="savebar"><a href="/portal/applications/<?= $id ?>/step/6" class="btn btn-quiet">Back to review</a>
    <button class="btn btn-gold"<?= !empty($missing) ? ' disabled' : '' ?>><?= $a['status'] === 'returned' ? 'Resubmit application' : 'Submit application' ?></button></div>
</form>
<?php endif; ?>

<?php if ($a['status'] === 'draft' && !$a['reference']): ?>
<form method="post" action="/portal/applications/<?= $id ?>/delete-draft" data-confirm="Delete this draft? This cannot be undone."><?= csrf_field() ?><button class="btn btn-sm btn-quiet">Delete this draft</button></form>
<?php endif; ?>
