<div class="panel-head welcome"><div><p class="eyebrow eyebrow-gold">Family portal</p><h1>Hello, <?= e(explode(' ', $u['full_name'])[0]) ?></h1><p class="muted"><?= $u['account_type'] === 'parent' ? 'Apply for your children and follow every application here.' : 'Follow your applications and support here.' ?></p></div>
<?php if ($cycle): ?>
  <form method="post" action="/portal/apply"><?= csrf_field() ?><button class="btn btn-gold">+ Start a new application</button></form>
<?php endif; ?>
</div>

<?php if ($cycle): ?>
  <div class="panel panel-gold"><b><?= e($cycle['name']) ?> is open.</b> Applications close on <?= e(fmt_date($cycle['closes_at'], 'j M Y, g:ia')) ?>. Drafts save automatically — you can finish later.</div>
<?php else: ?>
  <div class="panel panel-gold">Applications are closed right now. See the <a href="/application-period">application period</a> for the next cycle. You can still follow earlier applications below.</div>
<?php endif; ?>

<?php if ($continuable): ?>
<div class="panel">
  <h2>Continued support</h2>
  <p class="muted">These students were supported or applied before. We reuse their verified details — you only confirm what changed.</p>
  <?php foreach ($continuable as $c): ?>
    <form method="post" action="/portal/apply" class="btn-row" style="margin-bottom:.5rem"><?= csrf_field() ?>
      <input type="hidden" name="continue_from" value="<?= (int)$c['id'] ?>">
      <span><b><?= e($c['first_name'] . ' ' . $c['last_name']) ?></b> <span class="muted small">last: <?= e($c['reference']) ?></span></span>
      <button class="btn btn-sm btn-line">Apply for this cycle</button>
    </form>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<div class="panel">
  <h2>Applications</h2>
  <?php if (!$apps): ?>
    <div class="empty"><p>No applications yet.</p><?php if ($cycle): ?><p>Press <b>Start a new application</b>. It takes about 15 minutes; have the school ID, fee statement and chief’s recommendation ready.</p><?php endif; ?></div>
  <?php else: ?>
  <div class="table-wrap"><table class="cards">
    <thead><tr><th>Student</th><th>Reference</th><th>Cycle</th><th>Status</th><th class="r">Approved</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($apps as $a): if ($a['status'] === 'withdrawn') continue; ?>
      <tr>
        <td data-label="Student"><?= e(trim(($a['first_name'] ?? '') . ' ' . ($a['last_name'] ?? '')) ?: 'Not yet entered') ?><div class="small muted"><?= e($a['institution_name'] ?? '') ?></div></td>
        <td data-label="Reference" class="num"><?= e($a['reference'] ?? '—') ?></td>
        <td data-label="Cycle"><?= e($a['cycle_name']) ?></td>
        <td data-label="Status"><?= status_badge($a['status']) ?></td>
        <td data-label="Approved" class="r"><?= money($a['amount_approved']) ?></td>
        <td><?php if (in_array($a['status'], ['draft', 'returned'], true) && (int)$a['applicant_user_id'] === (int)$u['id']): ?>
          <a class="btn btn-sm" href="/portal/applications/<?= (int)$a['id'] ?>/step/<?= (int)$a['wizard_step'] ?>"><?= $a['status'] === 'returned' ? 'Fix and resubmit' : 'Continue' ?></a>
        <?php else: ?><a class="btn btn-sm btn-quiet" href="/portal/applications/<?= (int)$a['id'] ?>">Track</a><?php endif; ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody></table></div>
  <?php endif; ?>
</div>

<?php if ($notes): ?>
<div class="panel"><div class="panel-head"><h2>Latest messages</h2><a href="/portal/notifications">All messages</a></div>
  <ul class="timeline"><?php foreach ($notes as $n): ?><li><time><?= e(fmt_date($n['created_at'], 'j M, g:ia')) ?></time><b><?= e($n['title']) ?></b><br><span class="small"><?= e($n['body']) ?></span></li><?php endforeach; ?></ul>
</div>
<?php endif; ?>
