<?php
$id = (int)$a['id'];
$stages = [
    ['Submitted', ['submitted', 'returned']], ['Document check', ['verification']], ['Verification', ['field_verification', 'committee_review']],
    ['Committee review', ['recommended']], ['Decision', ['approved', 'partially_approved', 'not_approved', 'ready_for_payment', 'payment_processing', 'payment_failed']],
    ['Paid to institution', ['disbursed', 'closed']],
];
$order = ['draft' => -1, 'submitted' => 0, 'returned' => 0, 'verification' => 1, 'field_verification' => 2, 'committee_review' => 2, 'recommended' => 3,
    'approved' => 4, 'partially_approved' => 4, 'not_approved' => 4, 'ready_for_payment' => 4, 'payment_processing' => 4, 'payment_failed' => 4, 'disbursed' => 5, 'closed' => 6, 'withdrawn' => -1];
$pos = $order[$a['status']] ?? 0;
$sheetBy = array_column($sheets, null, 'kind');
?>
<p class="crumbs"><a href="/portal">Applications</a> › <?= e($a['reference'] ?? 'Draft') ?></p>
<div class="panel-head">
  <div><h1><?= e(trim($a['first_name'] . ' ' . $a['last_name']) ?: 'Draft application') ?></h1>
  <p class="muted"><?= e($a['reference'] ?? 'Not yet submitted') ?> · <?= e($a['cycle_name']) ?><?= $a['institution_name'] ? ' · ' . e($a['institution_name']) : '' ?></p></div>
  <?= status_badge($a['status']) ?>
</div>

<div class="two-col">
<div>
  <div class="panel <?= $a['status'] === 'returned' ? 'panel-alert' : 'panel-gold' ?>">
    <h2>What happens next</h2>
    <p><?= e(Workflow::nextStep($a)) ?></p>
    <?php if ($a['status'] === 'returned' && $a['return_reason']): ?><p><b>Officer’s note:</b> <?= e($a['return_reason']) ?></p><?php endif; ?>
    <?php if ($isOwner && in_array($a['status'], ['draft', 'returned'], true)): ?><a class="btn" href="/portal/applications/<?= $id ?>/step/<?= (int)$a['wizard_step'] ?>"><?= $a['status'] === 'returned' ? 'Update and resubmit' : 'Continue application' ?></a><?php endif; ?>
  </div>

  <?php if ($a['status'] !== 'draft'): ?>
  <div class="journey" style="margin-bottom:1.25rem">
    <div class="journey-head"><b>Progress</b><span class="small muted">Updated <?= e(fmt_date($a['updated_at'], 'j M, g:ia')) ?></span></div>
    <ol>
    <?php foreach ($stages as $i => [$label]): $cls = $a['status'] === 'not_approved' && $i === 4 ? 'now' : ($i < $pos ? 'done' : ($i === $pos ? 'now' : '')); ?>
      <li class="<?= $cls ?>"><span class="dot"><?= $i < $pos ? '✓' : $i + 1 ?></span><div><strong><?= e($label) ?></strong><?php if ($i === $pos || ($a['status'] === 'not_approved' && $i === 4)): ?><small><?= e(status_label($a['status'])) ?></small><?php endif; ?></div></li>
    <?php endforeach; ?>
    </ol>
  </div>

  <div class="amounts">
    <div><span>Requested</span><b><?= money($a['amount_requested']) ?></b></div>
    <div><span>Recommended</span><b><?= in_array($a['status'], ['approved','partially_approved','ready_for_payment','payment_processing','disbursed','closed','not_approved'], true) ? money($a['amount_recommended']) : '—' ?></b></div>
    <div><span>Approved</span><b><?= money($a['amount_approved']) ?></b></div>
    <div><span>Paid</span><b><?= money($a['amount_paid']) ?></b></div>
  </div>
  <?php endif; ?>

  <div class="panel"><h2>History</h2>
    <ul class="timeline"><?php foreach ($history as $h): ?>
      <li><time><?= e(fmt_date($h['created_at'], 'j M Y, g:ia')) ?></time><?= e(ucfirst(str_replace('_', ' ', $h['action']))) ?><?= $h['to_status'] && $h['to_status'] !== $h['from_status'] ? ' → ' . e(status_label($h['to_status'])) : '' ?><?= $h['comment'] ? '<div class="small muted">' . e($h['comment']) . '</div>' : '' ?></li>
    <?php endforeach; ?></ul>
  </div>
</div>

<div>
  <?php if ($a['reference']): ?>
  <div class="panel">
    <h2>Official sheets</h2>
    <p class="small muted">Sealed by the system with a unique code and QR. Anyone can check them at <a href="/verify">/verify</a>. Print or save as PDF from the sheet.</p>
    <div class="stack">
      <a class="btn btn-line" href="/sheets/application_receipt/<?= $id ?>">Application receipt</a>
      <?php if (in_array($a['status'], ['approved','partially_approved','ready_for_payment','payment_processing','payment_failed','disbursed','closed'], true)): ?><a class="btn btn-gold" href="/sheets/award_letter/<?= $id ?>">Award letter</a><?php endif; ?>
      <?php if ((float)$a['amount_paid'] > 0): ?><a class="btn btn-line" href="/sheets/support_statement/<?= $id ?>">Support statement</a><?php endif; ?>
    </div>
  </div>
  <?php endif; ?>

  <?php if ($payment): ?>
  <div class="panel"><h2>Payment</h2><dl class="facts"><dt>Status</dt><dd><?= status_badge($payment['status']) ?></dd><dt>Amount</dt><dd><?= money($payment['amount']) ?></dd>
    <?php if ($payment['status'] === 'paid'): ?><dt>Paid on</dt><dd><?= e(fmt_date($payment['paid_on'])) ?></dd><dt>Reference</dt><dd class="num"><?= e($payment['payment_reference']) ?></dd><?php endif; ?></dl>
    <p class="small muted" style="margin-top:.75rem">Paid directly to <?= e($a['institution_name']) ?>. Ask the institution’s bursar to confirm it on your fee statement.</p></div>
  <?php endif; ?>

  <?php if ($docs): ?>
  <div class="panel"><h2>Documents</h2>
    <ul class="timeline"><?php foreach ($docs as $d): ?><li><?= e($d['name']) ?> <?= status_badge($d['status'] === 'pending' ? 'submitted' : $d['status']) ?><?= $d['status'] === 'rejected' ? '<div class="small">' . e($d['rejection_reason']) . '</div>' : '' ?></li><?php endforeach; ?></ul></div>
  <?php endif; ?>

  <?php if ($isOwner && $a['student_access_code'] && $a['reference']): ?>
  <div class="panel"><h2>Student access</h2><p class="small">The student can create their own account and link this record with reference <b><?= e($a['reference']) ?></b> and code <b class="num"><?= e($a['student_access_code']) ?></b>.</p></div>
  <?php endif; ?>

  <div class="panel"><p class="small">No officer may ask for money. If anyone does, <a href="/report-concern">report it confidentially</a>.</p></div>
</div>
</div>
