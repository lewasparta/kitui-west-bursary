<h1>Support history</h1>
<p class="muted">Every submitted application and what was approved and paid. Requested, approved and paid amounts are shown separately.</p>
<?php if (!$rows): ?><div class="panel empty">No submitted applications yet.</div><?php else:
$by = []; foreach ($rows as $r) { $by[$r['student_id']][] = $r; } ?>
<?php foreach ($by as $list): $paid = array_sum(array_column($list, 'amount_paid')); ?>
<div class="panel">
  <div class="panel-head"><h2><?= e($list[0]['first_name'] . ' ' . $list[0]['last_name']) ?></h2><span>Total paid: <b><?= money($paid) ?></b></span></div>
  <div class="table-wrap"><table class="cards"><thead><tr><th>Cycle</th><th>Reference</th><th>Institution</th><th>Status</th><th class="r">Requested</th><th class="r">Approved</th><th class="r">Paid</th></tr></thead><tbody>
  <?php foreach ($list as $r): ?>
    <tr><td data-label="Cycle"><?= e($r['cycle_name']) ?></td><td data-label="Reference"><a href="/portal/applications/<?= (int)$r['id'] ?>"><?= e($r['reference']) ?></a></td>
    <td data-label="Institution"><?= e($r['institution_name']) ?></td><td data-label="Status"><?= status_badge($r['status']) ?></td>
    <td data-label="Requested" class="r"><?= money($r['amount_requested']) ?></td><td data-label="Approved" class="r"><?= money($r['amount_approved']) ?></td><td data-label="Paid" class="r"><?= money($r['amount_paid']) ?></td></tr>
  <?php endforeach; ?>
  </tbody></table></div>
  <?php $last = end($list); if ((float)$paid > 0): ?><p style="margin-top:1rem"><a class="btn btn-sm btn-line" href="/sheets/support_statement/<?= (int)$last['id'] ?>">Sealed support statement</a></p><?php endif; ?>
</div>
<?php endforeach; endif; ?>
