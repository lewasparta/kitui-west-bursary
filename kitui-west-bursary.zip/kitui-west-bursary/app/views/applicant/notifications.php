<h1>Messages</h1>
<p class="muted">Messages about your applications. Important ones are also sent by SMS.</p>
<div class="panel">
<?php if (!$p['rows']): ?><div class="empty">No messages yet.</div><?php else: ?>
  <ul class="timeline"><?php foreach ($p['rows'] as $n): ?>
    <li><time><?= e(fmt_date($n['created_at'], 'j M Y, g:ia')) ?></time><b><?= e($n['title']) ?></b><?= $n['read_at'] ? '' : ' <span class="badge badge-progress">New</span>' ?><br><?= e($n['body']) ?><?php if ($n['link']): ?> <a href="<?= e($n['link']) ?>">Open</a><?php endif; ?></li>
  <?php endforeach; ?></ul>
<?php endif; ?>
</div>
<?= partial('pager', ['p' => $p]) ?>
