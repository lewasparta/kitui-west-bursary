<p class="crumbs"><a href="/staff/mentorship">Mentorship</a> › Attendance</p>
<h1><?= e($e['title']) ?></h1>
<p class="muted"><?= e($e['program_title']) ?> · <?= e(fmt_date($e['starts_at'], 'D j M Y, g:i a')) ?> · <?= e($e['venue']) ?></p>
<?php if (!$rows): ?><div class="panel empty">Nobody has registered yet.</div><?php else: ?>
<form method="post" action="/staff/mentorship/events/<?= (int)$e['id'] ?>" class="panel"><?= csrf_field() ?>
<div class="table-wrap"><table class="cards"><thead><tr><th><input type="checkbox" data-check-all aria-label="Mark all present"></th><th>Name</th><th>Account</th><th>Phone</th><th>Feedback</th></tr></thead><tbody>
<?php foreach ($rows as $r): ?>
<tr><td><input type="checkbox" name="present[]" value="<?= (int)$r['id'] ?>" <?= checked($r['attended']) ?> aria-label="Present"></td>
<td data-label="Name"><?= e($r['full_name']) ?></td><td data-label="Account"><?= e(ucfirst($r['account_type'])) ?></td>
<td data-label="Phone"><?= e(mask_phone($r['phone'])) ?></td>
<td data-label="Feedback"><?= $r['feedback_rating'] ? str_repeat('★', (int)$r['feedback_rating']) . ' ' . e((string)$r['feedback_comment']) : '—' ?></td></tr>
<?php endforeach; ?>
</tbody></table></div>
<button class="btn">Save attendance</button>
</form>
<?php endif; ?>
