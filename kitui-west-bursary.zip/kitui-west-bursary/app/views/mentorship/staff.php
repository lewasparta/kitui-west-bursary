<div class="panel-head"><h1>Mentorship events</h1><?php if (Auth::has('admin')): ?><div class="btn-row"><a class="btn btn-sm btn-line" href="/admin/r/programs">Programmes</a><a class="btn btn-sm" href="/admin/r/events/new">New event</a></div><?php endif; ?></div>
<?php if (!$events): ?><div class="panel empty">No events yet.</div><?php else: ?>
<div class="table-wrap"><table class="cards"><thead><tr><th>Event</th><th>Programme</th><th>Date</th><th class="r">Registered</th><th class="r">Attended</th><th class="r">Rating</th><th></th></tr></thead><tbody>
<?php foreach ($events as $ev): ?>
<tr><td data-label="Event"><?= e($ev['title']) ?><div class="small muted"><?= e($ev['venue']) ?></div></td>
<td data-label="Programme"><?= e($ev['program_title']) ?></td>
<td data-label="Date"><?= e(fmt_date($ev['starts_at'], 'j M Y, g:i a')) ?></td>
<td data-label="Registered" class="r"><?= (int)$ev['registered'] ?> / <?= (int)$ev['capacity'] ?></td>
<td data-label="Attended" class="r"><?= (int)$ev['attended'] ?></td>
<td data-label="Rating" class="r"><?= $ev['rating'] ? e($ev['rating']) . ' ★' : '—' ?></td>
<td><a class="btn btn-sm" href="/staff/mentorship/events/<?= (int)$ev['id'] ?>">Attendance</a></td></tr>
<?php endforeach; ?>
</tbody></table></div>
<?php endif; ?>
