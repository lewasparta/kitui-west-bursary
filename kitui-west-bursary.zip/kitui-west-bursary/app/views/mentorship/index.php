<div class="page-head"><h1>Mentorship &amp; student development</h1>
<p class="muted">Free, optional sessions for students and parents. Taking part never affects bursary decisions.</p></div>

<h2>Upcoming events</h2>
<?php if (!$events): ?><div class="panel empty">No upcoming events yet. New sessions are announced here and by SMS.</div><?php else: ?>
<div class="grid-2">
<?php foreach ($events as $ev): $full = (int)$ev['registered'] >= (int)$ev['capacity']; ?>
  <div class="panel feature">
    <span class="badge badge-muted"><?= e(MENTOR_CATEGORIES[$ev['category']] ?? $ev['category']) ?></span>
    <h3><?= e($ev['title']) ?></h3>
    <p class="small muted"><?= e(fmt_date($ev['starts_at'], 'D j M Y, g:i a')) ?> · <?= e($ev['venue']) ?></p>
    <p class="small"><?= e(mb_strimwidth($ev['description'], 0, 180, '…')) ?></p>
    <p class="small muted"><?= max(0, (int)$ev['capacity'] - (int)$ev['registered']) ?> place(s) left</p>
    <?php if ($ev['my_reg']): ?><span class="badge badge-ok">You are registered</span>
    <?php elseif ($full): ?><span class="badge badge-bad">Full</span>
    <?php else: ?><form method="post" action="/mentorship/events/<?= (int)$ev['id'] ?>/register"><?= csrf_field() ?><button class="btn btn-sm">Register</button></form><?php endif; ?>
  </div>
<?php endforeach; ?>
</div>
<?php endif; ?>

<?php if ($mine): ?>
<h2>My sessions</h2>
<div class="table-wrap"><table class="cards"><thead><tr><th>Event</th><th>Date</th><th>Attendance</th><th>Feedback</th></tr></thead><tbody>
<?php foreach ($mine as $r): $past = strtotime($r['starts_at']) <= time(); ?>
<tr><td data-label="Event"><?= e($r['title']) ?><div class="small muted"><?= e($r['venue']) ?></div></td>
<td data-label="Date"><?= e(fmt_date($r['starts_at'], 'j M Y, g:i a')) ?></td>
<td data-label="Attendance"><?= $r['attended'] === null ? '<span class="muted">—</span>' : ($r['attended'] ? '<span class="badge badge-ok">Attended</span>' : '<span class="badge badge-muted">Absent</span>') ?></td>
<td data-label="Feedback">
<?php if ($r['feedback_rating']): ?><?= str_repeat('★', (int)$r['feedback_rating']) . str_repeat('☆', 5 - (int)$r['feedback_rating']) ?>
<?php elseif ($past): ?>
  <form method="post" action="/mentorship/registrations/<?= (int)$r['id'] ?>/feedback" class="btn-row"><?= csrf_field() ?>
    <select name="rating" aria-label="Rating" required><option value="">Rate…</option><?php for ($i = 5; $i >= 1; $i--): ?><option value="<?= $i ?>"><?= $i ?> ★</option><?php endfor; ?></select>
    <input name="comment" maxlength="500" placeholder="What was useful?" aria-label="Comment">
    <button class="btn btn-sm btn-line">Send</button></form>
<?php else: ?><span class="small muted">After the event</span><?php endif; ?>
</td></tr>
<?php endforeach; ?>
</tbody></table></div>
<?php endif; ?>

<h2>Programmes</h2>
<div class="grid-3">
<?php foreach ($programs as $p): ?><div class="panel"><span class="badge badge-muted"><?= e(MENTOR_CATEGORIES[$p['category']] ?? '') ?></span><h3><?= e($p['title']) ?></h3><p class="small"><?= e($p['description']) ?></p></div><?php endforeach; ?>
</div>
