<?php
$u = Auth::user();
$roles = Auth::roles();
$current = current_path();
$links = [];
if ($u && $u['account_type'] !== 'staff') {
    $links = ['/portal' => ['Applications', 'clipboard'], '/portal/history' => ['Support history', 'coin'], '/mentorship' => ['Mentorship', 'book'], '/portal/notifications' => ['Messages', 'bell'], '/portal/profile' => ['Profile', 'user']];
} elseif ($u) {
    $links['/staff'] = ['Dashboard', 'home'];
    if (array_intersect(['doc_officer', 'ward_officer', 'committee', 'approver', 'auditor'], $roles)) { $links['/staff/search'] = ['Find application', 'search']; }
    if (in_array('committee', $roles, true) || in_array('approver', $roles, true)) { $links['/staff/committee'] = ['Committee', 'stamp']; }
    if (in_array('finance', $roles, true)) { $links['/finance'] = ['Finance', 'bank']; }
    if (in_array('auditor', $roles, true)) { $links['/audit'] = ['Audit', 'eye']; $links['/audit/concerns'] = ['Concerns', 'flag']; if (!in_array('finance', $roles, true)) { $links['/finance'] = ['Payments', 'bank']; } }
    if (array_intersect(['admin', 'ward_officer'], $roles)) { $links['/staff/mentorship'] = ['Mentorship', 'book']; }
    if (array_intersect(['admin', 'auditor', 'finance', 'approver', 'committee'], $roles)) { $links['/reports'] = ['Reports', 'chart']; }
    if (in_array('admin', $roles, true)) { $links['/admin'] = ['Administration', 'cog']; }
}
$unread = $u ? (int)DB::val('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND read_at IS NULL', [$u['id']]) : 0;
$roleNames = $u ? implode(', ', array_map(fn($r) => (string)DB::val('SELECT name FROM roles WHERE slug=?', [$r]), $roles)) : '';
$initials = $u ? strtoupper(implode('', array_map(fn($w) => mb_substr($w, 0, 1), array_slice(preg_split('/\s+/', trim(preg_replace('/\(.*\)/', '', $u['full_name']))), 0, 2)))) : '';
$isActive = fn($href) => $current === $href || ($href !== '/staff' && $href !== '/portal' && str_starts_with($current, $href . '/')) || ($href === '/portal' && str_starts_with($current, '/portal/applications'));
?><!doctype html>
<html lang="<?= e($_SESSION['lang'] ?? 'en') ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="app-base" content="<?= e(BASE_URL) ?>">
<meta name="csrf-token" content="<?= e(csrf_token()) ?>">
<title><?= e(($title ?? 'Dashboard')) ?> | Kitui West Bursary</title>
<meta name="theme-color" content="#0b3d26">
<meta name="robots" content="noindex">
<link rel="icon" href="<?= asset('img/logo.svg') ?>" type="image/svg+xml">
<link rel="stylesheet" href="<?= asset('css/app.css') ?>">
<script src="<?= asset('js/app.js') ?>" defer></script>
<?php if (!empty($qr)): ?><script src="<?= asset('js/qrcode.js') ?>" defer></script><?php endif; ?>
</head>
<body class="shell">
<a class="skip" href="#main">Skip to content</a>
<input type="checkbox" id="side-toggle" class="sr side-toggle">
<aside class="side" aria-label="Sections">
  <a class="side-brand" href="<?= Auth::homeFor() ?>"><img src="<?= asset('img/logo.svg') ?>" alt="" width="40" height="40"><div><b>Kitui West Bursary</b><span><?= $u && $u['account_type'] === 'staff' ? 'Staff workspace' : 'Family portal' ?></span></div></a>
  <nav class="side-nav">
    <?php foreach ($links as $href => [$label, $ico]): ?>
      <a href="<?= $href ?>"<?= $isActive($href) ? ' aria-current="page"' : '' ?>><?= icon($ico) ?><span><?= e($label) ?></span><?php if ($href === '/portal/notifications' && $unread): ?><em class="count"><?= $unread ?></em><?php endif; ?></a>
    <?php endforeach; ?>
  </nav>
  <div class="side-foot">
    <?php if ($u && $u['account_type'] === 'staff' && !$u['totp_enabled']): ?><a class="side-warn" href="/account/2fa"><?= icon('lock') ?> Turn on two-step login</a><?php endif; ?>
    <a href="/account/password"><?= icon('lock') ?><span>Change password</span></a>
    <a href="/"><?= icon('home') ?><span>Public website</span></a>
  </div>
  <div class="side-hills" aria-hidden="true"></div>
</aside>
<label for="side-toggle" class="side-scrim" aria-hidden="true"></label>
<div class="shell-main">
  <header class="topbar">
    <label for="side-toggle" class="side-btn" title="Menu"><span class="burger" aria-hidden="true"></span><span class="sr">Menu</span></label>
    <div class="topbar-title"><?= e($title ?? '') ?></div>
    <?php if ($u): ?>
      <?php if ($u['account_type'] !== 'staff'): ?><a class="bell" href="/portal/notifications" title="Messages"><?= icon('bell') ?><?php if ($unread): ?><em class="count"><?= $unread ?></em><?php endif; ?></a><?php endif; ?>
      <div class="me"><span class="avatar"><?= e($initials) ?></span><div><b><?= e($u['full_name']) ?></b><small><?= e($roleNames ?: ucfirst($u['account_type'])) ?></small></div></div>
      <form method="post" action="/logout" class="inline"><?= csrf_field() ?><button class="btn btn-sm btn-quiet" title="Log out"><?= icon('logout') ?><span class="hide-sm">Log out</span></button></form>
    <?php endif; ?>
  </header>
  <div class="seal-band" aria-hidden="true"></div>
  <main id="main" class="app-main"><div class="wrap">
  <?php foreach (take_flash() as [$type, $msg]): ?>
    <div class="flash flash-<?= e($type) ?>" role="status"><?= e($msg) ?></div>
  <?php endforeach; ?>
  <?= $content ?>
  </div></main>
</div>
</body>
</html>
