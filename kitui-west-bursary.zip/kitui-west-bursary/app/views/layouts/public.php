<?php
$current = current_path();
$nav = ['/how-it-works' => t('nav.how'), '/eligibility' => t('nav.eligibility'), '/application-period' => t('nav.period'),
    '/faqs' => 'FAQs', '/transparency' => t('nav.transparency'), '/contact' => t('nav.contact')];
$me = Auth::user();
?><!doctype html>
<html lang="<?= e($_SESSION['lang'] ?? 'en') ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="app-base" content="<?= e(BASE_URL) ?>">
<title><?= e(($title ?? '') ? $title . ' | ' : '') ?>Kitui West Digital Bursary</title>
<meta name="description" content="Apply for the Kitui West bursary online, track your application and see how funds are shared.">
<meta name="theme-color" content="#0b3d26">
<link rel="icon" href="<?= asset('img/logo.svg') ?>" type="image/svg+xml">
<link rel="stylesheet" href="<?= asset('css/app.css') ?>">
<?php if (!empty($qr)): ?><script src="<?= asset('js/qrcode.js') ?>" defer></script><?php endif; ?>
<script src="<?= asset('js/app.js') ?>" defer></script>
</head>
<body class="site">
<a class="skip" href="#main">Skip to content</a>
<div class="topline">
  <div class="wrap topline-in">
    <span class="topline-badge"><?= icon('shield') ?> Official bursary portal · Kitui West Constituency</span>
    <span class="topline-links">
      <a href="tel:<?= e(preg_replace('/\s+/', '', setting('contact_phone'))) ?>"><?= icon('phone') ?> <?= e(setting('contact_phone')) ?></a>
      <a href="/lang/<?= ($_SESSION['lang'] ?? 'en') === 'sw' ? 'en' : 'sw' ?>"><?= ($_SESSION['lang'] ?? 'en') === 'sw' ? 'English' : 'Kiswahili' ?></a>
      <a class="topline-alert" href="/report-concern"><?= icon('flag') ?> <?= e(t('nav.concern')) ?></a>
    </span>
  </div>
</div>
<header class="site-head">
  <div class="wrap bar">
    <a class="brand" href="/"><img src="<?= asset('img/logo.svg') ?>" alt="" width="46" height="46"><div><b>Kitui West Bursary</b><span>Transparent Support. Brighter Futures.</span></div></a>
    <input type="checkbox" id="nav-toggle" class="nav-toggle sr">
    <label for="nav-toggle" class="nav-btn"><span class="burger" aria-hidden="true"></span> Menu</label>
    <nav class="site-nav" aria-label="Main">
      <?php foreach ($nav as $href => $label): ?>
        <a href="<?= $href ?>"<?= $current === $href ? ' aria-current="page"' : '' ?>><?= e($label) ?></a>
      <?php endforeach; ?>
      <span class="nav-cta">
      <?php if ($me): ?>
        <a class="btn btn-sm btn-gold" href="<?= Auth::homeFor() ?>"><?= icon('user') ?> My dashboard</a>
      <?php else: ?>
        <a class="btn btn-sm btn-ghost" href="/login">Log in</a>
        <a class="btn btn-sm btn-gold" href="/register">Apply now</a>
      <?php endif; ?>
      </span>
    </nav>
  </div>
</header>
<main id="main">
<?php foreach (take_flash() as [$type, $msg]): ?>
  <div class="wrap"><div class="flash flash-<?= e($type) ?>" role="status"><?= e($msg) ?></div></div>
<?php endforeach; ?>
<?= $content ?>
</main>
<footer class="site-foot">
  <div class="foot-hills" aria-hidden="true"></div>
  <div class="wrap">
    <div class="foot-grid">
      <div class="foot-brand">
        <a class="brand brand-light" href="/"><img src="<?= asset('img/logo.svg') ?>" alt="" width="46" height="46"><div><b>Kitui West Bursary</b><span>Transparent Support. Brighter Futures.</span></div></a>
        <p>Bursary support for students from Mutonguni, Kauwi, Matinyani and Kwa Mutonga/Kithumula — applied for, reviewed and paid in the open.</p>
      </div>
      <div><h3>Apply</h3><ul>
        <li><a href="/how-it-works">How it works</a></li><li><a href="/eligibility">Who can apply</a></li>
        <li><a href="/application-period">Application dates</a></li><li><a href="/register">Create an account</a></li><li><a href="/login">Track an application</a></li></ul></div>
      <div><h3>Accountability</h3><ul>
        <li><a href="/transparency">Transparency dashboard</a></li><li><a href="/verify">Check a document</a></li>
        <li><a href="/report-concern">Report a concern</a></li><li><a href="/report-concern/track">Track a concern</a></li><li><a href="/about">About the fund</a></li><li><a href="/privacy">Privacy notice</a></li></ul></div>
      <div><h3>Visit or call</h3>
        <p><?= icon('map') ?> <?= e(setting('office_address')) ?><br><?= icon('phone') ?> <?= e(setting('contact_phone')) ?><br><?= icon('sms') ?> <a href="mailto:<?= e(setting('contact_email')) ?>"><?= e(setting('contact_email')) ?></a></p>
        <p><a href="/faqs">Questions? Read the FAQs</a></p></div>
    </div>
    <div class="foot-note">
      <p><?= icon('alert') ?> <b>Applying is free.</b> No officer may ask for money. Bursaries are paid only to institutions, never in cash.</p>
      <p class="fine">&copy; <?= date('Y') ?> Kitui West Digital Bursary · <a href="/lang/en">English</a> · <a href="/lang/sw">Kiswahili</a></p>
    </div>
  </div>
</footer>
</body>
</html>
