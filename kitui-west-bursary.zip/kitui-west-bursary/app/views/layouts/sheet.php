<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="app-base" content="<?= e(BASE_URL) ?>">
<meta name="robots" content="noindex">
<title><?= e($title) ?> — <?= e($doc['code']) ?></title>
<link rel="icon" href="<?= asset('img/logo.svg') ?>" type="image/svg+xml">
<link rel="stylesheet" href="<?= asset('css/sheet.css') ?>">
<script src="<?= asset('js/qrcode.js') ?>" defer></script>
<script src="<?= asset('js/app.js') ?>" defer></script>
</head>
<body class="sheet-body">
<?= $content ?>
</body>
</html>
