<div class="page-head"><h1>Reports</h1><p class="muted">Every download is recorded in the audit trail with your name and the time. Official single-application documents (receipt, award letter, support statement) are sealed sheets, opened from each application.</p></div>
<form method="get" class="filters panel" action="">
  <div class="field"><label for="cy">Application cycle</label><select id="cy" name="cycle"><?php foreach ($cycles as $c): ?><option value="<?= (int)$c['id'] ?>"<?= selected(input('cycle'), $c['id']) ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></div>
  <button class="btn btn-sm btn-line">Use this cycle</button>
</form>
<div class="grid-2">
<?php foreach ($list as $key => [$name, $desc]): $q = ['cycle' => input('cycle') ?: ($cycles[0]['id'] ?? '')]; ?>
  <div class="panel feature"><h3><?= e($name) ?></h3><p class="small"><?= e($desc) ?></p>
    <div class="btn-row"><a class="btn btn-sm" href="/reports/<?= e($key) ?>?<?= e(http_build_query($q + ['format' => 'xls'])) ?>">Excel</a><a class="btn btn-sm btn-line" href="/reports/<?= e($key) ?>?<?= e(http_build_query($q + ['format' => 'csv'])) ?>">CSV</a></div>
  </div>
<?php endforeach; ?>
</div>
<p class="small muted">Need a PDF? Open the Excel file and print to PDF, or use a sealed sheet’s “Print / Save PDF” button.</p>
<?php if ($recent && Auth::has('auditor', 'admin')): ?>
<h2>Recent downloads</h2>
<div class="table-wrap"><table class="cards"><thead><tr><th>When</th><th>Who</th><th>Report</th><th>Format</th><th class="r">Rows</th></tr></thead><tbody>
<?php foreach ($recent as $r): ?><tr><td data-label="When"><?= e(fmt_date($r['created_at'], 'j M Y H:i')) ?></td><td data-label="Who"><?= e($r['full_name']) ?></td><td data-label="Report"><?= e($r['report']) ?></td><td data-label="Format"><?= e(strtoupper((string)$r['format'])) ?></td><td data-label="Rows" class="r"><?= e($r['nrows']) ?></td></tr><?php endforeach; ?>
</tbody></table></div>
<?php endif; ?>
