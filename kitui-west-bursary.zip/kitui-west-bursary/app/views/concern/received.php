<div class="wrap section narrow">
  <div class="verify-result valid">
    <h1>Your report was received</h1>
    <p>Write these down now. The PIN is shown only once and is needed to track the report.</p>
    <dl class="facts"><dt>Tracking reference</dt><dd class="num"><b><?= e($ref) ?></b></dd><dt>PIN</dt><dd class="num"><b><?= e($pin) ?></b></dd></dl>
  </div>
  <p><a class="btn btn-line" href="/report-concern/track">Track a report</a> <a class="btn btn-quiet" href="/">Home</a></p>
</div>
