<div class="page-head"><div class="wrap"><h1>Report a concern</h1><p>Report bribery, fraud, forged documents, favouritism, ghost beneficiaries, payment problems or officer misconduct. You can stay anonymous. Reports go to the auditors, not to the officers handling applications.</p></div></div>
<div class="wrap section narrow">
  <?php if ($errors): ?><div class="flash flash-error" role="alert">Please correct the highlighted fields.</div><?php endif; ?>
  <form method="post" action="/report-concern" class="panel" novalidate>
    <?= csrf_field() ?>
    <div class="field<?= isset($errors['category']) ? ' has-error' : '' ?>"><label for="category">What kind of concern?</label>
      <select id="category" name="category"><option value="">Choose…</option><?php foreach (CONCERN_CATEGORIES as $k => $l): ?><option value="<?= $k ?>"<?= selected($_SESSION['old']['category'] ?? '', $k) ?>><?= e($l) ?></option><?php endforeach; ?></select><?= field_error($errors, 'category') ?></div>
    <div class="field<?= isset($errors['description']) ? ' has-error' : '' ?>"><label for="description">What happened? <span class="hint">When, where, who was involved, and any amounts. Do not include your own name if you want to stay anonymous.</span></label>
      <textarea id="description" name="description" maxlength="5000" rows="7"><?= old('description') ?></textarea><?= field_error($errors, 'description') ?></div>
    <div class="grid-2">
      <div class="field"><label for="rr">Related application reference <span class="hint">Optional</span></label><input type="text" id="rr" name="related_reference" class="code-input" value="<?= old('related_reference') ?>"></div>
      <div class="field"><label for="ward">Ward <span class="hint">Optional</span></label><select id="ward" name="ward_id"><option value="">—</option><?php foreach ($wards as $w): ?><option value="<?= (int)$w['id'] ?>"<?= selected($_SESSION['old']['ward_id'] ?? '', $w['id']) ?>><?= e($w['name']) ?></option><?php endforeach; ?></select></div>
    </div>
    <details class="faq"<?= !empty($_SESSION['old']['identify']) ? ' open' : '' ?>><summary>I am willing to give my name and phone (optional)</summary><div>
      <label class="check"><input type="checkbox" name="identify" value="1"<?= checked(!empty($_SESSION['old']['identify'])) ?>>Contact me about this report</label><p></p>
      <div class="grid-2">
        <div class="field<?= isset($errors['reporter_name']) ? ' has-error' : '' ?>"><label for="rn">Your name</label><input type="text" id="rn" name="reporter_name" value="<?= old('reporter_name') ?>"><?= field_error($errors, 'reporter_name') ?></div>
        <div class="field<?= isset($errors['reporter_phone']) ? ' has-error' : '' ?>"><label for="rp">Your phone</label><input type="tel" id="rp" name="reporter_phone" value="<?= old('reporter_phone') ?>"><?= field_error($errors, 'reporter_phone') ?></div>
      </div></div></details>
    <p class="small muted">Anonymous reports do not record your name, phone or internet address.</p>
    <button class="btn">Send report</button>
  </form>
  <p>Already reported? <a href="/report-concern/track">Track your report</a>.</p>
</div>
