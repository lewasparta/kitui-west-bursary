<div class="page-head"><div class="wrap"><h1>Track a concern</h1><p>Enter the tracking reference and PIN you received.</p></div></div>
<div class="wrap section narrow">
  <?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?>
  <?php if ($c): ?>
    <div class="panel"><div class="panel-head"><h2><?= e($c['reference']) ?></h2><?= status_badge($c['status']) ?></div>
      <p class="small muted">Received <?= e(fmt_date($c['created_at'], 'j M Y')) ?> · last updated <?= e(fmt_date($c['updated_at'], 'j M Y')) ?></p>
      <?php if ($updates): ?><ul class="timeline"><?php foreach ($updates as $u): ?><li><time><?= e(fmt_date($u['created_at'], 'j M Y')) ?></time><?= e($u['note']) ?></li><?php endforeach; ?></ul>
      <?php else: ?><p>Your report is with the audit team. Updates will appear here.</p><?php endif; ?></div>
  <?php endif; ?>
  <form method="post" action="/report-concern/track" class="panel"><?= csrf_field() ?>
    <div class="grid-2"><div class="field"><label for="ref">Reference</label><input type="text" id="ref" name="reference" class="code-input" placeholder="KWC-2026-00001" required></div>
    <div class="field"><label for="pin">PIN</label><input type="password" id="pin" name="pin" inputmode="numeric" required></div></div>
    <button class="btn">Check status</button>
  </form>
</div>
