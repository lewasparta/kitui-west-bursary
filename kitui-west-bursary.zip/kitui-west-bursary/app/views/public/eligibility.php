<div class="page-head"><div class="wrap"><h1>Eligibility and requirements</h1><p><?= $cycle ? 'Rules for ' . e($cycle['name']) . '.' : 'Rules are published when a cycle is announced.' ?></p></div></div>
<div class="wrap section">
  <div class="two-col">
    <div class="prose">
      <h2>Who can apply</h2>
      <ul>
        <li>The student’s home is in a Kitui West ward.</li>
        <li>The student is currently enrolled at an eligible institution for this cycle.</li>
        <li>The household cannot fully meet the fees.</li>
        <li>One application per student per cycle.</li>
      </ul>
      <h2>Documents</h2>
      <?php if (!$docs): ?><p class="muted">The document list will appear here when the cycle is set up.</p><?php else: ?>
      <div class="table-wrap"><table class="cards"><thead><tr><th>Document</th><th>For</th><th>Needed</th></tr></thead><tbody>
      <?php foreach ($docs as $d): ?>
        <tr><td data-label="Document"><b><?= e($d['name']) ?></b><br><span class="small muted"><?= e($d['description']) ?></span></td><td data-label="For"><?= e(level_label($d['level'])) ?></td><td data-label="Needed"><?= $d['is_required'] ? 'Required' : 'If applicable' ?></td></tr>
      <?php endforeach; ?></tbody></table></div><?php endif; ?>
    </div>
    <div>
      <div class="panel"><h3>Award ranges</h3>
        <?php if (!$levels): ?><p class="muted">Not yet published.</p><?php endif; ?>
        <?php foreach ($levels as $l): ?><p><b><?= e(level_label($l['level'])) ?></b><br><?= e(money($l['min_amount'])) ?> to <?= e(money($l['max_amount'])) ?></p><?php endforeach; ?>
      </div>
      <div class="lock-note"><span aria-hidden="true">🔒</span><span>School ID cards are checked by an officer. If the automatic reader cannot read your card, you are not rejected — a person looks at it.</span></div>
    </div>
  </div>
</div>
