<?php
$sup = fn($n) => ((int)$n > 0 && (int)$n < $min) ? '<span class="muted" title="Hidden to protect privacy">&lt;' . $min . '</span>' : number_format((int)$n);
$maxAmt = max(1, ...array_map(fn($w) => (float)$w['amount'], $wards ?: [['amount' => 1]]));
?>
<div class="page-head"><div class="wrap"><h1>Transparency dashboard</h1><p>Totals only. No names, phone numbers, ID numbers, homes or individual payments are ever published. Groups smaller than <?= (int)$min ?> are hidden.</p></div></div>
<div class="wrap section">
  <form class="filters" method="get">
    <div class="field"><label for="cycle">Cycle</label><select id="cycle" name="cycle"><?php foreach ($cycles as $c): ?><option value="<?= (int)$c['id'] ?>"<?= selected($c['id'], $cycleId) ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></div>
    <button class="btn btn-line">Show</button>
  </form>
  <div class="stats">
    <div class="stat"><b><?= number_format($stats['received'] ?? 0) ?></b><span>Applications received</span></div>
    <div class="stat"><b><?= number_format($stats['verified'] ?? 0) ?></b><span>Verified</span></div>
    <div class="stat"><b><?= number_format($stats['approved'] ?? 0) ?></b><span>Approved</span></div>
    <div class="stat"><b><?= number_format($stats['disbursed'] ?? 0) ?></b><span>Paid</span></div>
    <div class="stat gold"><b><?= e(money($stats['amount_approved'] ?? 0)) ?></b><span>Total awarded</span></div>
    <div class="stat gold"><b><?= e(money($stats['amount_paid'] ?? 0)) ?></b><span>Total paid to institutions</span></div>
  </div>
  <div class="two-col">
    <div class="panel">
      <h2>Awards by ward</h2>
      <?php foreach ($wards as $w): ?>
        <div class="bar-row"><span><?= e($w['name']) ?></span><div class="bar-track"><div class="bar-fill" style="width:<?= round((float)$w['amount'] / $maxAmt * 100, 1) ?>%"></div></div><span class="num r small"><?= e(money($w['amount'])) ?></span></div>
      <?php endforeach; ?>
      <div class="table-wrap" style="margin-top:1rem"><table class="cards"><thead><tr><th>Ward</th><th class="r">Applications</th><th class="r">Approved</th><th class="r">Budget</th><th class="r">Paid</th></tr></thead><tbody>
      <?php foreach ($wards as $w): ?><tr><td data-label="Ward"><?= e($w['name']) ?></td><td class="r" data-label="Applications"><?= $sup($w['apps']) ?></td><td class="r" data-label="Approved"><?= $sup($w['approved']) ?></td><td class="r" data-label="Budget"><?= e(money($w['budget'])) ?></td><td class="r" data-label="Paid"><?= e(money($w['paid'])) ?></td></tr><?php endforeach; ?>
      </tbody></table></div>
    </div>
    <div>
      <div class="panel"><h2>By level of education</h2>
        <?php if (!$levels): ?><p class="muted">No applications yet.</p><?php endif; ?>
        <?php foreach ($levels as $l): ?><p><b><?= e(level_label($l['level'])) ?></b><br><span class="small"><?= $sup($l['apps']) ?> applied · <?= $sup($l['approved']) ?> approved · <?= e(money($l['amount'])) ?></span></p><?php endforeach; ?>
      </div>
      <div class="panel"><h2>Approved by gender</h2>
        <?php foreach ($gender as $g): ?><p><?= e(ucfirst($g['gender'])) ?>: <?= $sup($g['n']) ?></p><?php endforeach; ?>
        <?php if (!$gender): ?><p class="muted">No approvals yet.</p><?php endif; ?>
      </div>
      <div class="panel"><h2>Mentorship</h2><p><?= number_format((int)($mentor['events'] ?? 0)) ?> sessions · <?= $sup($mentor['participants'] ?? 0) ?> students registered · <?= $sup($mentor['attended'] ?? 0) ?> attendances</p></div>
    </div>
  </div>
</div>
