<div class="page-head"><div class="wrap"><h1>How it works</h1><p>From application to payment, with a record at every step.</p></div></div>
<div class="wrap section narrow">
  <ol class="steps-list">
    <li><div><h3>Create an account</h3><p>Register with your mobile number. Parents can add several children under one account; students can register themselves.</p></div></li>
    <li><div><h3>Fill in the application</h3><p>Seven short steps: applicant, student, education, household, documents, review and declaration. Your progress saves as you type, so you can stop and continue later.</p></div></li>
    <li><div><h3>Upload documents and get the chief’s form</h3><p>Take clear photos of the school ID and other documents. Print the system-issued recommendation form, have the chief sign and stamp it, then upload the photo.</p></div></li>
    <li><div><h3>Documents are checked</h3><p>An officer confirms your documents. If something is missing you get an SMS explaining what to fix.</p></div></li>
    <li><div><h3>Verification and field visits</h3><p>A ward officer verifies the information. Some homes are visited, either at random or where checks need it.</p></div></li>
    <li><div><h3>Committee review and approval</h3><p>The committee recommends an amount. A separate approver confirms it within the ward budget.</p></div></li>
    <li><div><h3>Payment to the institution</h3><p>Finance prepares a payment batch, another officer authorises it and the bank reference is recorded. You receive an SMS once it is paid.</p></div></li>
  </ol>
  <p style="margin-top:1.5rem"><a class="btn" href="/register">Start an application</a></p>
</div>
