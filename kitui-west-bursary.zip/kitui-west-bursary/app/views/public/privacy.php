<div class="page-head"><div class="wrap"><h1>Privacy notice</h1><p>How the Kitui West Digital Bursary collects, uses and protects your information, in line with Kenya’s Data Protection Act, 2019.</p></div></div>
<div class="wrap section narrow prose">
  <h2>What we collect and why</h2>
  <p>We collect the information needed to decide and pay bursaries: the parent or guardian’s name, phone and ID number; the student’s name, date of birth, school details and documents; household circumstances; and, where a field visit is needed, photos of the homestead taken by an authorised officer. We use it only to assess applications, pay institutions, prevent fraud, send you updates, and publish anonymous statistics.</p>
  <h2>Children’s information</h2>
  <p>Most students are children. Their information is entered by a parent or guardian, seen only by officers whose role requires it, and never published. The public transparency page shows totals only, and hides any group small enough to identify someone.</p>
  <h2>Who can see it</h2>
  <p>Only authorised officers, each limited to their step (document check, ward verification, committee, approval, finance or audit). Officers related to your household are blocked from your file. Every time an officer opens your application or a document, it is recorded.</p>
  <h2>How it is protected</h2>
  <p>Documents are kept in private storage, never on public web addresses. Passwords are stored as one-way hashes. Staff use two-step login. All actions are recorded in a log that cannot be edited. Payments go only to institution bank accounts.</p>
  <h2>How long we keep it</h2>
  <p>Application records are kept for audit for at least seven years after the bursary cycle closes, as public finance rules require, then deleted or anonymised.</p>
  <h2>Your rights</h2>
  <p>You may ask to see the information held about you or your child, correct anything wrong, or object to a use you disagree with. Contact the bursary office at <?= e(setting('contact_email')) ?> or <?= e(setting('contact_phone')) ?>. You may also complain to the Office of the Data Protection Commissioner (ODPC).</p>
  <h2>Concerns and reports</h2>
  <p>Reports through “Report a concern” can be anonymous. If you give your name, it is seen only by the auditors handling the report.</p>
</div>
