<div class="page-head"><div class="wrap"><h1>Announcements</h1></div></div>
<div class="wrap section narrow">
  <?php foreach ($p['rows'] as $a): ?>
    <article class="panel"><h2><a href="/announcements/<?= (int)$a['id'] ?>"><?= e($a['title']) ?></a></h2><p class="small muted"><?= e(fmt_date($a['published_at'])) ?></p><p><?= e(mb_strimwidth($a['body'], 0, 240, '…')) ?></p></article>
  <?php endforeach; ?>
  <?php if (!$p['rows']): ?><p class="muted">No announcements yet.</p><?php endif; ?>
  <?= partial('pager', ['p' => $p]) ?>
</div>
