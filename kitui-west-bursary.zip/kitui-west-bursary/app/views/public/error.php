<div class="wrap section narrow">
  <div class="panel"><h1><?= $status === 404 ? 'Page not found' : ($status === 403 ? 'Not allowed' : ($status === 429 ? 'Please slow down' : 'Something went wrong')) ?></h1>
  <p><?= e($message) ?></p>
  <div class="btn-row"><a class="btn" href="<?= e(Auth::user() ? Auth::homeFor() : '/') ?>">Go to start</a></div></div>
</div>
