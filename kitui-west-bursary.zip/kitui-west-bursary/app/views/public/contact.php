<div class="page-head"><div class="wrap"><h1>Contact</h1><p>Questions about your application? Log in first — most answers are on your tracking page.</p></div></div>
<div class="wrap section cols">
  <div class="panel"><h3>Bursary office</h3><p><?= e(setting('office_address')) ?></p><p class="small muted">Monday to Friday, 8:00am to 5:00pm</p></div>
  <div class="panel"><h3>Phone</h3><p><a href="tel:<?= e(preg_replace('/\s+/', '', setting('contact_phone'))) ?>"><?= e(setting('contact_phone')) ?></a></p><p class="small muted">Have your application reference ready.</p></div>
  <div class="panel"><h3>Email</h3><p><a href="mailto:<?= e(setting('contact_email')) ?>"><?= e(setting('contact_email')) ?></a></p></div>
  <div class="panel panel-alert"><h3>Report misconduct</h3><p>If anyone asks you for money or you suspect fraud, report it confidentially.</p><a class="btn btn-danger" href="/report-concern">Report a concern</a></div>
</div>
