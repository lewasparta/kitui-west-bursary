<div class="page-head"><div class="wrap"><h1>Check an official document</h1><p>Receipts, chief recommendation forms, award letters and support statements are issued only by this system. Each carries a code. Compare the paper with the official record below.</p></div></div>
<div class="wrap section narrow">
  <form method="get" class="panel">
    <label for="code">Verification code <span class="hint">Printed at the bottom of the sheet or read from its QR code</span></label>
    <input class="code-input" id="code" name="code" value="<?= e($code) ?>" placeholder="KWV-XXXX-XXXX-XXXX" required autocomplete="off">
    <p></p><button class="btn">Check document</button>
  </form>
  <?php if ($result): $p = $result['payload'] ?? []; ?>
    <?php if ($result['state'] === 'valid'): ?>
      <div class="verify-result valid"><h2>Genuine document</h2><p>This <?= e(strtolower(Seal::KINDS[$result['doc']['kind']])) ?> was issued by the system on <?= e(fmt_date($result['doc']['issued_at'], 'j M Y, g:ia')) ?>. The paper must match these details exactly. If anything differs, it has been altered.</p>
        <dl class="facts">
          <?php foreach (($p['public'] ?? []) as $k => $v): ?><dt><?= e($k) ?></dt><dd><?= e($v) ?></dd><?php endforeach; ?>
          <dt>Seal fingerprint</dt><dd class="num"><?= e(Seal::fingerprint($result['doc'])) ?></dd>
        </dl>
      </div>
    <?php elseif ($result['state'] === 'revoked'): ?>
      <div class="verify-result warn"><h2>No longer valid</h2><p>This document was replaced on <?= e(fmt_date($result['doc']['revoked_at'])) ?> (<?= e($result['doc']['revoked_reason']) ?>). Ask the holder for the current version.</p></div>
    <?php elseif ($result['state'] === 'tampered'): ?>
      <div class="verify-result bad"><h2>Do not accept this document</h2><p>The record behind this code failed its security seal. The bursary office has been alerted.</p></div>
    <?php else: ?>
      <div class="verify-result bad"><h2>Code not found</h2><p>No document with this code was ever issued. The paper is not genuine. <a href="/report-concern">Report it</a>.</p></div>
    <?php endif; ?>
  <?php endif; ?>
</div>
