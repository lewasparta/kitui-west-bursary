<div class="page-head"><div class="wrap"><h1>Frequently asked questions</h1></div></div>
<div class="wrap section narrow">
  <?php foreach ($faqs as $f): ?><details class="faq"><summary><?= e($f['question']) ?></summary><div><?= nl2br(e($f['answer'])) ?></div></details><?php endforeach; ?>
  <?php if (!$faqs): ?><p class="muted">No questions have been published yet.</p><?php endif; ?>
</div>
