<div class="page-head"><div class="wrap"><h1>About the bursary</h1><p>Support for needy and deserving students from Kitui West, managed openly from application to payment.</p></div></div>
<div class="wrap section prose">
  <p>The Kitui West bursary helps students from the constituency stay in secondary school, TVET, college and university. The fund is limited, so it is shared using clear, published rules and reviewed by a committee.</p>
  <h2>Why the process is digital</h2>
  <p>Paper forms were bought, copied and sometimes forged. Files went missing and applicants could not tell where their application was. This platform replaces paper with a single online application that records who did what and when.</p>
  <h2>How we protect the fund</h2>
  <ul>
    <li>Different officers handle documents, verification, committee review, approval and payment.</li>
    <li>Officers declare any conflict of interest before opening an application.</li>
    <li>The system checks for duplicate students, repeated documents and links to staff.</li>
    <li>A share of applications is picked at random for field visits and independent audit.</li>
    <li>Payments go directly to institutions and are reconciled against bank records.</li>
    <li>The audit trail cannot be edited, even by administrators.</li>
  </ul>
  <h2>Your privacy</h2>
  <p>Student details, phone numbers, ID numbers, home information and homestead photos are seen only by officers who need them for your application. Public statistics are aggregated and small groups are hidden.</p>
</div>
