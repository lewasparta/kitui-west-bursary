<div class="page-head"><div class="wrap"><h1>Application period</h1><p>Applications are accepted only while a cycle is open.</p></div></div>
<div class="wrap section">
  <?php if ($current): ?>
    <div class="panel panel-gold"><h2><?= e($current['name']) ?> is open</h2><p>Closes <b><?= e(fmt_date($current['closes_at'], 'l j F Y, g:ia')) ?></b>. Drafts not submitted by then cannot be considered.</p><a class="btn" href="/register">Start an application</a></div>
  <?php else: ?>
    <div class="panel"><h2>No cycle is open right now</h2><p>Announcements and SMS will tell you when the next one opens.<?php foreach ($upcoming as $u): ?> <b><?= e($u['name']) ?></b> is planned to open on <?= e(fmt_date($u['opens_at'])) ?>.<?php endforeach; ?></p></div>
  <?php endif; ?>
  <h2>Cycles</h2>
  <div class="table-wrap"><table class="cards"><thead><tr><th>Cycle</th><th>Opens</th><th>Closes</th><th>Status</th></tr></thead><tbody>
  <?php foreach ($cycles as $c): ?><tr><td data-label="Cycle"><?= e($c['name']) ?></td><td data-label="Opens"><?= e(fmt_date($c['opens_at'])) ?></td><td data-label="Closes"><?= e(fmt_date($c['closes_at'])) ?></td><td data-label="Status"><?= e(ucfirst($c['status'])) ?></td></tr><?php endforeach; ?>
  <?php if (!$cycles): ?><tr><td colspan="4" class="empty">No cycles published yet.</td></tr><?php endif; ?>
  </tbody></table></div>
</div>
