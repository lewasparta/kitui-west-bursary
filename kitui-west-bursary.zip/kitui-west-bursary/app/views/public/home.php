<?php
$open = $cycle && $cycle['status'] === 'open' && strtotime($cycle['opens_at']) <= time() && strtotime($cycle['closes_at']) > time();
$daysLeft = $open ? max(0, (int)ceil((strtotime($cycle['closes_at']) - time()) / 86400)) : null;
$levelIcon = ['secondary' => 'school', 'tvet' => 'cog', 'college' => 'book', 'university' => 'star', 'special' => 'users'];
?>
<section class="hero2">
  <div class="hero2-glow" aria-hidden="true"></div>
  <div class="wrap hero2-in">
    <div class="hero2-copy">
      <?php if ($cycle): ?>
        <p class="pill <?= $open ? 'pill-live' : '' ?>"><span class="pill-dot"></span><?= e($cycle['name']) ?> —
          <?= $open ? 'applications open · ' . $daysLeft . ' day' . ($daysLeft === 1 ? '' : 's') . ' left' : 'opens ' . e(fmt_date($cycle['opens_at'], 'j M Y')) ?></p>
      <?php endif; ?>
      <h1><?= e(t('home.title')) ?></h1>
      <p class="lead"><?= e(t('home.lead')) ?></p>
      <div class="btn-row hero2-cta">
        <a class="btn btn-gold btn-lg" href="/register"><?= e(t('home.apply')) ?> <?= icon('arrow') ?></a>
        <a class="btn btn-glass btn-lg" href="/login"><?= icon('search') ?> <?= e(t('home.track')) ?></a>
      </div>
      <ul class="trust">
        <li><?= icon('check') ?> Free to apply — no agents</li>
        <li><?= icon('bank') ?> Paid straight to the school</li>
        <li><?= icon('sms') ?> SMS at every step</li>
      </ul>
    </div>
    <div class="hero2-card">
      <div class="journey">
        <div class="journey-head"><b>KWB-<?= date('Y') ?>-000148</b><span class="chip chip-gold">Live tracking</span></div>
        <ol>
          <li class="done"><span class="dot">✓</span><div><strong>Submitted online</strong><small>Reference and receipt sent by SMS</small></div></li>
          <li class="done"><span class="dot">✓</span><div><strong>Documents checked</strong><small>School ID and chief’s form confirmed</small></div></li>
          <li class="done"><span class="dot">✓</span><div><strong>Verified in the ward</strong><small>By a ward officer, not the checker</small></div></li>
          <li class="now"><span class="dot">4</span><div><strong>Committee review</strong><small>Amount recommended, then approved separately</small></div></li>
          <li><span class="dot">5</span><div><strong>Paid to the school</strong><small>Bank reference recorded and sent to you</small></div></li>
        </ol>
      </div>
      <div class="float-seal" aria-hidden="true"><?= icon('qr') ?><div><b>Sealed award letter</b><small>KWV-7Q2M-4KDX-9PHT · verified ✓</small></div></div>
    </div>
  </div>
  <div class="hero2-hills" aria-hidden="true"></div>
</section>

<section class="numbers">
  <div class="wrap numbers-in">
    <div><b><?= number_format($stats['received'] ?? 0) ?></b><span>Applications this cycle</span></div>
    <div><b><?= number_format($stats['approved'] ?? 0) ?></b><span>Students approved</span></div>
    <div><b><?= e(money($stats['amount_approved'] ?? 0)) ?></b><span>Awarded</span></div>
    <div><b><?= e(money($stats['amount_paid'] ?? 0)) ?></b><span>Paid to institutions</span></div>
    <a class="numbers-link" href="/transparency">Open the transparency dashboard <?= icon('arrow') ?></a>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="sec-head"><p class="eyebrow">How to apply</p><h2>Four steps, all from your phone</h2><p class="muted">No forms to buy, no queues at the office. Your answers save as you type, so you can finish later.</p></div>
    <ol class="steps4">
      <li><span class="step-ico"><?= icon('user') ?></span><b>Create an account</b><p>Register with the parent’s or guardian’s mobile number.</p></li>
      <li><span class="step-ico"><?= icon('clipboard') ?></span><b>Fill in the details</b><p>Student, school and household — about 10 minutes.</p></li>
      <li><span class="step-ico"><?= icon('upload') ?></span><b>Upload documents</b><p>Photo of the school ID, fee statement and the chief’s sealed form.</p></li>
      <li><span class="step-ico"><?= icon('bell') ?></span><b>Track and get paid</b><p>Follow every step. Money goes straight to the school account.</p></li>
    </ol>
    <p class="center"><a class="btn btn-line" href="/how-it-works">See the full process <?= icon('arrow') ?></a></p>
  </div>
</section>

<?php if ($levels): ?>
<section class="section alt">
  <div class="wrap">
    <div class="sec-head"><p class="eyebrow">Who it supports</p><h2>Levels supported this cycle</h2></div>
    <div class="levels">
      <?php foreach ($levels as $l): ?>
        <div class="level-card"><span class="level-ico"><?= icon($levelIcon[$l['level']] ?? 'school') ?></span><b><?= e(level_label($l['level'])) ?></b><small>Awards <?= e(money($l['min_amount'])) ?> – <?= e(money($l['max_amount'])) ?></small></div>
      <?php endforeach; ?>
    </div>
    <p class="center small muted">Full rules and required documents: <a href="/eligibility">Eligibility &amp; requirements</a></p>
  </div>
</section>
<?php endif; ?>

<section class="section">
  <div class="wrap">
    <div class="sec-head"><p class="eyebrow">Built to stop corruption</p><h2>Every shilling can be traced</h2></div>
    <div class="cards3">
      <div class="icard"><span class="icard-ico"><?= icon('users') ?></span><h3>Different hands at every step</h3><p>The officer who checks documents cannot approve, and the person who approves cannot pay. The system enforces it.</p></div>
      <div class="icard"><span class="icard-ico"><?= icon('eye') ?></span><h3>Nothing happens unseen</h3><p>Every action is recorded against a name and time in a log that cannot be edited — auditors can replay any application.</p></div>
      <div class="icard"><span class="icard-ico"><?= icon('bank') ?></span><h3>Money goes to the school</h3><p>Bursaries are never paid in cash. You receive the bank reference by SMS and the school can confirm it.</p></div>
    </div>
  </div>
</section>

<section class="seal-sec">
  <div class="wrap seal-in">
    <div>
      <p class="eyebrow eyebrow-gold">Sealed official documents</p>
      <h2>A sheet made in a cyber café will not pass</h2>
      <p>Receipts, the chief’s recommendation form and award letters come only from this system. Each carries a unique code, a QR and a digital seal. Before relying on any bursary document, check it here.</p>
      <form action="/verify" method="get" class="verify-inline">
        <label class="sr" for="code">Verification code</label>
        <input class="code-input" id="code" name="code" type="text" placeholder="KWV-XXXX-XXXX-XXXX" autocomplete="off" required>
        <button class="btn btn-gold"><?= icon('shield') ?> Check document</button>
      </form>
    </div>
    <div class="mock-sheet" aria-hidden="true">
      <div class="mock-top"><img src="<?= asset('img/logo.svg') ?>" alt=""><div><b>KITUI WEST DIGITAL BURSARY</b><small>AWARD LETTER · ORIGINAL</small></div></div>
      <div class="mock-lines"><i></i><i></i><i class="short"></i><i></i><i class="short"></i></div>
      <div class="mock-foot"><span class="mock-qr"><?= icon('qr') ?></span><div><small>Verification code</small><b>KWV-7Q2M-4KDX-9PHT</b><small>Seal 9F2A 61C0 D4E8 07BB</small></div><span class="mock-stamp">SEALED</span></div>
    </div>
  </div>
</section>

<section class="section">
  <div class="wrap two-col">
    <div>
      <div class="panel-head"><h2>Announcements</h2><a href="/announcements">All</a></div>
      <?php if (!$news): ?><p class="muted">No announcements yet.</p><?php endif; ?>
      <?php foreach ($news as $n): ?>
        <a class="news" href="/announcements/<?= (int)$n['id'] ?>"><span class="news-date"><b><?= e(fmt_date($n['published_at'], 'j')) ?></b><?= e(fmt_date($n['published_at'], 'M')) ?></span><span><b><?= e($n['title']) ?></b><small>Read more →</small></span></a>
      <?php endforeach; ?>
    </div>
    <div>
      <div class="panel-head"><h2>Mentorship</h2><a href="/login">Register</a></div>
      <?php if (!$events): ?><p class="muted">New sessions are announced here and by SMS.</p><?php endif; ?>
      <?php foreach ($events as $ev): ?>
        <div class="news"><span class="news-date news-date-gold"><b><?= e(fmt_date($ev['starts_at'], 'j')) ?></b><?= e(fmt_date($ev['starts_at'], 'M')) ?></span><span><b><?= e($ev['title']) ?></b><small><?= icon('map') ?> <?= e($ev['venue']) ?></small></span></div>
      <?php endforeach; ?>
      <p class="small muted">Free career, university, TVET, digital-skills and money sessions for students and parents.</p>
    </div>
  </div>
</section>

<section class="cta-band">
  <div class="wrap cta-in">
    <div><h2>Ready to apply?</h2><p>It takes about 10 minutes. Keep the school ID and fee statement nearby.</p></div>
    <div class="btn-row"><a class="btn btn-lg" href="/register">Start my application <?= icon('arrow') ?></a><a class="btn btn-lg btn-ghost-dark" href="/eligibility">Check eligibility</a></div>
  </div>
</section>
