<div class="page-head"><div class="wrap"><p class="small"><a href="/announcements">Announcements</a></p><h1><?= e($a['title']) ?></h1><p><?= e(fmt_date($a['published_at'], 'l j F Y')) ?></p></div></div>
<div class="wrap section prose"><?= nl2br(e($a['body'])) ?></div>
