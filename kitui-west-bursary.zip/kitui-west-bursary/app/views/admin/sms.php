<p class="crumbs"><a href="/admin">Administration</a> › SMS log</p>
<div class="panel-head"><h1>SMS log</h1><a class="btn btn-sm btn-line" href="/admin/r/sms_templates">Edit templates</a></div>
<p class="muted">Driver: <b><?= e(env('SMS_DRIVER', 'log')) ?></b><?= env('SMS_DRIVER', 'log') === 'log' ? ' — messages are recorded here but not sent. Set SMS_DRIVER=africastalking in .env to send.' : '' ?></p>
<div class="table-wrap"><table class="cards"><thead><tr><th>Time</th><th>Phone</th><th>Type</th><th>Application</th><th>Status</th><th>Message</th></tr></thead><tbody>
<?php foreach ($p['rows'] as $m): ?>
<tr><td data-label="Time"><?= e(fmt_date($m['created_at'], 'j M H:i')) ?></td><td data-label="Phone"><?= e(mask_phone($m['phone'])) ?></td><td data-label="Type"><?= e($m['template_code'] ?? 'direct') ?></td>
<td data-label="Application"><?= e($m['reference'] ?? '—') ?></td>
<td data-label="Status"><span class="badge <?= $m['status'] === 'failed' ? 'badge-bad' : ($m['status'] === 'sent' ? 'badge-ok' : 'badge-muted') ?>"><?= e(ucfirst($m['status'])) ?></span><?= $m['error'] ? '<div class="small field-error">' . e($m['error']) . '</div>' : '' ?></td>
<td data-label="Message" class="small"><?= e(preg_replace('/(password is |code is )\S+/', '$1••••••', $m['body'])) ?></td></tr>
<?php endforeach; ?>
</tbody></table></div>
<?= partial('pager', ['p' => $p]) ?>
