<?php
$cols = array_slice(array_filter($fields, fn($f) => !in_array($f[1], ['textarea'], true)), 0, 5, true);
$show = function ($f, $v) {
    if ($f[1] === 'bool') { return $v ? '<span class="badge badge-ok">Yes</span>' : '<span class="badge badge-muted">No</span>'; }
    if (is_array($f[1])) { return e($f[1][$v] ?? $v); }
    if ($f[1] === 'money') { return money($v); }
    if ($f[1] === 'datetime') { return e(fmt_date($v, 'j M Y H:i')); }
    return e(mb_strimwidth((string)$v, 0, 70, '…'));
};
?>
<p class="crumbs"><a href="/admin">Administration</a> › <?= e($title) ?></p>
<div class="panel-head"><h1><?= e($title) ?></h1><?php if ($res !== 'sms_templates'): ?><a class="btn btn-sm" href="/admin/r/<?= e($res) ?>/new">Add new</a><?php endif; ?></div>
<?php if (!$p['rows']): ?><div class="panel empty">Nothing here yet.</div><?php else: ?>
<div class="table-wrap"><table class="cards"><thead><tr><?php foreach ($cols as $f): ?><th><?= e(preg_replace('/\s*\(.*$/', '', $f[0])) ?></th><?php endforeach; ?><th></th></tr></thead><tbody>
<?php foreach ($p['rows'] as $r): ?><tr>
<?php foreach ($cols as $k => $f): ?><td data-label="<?= e(preg_replace('/\s*\(.*$/', '', $f[0])) ?>"><?= $show($f, $r[$k] ?? null) ?></td><?php endforeach; ?>
<td><a class="btn btn-sm btn-line" href="/admin/r/<?= e($res) ?>/<?= (int)$r['id'] ?>">Edit</a></td></tr>
<?php endforeach; ?>
</tbody></table></div>
<?= partial('pager', ['p' => $p]) ?>
<?php endif; ?>
