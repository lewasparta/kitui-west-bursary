<?php $row = $row ?? []; ?>
<p class="crumbs"><a href="/admin">Administration</a> › <a href="/admin/r/<?= e($res) ?>">List</a></p>
<h1><?= e($title) ?></h1>
<?php if (isset($errors['_'])): ?><div class="flash flash-error"><?= e($errors['_']) ?></div><?php endif; ?>
<form method="post" action="/admin/r/<?= e($res) ?>/save" class="panel narrow"><?= csrf_field() ?>
<?php if (!empty($row['id'])): ?><input type="hidden" name="id" value="<?= (int)$row['id'] ?>"><?php endif; ?>
<?php foreach ($fields as $k => [$label, $type, $rule]): $val = $row[$k] ?? ''; $id = 'f_' . $k; $cls = 'field' . (isset($errors[$k]) ? ' has-error' : ''); ?>
  <?php if ($type === 'bool'): ?>
    <label class="check"><input type="checkbox" name="<?= e($k) ?>" value="1" <?= checked($row ? $val : ($k === 'is_active' || $k === 'is_required' || $k === 'is_eligible')) ?>> <?= e($label) ?></label>
  <?php elseif ($type === 'readonly'): ?>
    <div class="field"><label><?= e($label) ?></label><p><code><?= e($val) ?></code></p></div>
  <?php else: ?>
  <div class="<?= $cls ?>"><label for="<?= $id ?>"><?= e($label) ?></label>
    <?php if (is_array($type)): ?>
      <select id="<?= $id ?>" name="<?= e($k) ?>"><option value="">Choose…</option><?php foreach ($type as $ov => $ol): ?><option value="<?= e($ov) ?>"<?= selected($val, $ov) ?>><?= e($ol) ?></option><?php endforeach; ?></select>
    <?php elseif ($type === 'textarea'): ?>
      <textarea id="<?= $id ?>" name="<?= e($k) ?>" rows="6"><?= e($val) ?></textarea>
    <?php elseif ($type === 'datetime'): ?>
      <input id="<?= $id ?>" type="datetime-local" name="<?= e($k) ?>" value="<?= $val ? e(date('Y-m-d\TH:i', strtotime((string)$val))) : '' ?>">
    <?php else: ?>
      <input id="<?= $id ?>" name="<?= e($k) ?>" value="<?= e($val) ?>"<?= in_array($type, ['number', 'money'], true) ? ' inputmode="numeric"' : '' ?>>
    <?php endif; ?>
    <?= field_error($errors, $k) ?></div>
  <?php endif; ?>
<?php endforeach; ?>
<p></p><button class="btn">Save</button> <a class="btn btn-quiet" href="/admin/r/<?= e($res) ?>">Cancel</a>
</form>
