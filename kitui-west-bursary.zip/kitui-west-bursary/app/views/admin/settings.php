<p class="crumbs"><a href="/admin">Administration</a> › Settings</p>
<h1>System settings</h1>
<form method="post" action="/admin/settings" class="panel narrow"><?= csrf_field() ?>
<?php foreach (EDITABLE_SETTINGS as $k => [$label, $type]): ?>
<?php if ($type === 'roles'): $on = explode(',', $vals[$k]); ?>
<fieldset class="field"><legend><?= e($label) ?></legend><div class="choice-list">
<?php foreach (DB::all('SELECT slug, name FROM roles WHERE is_staff = 1 ORDER BY id') as $r): ?>
  <label class="check"><input type="checkbox" name="<?= e($k) ?>[]" value="<?= e($r['slug']) ?>" <?= checked(in_array($r['slug'], $on, true) || $r['slug'] === 'admin') ?><?= $r['slug'] === 'admin' ? ' disabled' : '' ?>> <?= e($r['name']) ?></label>
<?php endforeach; ?></div><p class="hint">Recommended: Approver, Finance and Auditor. Staff set it up with an authenticator app at their next login.</p></fieldset>
<?php continue; endif; ?>
<div class="field<?= isset($errors[$k]) ? ' has-error' : '' ?>"><label for="s_<?= e($k) ?>"><?= e($label) ?></label>
<input id="s_<?= e($k) ?>" name="<?= e($k) ?>" type="<?= $type === 'number' ? 'number' : ($type === 'email' ? 'email' : 'text') ?>" value="<?= e($vals[$k]) ?>"><?= field_error($errors, $k) ?></div>
<?php endforeach; ?>
<p class="hint">Eligibility, amount bands, required documents and budgets are set per cycle under Administration → Bursary rules.</p>
<button class="btn">Save settings</button>
</form>
