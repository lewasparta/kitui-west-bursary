<div class="page-head"><h1>Administration</h1><p class="muted">Every change here is recorded in the audit trail with the old and new values.</p></div>
<?php if ($counts['no2fa']): ?><div class="flash flash-info"><?= (int)$counts['no2fa'] ?> active staff account(s) have not turned on two-step login. Administrators cannot work without it.</div><?php endif; ?>
<div class="stats">
  <a class="stat" href="/admin/users"><b><?= $counts['users'] ?></b><span>Staff users</span></a>
  <a class="stat" href="/admin/users?type=families"><b><?= $counts['families'] ?></b><span>Family accounts</span></a>
  <a class="stat" href="/admin/r/wards"><b><?= $counts['wards'] ?></b><span>Active wards</span></a>
  <a class="stat gold" href="/admin/r/institutions"><b><?= $counts['institutions'] ?></b><span>Institutions</span></a>
</div>
<div class="two-col">
<div class="panel"><h2>Configure</h2>
  <div class="stack">
    <p><a class="btn btn-gold btn-sm" href="/admin/security">Security checklist</a> Live check of HTTPS, keys, demo accounts, two-step login, SMS, backups and the audit chain.</p>
    <p><a class="btn btn-line btn-sm" href="/admin/users">Users &amp; roles</a> Staff accounts, roles, wards and approval limits.</p>
    <p><a class="btn btn-line btn-sm" href="/admin/settings">System settings</a> Office contacts, upload size, privacy threshold.</p>
    <p><a class="btn btn-line btn-sm" href="/admin/sms">SMS log</a> Every message sent and its delivery status.</p>
    <p><a class="btn btn-line btn-sm" href="/audit/logs">Audit log</a> Search the tamper-evident activity record.</p>
  </div>
  <h3>Bursary rules &amp; content</h3>
  <div class="btn-row"><?php foreach ($res as $k => $label): ?><a class="btn btn-sm btn-quiet" href="/admin/r/<?= e($k) ?>"><?= e($label) ?></a><?php endforeach; ?></div>
</div>
<div class="panel"><h2>Ward budgets<?= $cycle ? ' — ' . e($cycle['name']) : '' ?></h2>
<?php if (!$budget): ?><p class="muted">No budgets set for this cycle. <a href="/admin/r/budgets/new">Add ward budgets</a>.</p><?php else: ?>
  <?php foreach ($budget as $b): $pct = $b['amount'] > 0 ? min(100, round($b['committed'] / $b['amount'] * 100)) : 0; ?>
  <div class="bar-row"><span><?= e($b['name']) ?></span><div class="bar-track"><div class="bar-fill" style="width:<?= $pct ?>%"></div></div><span class="small num"><?= money($b['committed']) ?> / <?= money($b['amount']) ?></span></div>
  <?php endforeach; ?>
<?php endif; ?>
</div>
</div>
