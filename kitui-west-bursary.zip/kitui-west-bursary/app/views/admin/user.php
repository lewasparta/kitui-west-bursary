<?php $v = fn($k) => e($_POST[$k] ?? ($user[$k] ?? '')); $staff = !$user || $user['account_type'] === 'staff'; ?>
<p class="crumbs"><a href="/admin/users">Users</a> › <?= e($title) ?></p>
<h1><?= e($title) ?></h1>
<form method="post" action="/admin/users/save" class="panel narrow"><?= csrf_field() ?>
<?php if ($user): ?><input type="hidden" name="id" value="<?= (int)$user['id'] ?>"><?php endif; ?>
<div class="field<?= isset($errors['full_name']) ? ' has-error' : '' ?>"><label for="fn">Full name</label><input id="fn" name="full_name" value="<?= $v('full_name') ?>" required><?= field_error($errors, 'full_name') ?></div>
<div class="grid-2">
<div class="field<?= isset($errors['phone']) ? ' has-error' : '' ?>"><label for="ph">Mobile number (login)</label><input id="ph" name="phone" inputmode="tel" value="<?= $v('phone') ?>" required><?= field_error($errors, 'phone') ?></div>
<div class="field<?= isset($errors['email']) ? ' has-error' : '' ?>"><label for="em">Email</label><input id="em" type="email" name="email" value="<?= $v('email') ?>"><?= field_error($errors, 'email') ?></div>
</div>
<div class="field<?= isset($errors['national_id']) ? ' has-error' : '' ?>"><label for="ni">National ID number <span class="hint">Used to hide applications from officers related to the household.</span></label><input id="ni" name="national_id" inputmode="numeric" value="<?= $v('national_id') ?>"><?= field_error($errors, 'national_id') ?></div>
<?php if ($staff): ?>
<fieldset class="field<?= isset($errors['roles']) ? ' has-error' : '' ?>"><legend>Roles</legend>
  <div class="choice-list"><?php foreach ($roles as $r): ?><label class="check"><input type="checkbox" name="roles[]" value="<?= e($r['slug']) ?>" <?= checked(in_array($r['slug'], $mine, true)) ?>> <?= e($r['name']) ?></label><?php endforeach; ?></div>
  <?= field_error($errors, 'roles') ?>
  <p class="hint">Finance cannot be combined with committee/approver, and auditors hold no other role. The system also stops any person doing two steps on the same application.</p>
</fieldset>
<div class="grid-2">
<div class="field<?= isset($errors['ward_id']) ? ' has-error' : '' ?>"><label for="wd">Ward (ward officers)</label><select id="wd" name="ward_id"><option value="">All / not applicable</option><?php foreach ($wards as $w): ?><option value="<?= (int)$w['id'] ?>"<?= selected($_POST['ward_id'] ?? ($user['ward_id'] ?? ''), $w['id']) ?>><?= e($w['name']) ?></option><?php endforeach; ?></select><?= field_error($errors, 'ward_id') ?></div>
<div class="field<?= isset($errors['approval_limit']) ? ' has-error' : '' ?>"><label for="al">Approval limit, KES (approvers)</label><input id="al" name="approval_limit" inputmode="numeric" value="<?= $v('approval_limit') ?>"><?= field_error($errors, 'approval_limit') ?></div>
</div>
<?php endif; ?>
<label class="check"><input type="checkbox" name="is_active" value="1" <?= checked($user ? ($_POST ? isset($_POST['is_active']) : $user['is_active']) : true) ?>> Account active</label>
<?php if ($user): ?>
<label class="check"><input type="checkbox" name="reset_password" value="1"> Issue a new temporary password (sent by SMS, must be changed at login)</label>
<?php if ($user['totp_enabled']): ?><label class="check"><input type="checkbox" name="reset_2fa" value="1"> Reset two-step login (lost phone)</label><?php endif; ?>
<?php else: ?><p class="hint">A temporary password is created, shown to you once and sent to the user by SMS.</p><?php endif; ?>
<p></p><button class="btn">Save user</button>
</form>
