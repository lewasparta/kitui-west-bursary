<?php $labels = ['ok' => 'OK', 'warn' => 'Action recommended', 'bad' => 'Fix now', 'info' => 'Note']; ?>
<p class="crumbs"><a href="/admin">Administration</a> › Security checklist</p>
<div class="panel-head welcome"><div><p class="eyebrow eyebrow-gold">Checked live on this installation</p><h1>Security checklist</h1><p class="muted"><?= e($score) ?> checks passing. Re-open this page after any change.</p></div></div>
<div class="checks">
<?php foreach ($checks as $c): ?>
  <div class="check-row check-<?= e($c['state']) ?>">
    <span class="check-ico"><?= icon($c['state'] === 'ok' ? 'check' : ($c['state'] === 'info' ? 'help' : 'alert')) ?></span>
    <div><b><?= e($c['title']) ?></b> <span class="badge <?= ['ok' => 'badge-ok', 'warn' => 'badge-warn', 'bad' => 'badge-bad', 'info' => 'badge-muted'][$c['state']] ?>"><?= e($labels[$c['state']]) ?></span>
      <p><?= e($c['detail']) ?></p><?php if ($c['fix']): ?><p class="small check-fix"><?= icon('arrow') ?> <?= e($c['fix']) ?></p><?php endif; ?></div>
  </div>
<?php endforeach; ?>
</div>
<div class="panel">
  <h2>Security events in the last 24 hours</h2>
  <?php if (!$events): ?><p class="muted">None.</p><?php else: ?>
  <ul><?php foreach ($events as $ev): ?><li><b><?= (int)$ev['n'] ?></b> × <?= e(str_replace('_', ' ', $ev['action'])) ?></li><?php endforeach; ?></ul>
  <p class="small"><a href="/audit/logs?category=security">See the details in the audit log</a></p>
  <?php endif; ?>
</div>
