<div class="panel-head"><h1>Users</h1><a class="btn btn-sm" href="/admin/users/new">New staff user</a></div>
<form method="get" class="filters panel"><input type="hidden" name="type" value="<?= e($type) ?>">
  <div class="field"><label for="q">Search name or phone</label><input id="q" name="q" value="<?= e(input('q', '')) ?>"></div>
  <button class="btn btn-sm btn-line">Search</button>
  <div class="btn-row"><a class="btn btn-sm <?= $type === 'staff' ? '' : 'btn-quiet' ?>" href="/admin/users">Staff</a><a class="btn btn-sm <?= $type === 'families' ? '' : 'btn-quiet' ?>" href="/admin/users?type=families">Families &amp; students</a></div>
</form>
<div class="table-wrap"><table class="cards"><thead><tr><th>Name</th><th>Phone</th><th><?= $type === 'staff' ? 'Roles' : 'Account' ?></th><th>Ward</th><th>2FA</th><th>Status</th><th></th></tr></thead><tbody>
<?php foreach ($p['rows'] as $r): ?>
<tr><td data-label="Name"><?= e($r['full_name']) ?></td><td data-label="Phone"><?= e($r['phone']) ?></td>
<td data-label="<?= $type === 'staff' ? 'Roles' : 'Account' ?>"><?= e($type === 'staff' ? (string)$r['role_names'] : ucfirst($r['account_type'])) ?><?= $r['approval_limit'] ? '<div class="small muted">Limit ' . money($r['approval_limit']) . '</div>' : '' ?></td>
<td data-label="Ward"><?= e($r['ward_name'] ?? '—') ?></td>
<td data-label="2FA"><?= $r['totp_enabled'] ? '<span class="badge badge-ok">On</span>' : '<span class="badge badge-muted">Off</span>' ?></td>
<td data-label="Status"><?= $r['is_active'] ? ($r['locked_until'] && strtotime($r['locked_until']) > time() ? '<span class="badge badge-bad">Locked</span>' : '<span class="badge badge-ok">Active</span>') : '<span class="badge badge-muted">Disabled</span>' ?></td>
<td><a class="btn btn-sm btn-line" href="/admin/users/<?= (int)$r['id'] ?>">Edit</a></td></tr>
<?php endforeach; ?>
</tbody></table></div>
<?= partial('pager', ['p' => $p]) ?>
