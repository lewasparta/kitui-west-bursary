<?php $micro = str_repeat('KITUI WEST BURSARY · ' . $doc['code'] . ' · SEALED · ', 14); ?>
<div class="toolbar no-print">
  <a href="<?= Auth::isStaff() ? '/staff/applications/' . (int)$a['id'] : '/portal/applications/' . (int)$a['id'] ?>">← Back</a>
  <span>Official sealed sheet. Print it, or choose “Save as PDF” in the print window.</span>
  <button type="button" data-print>Print / Save PDF</button>
</div>
<article class="sheet">
  <div class="sheet-guilloche" aria-hidden="true"></div>
  <div class="sheet-watermark" aria-hidden="true"><?php for ($i = 0; $i < 6; $i++): ?><span><?= e($doc['code']) ?> · ORIGINAL</span><?php endfor; ?></div>
  <div class="sheet-inner">
    <header class="sheet-head">
      <img src="<?= asset('img/logo.svg') ?>" alt="" width="64" height="64">
      <div class="sheet-org"><b>KITUI WEST DIGITAL BURSARY</b><span>Student Support &amp; Development Platform</span><i>Transparent Support. Brighter Futures.</i></div>
      <div class="sheet-serial"><span>Document code</span><b><?= e($doc['code']) ?></b><span>Issued <?= e(fmt_date($doc['issued_at'], 'j M Y')) ?></span></div>
    </header>
    <div class="micro" aria-hidden="true"><?= e($micro) ?></div>
    <h1 class="sheet-title"><?= e($title) ?></h1>
    <?php if (!empty($body['to'])): ?><p><b>To:</b> <?= e($body['to']) ?></p><?php endif; ?>
    <p class="sheet-intro"><?= e($body['intro']) ?></p>

    <table class="sheet-facts">
      <?php foreach ($public as $k => $v): ?><tr><th><?= e($k) ?></th><td><?= e($v) ?></td></tr><?php endforeach; ?>
    </table>

    <?php if ($rows): ?>
    <table class="sheet-rows"><thead><tr><th>Cycle</th><th>Reference</th><th>Institution</th><th>Paid on</th><th>Payment ref.</th><th class="r">Amount</th></tr></thead>
      <tbody><?php foreach ($rows as $r): ?><tr><?php foreach ($r as $i => $c): ?><td<?= $i === 5 ? ' class="r"' : '' ?>><?= e($c) ?></td><?php endforeach; ?></tr><?php endforeach; ?></tbody></table>
    <?php endif; ?>

    <?php if (!empty($body['chief'])): ?>
    <section class="chief">
      <h2>For the Chief / Assistant Chief</h2>
      <div class="chief-q">Is the student a resident of your area? &nbsp; ☐ Yes &nbsp; ☐ No</div>
      <div class="chief-q">Family circumstances and need (your comments):</div>
      <div class="lines"><span></span><span></span><span></span><span></span></div>
      <div class="chief-sign">
        <div><label>Name</label><span></span></div><div><label>Location / sub-location</label><span></span></div>
        <div><label>Signature</label><span></span></div><div><label>Date</label><span></span></div>
      </div>
      <div class="stamp-box">Official stamp</div>
    </section>
    <?php endif; ?>

    <?php if ($kind === 'award_letter'): ?>
      <div class="sign-row"><div><span class="sig-line"></span>Bursary Committee Secretary</div><div><span class="sig-line"></span>Fund Account Manager</div></div>
    <?php endif; ?>

    <footer class="sheet-foot">
      <div class="qr-box" data-qr="<?= e($verifyUrl) ?>" role="img" aria-label="QR code linking to the verification page"></div>
      <div class="verify-text">
        <b>Check that this document is genuine</b>
        <p>Scan the QR code, or visit <b><?= e(preg_replace('#^https?://#', '', abs_url('/verify'))) ?></b> and enter the code <b class="code"><?= e($doc['code']) ?></b>. The details shown online must match this paper exactly. Any difference means the sheet was altered.</p>
        <p class="seal">Seal fingerprint: <b><?= e(Seal::fingerprint($doc)) ?></b> · Only this system can issue these sheets. Copies made or edited elsewhere cannot produce a valid code.</p>
      </div>
    </footer>
    <div class="micro" aria-hidden="true"><?= e(implode("", array_reverse(mb_str_split($micro)))) ?></div>
  </div>
</article>
