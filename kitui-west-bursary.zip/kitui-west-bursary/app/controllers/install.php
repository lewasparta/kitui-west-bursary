<?php
declare(strict_types=1);

/** Shown instead of the site until installation is complete. One screen, one button. */
function install_handle(): never
{
    $v = [
        'host' => trim((string)($_POST['host'] ?? '127.0.0.1')), 'port' => trim((string)($_POST['port'] ?? '3306')),
        'db' => trim((string)($_POST['db'] ?? 'kwb')), 'user' => trim((string)($_POST['user'] ?? 'root')),
        'pass' => (string)($_POST['pass'] ?? ''), 'demo' => $_SERVER['REQUEST_METHOD'] === 'POST' ? isset($_POST['demo']) : true,
        'admin_name' => trim((string)($_POST['admin_name'] ?? '')), 'admin_phone' => trim((string)($_POST['admin_phone'] ?? '')),
        'admin_pass' => (string)($_POST['admin_pass'] ?? ''),
    ];
    $error = null;
    // On this computer (XAMPP) no code is needed. From the internet, the installer asks for a one-time
    // code stored in a server file, so only someone with access to the server's files can install.
    $needCode = !is_local_request();
    $codeFile = BASE_PATH . '/storage/install-code.txt';
    if ($needCode && !is_file($codeFile)) {
        @file_put_contents($codeFile, strtoupper(bin2hex(random_bytes(5))) . "\n");
    }
    $v['need_code'] = $needCode;
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        csrf_check();
        rate_limit_soft_install();
        if ($needCode && !hash_equals(trim((string)@file_get_contents($codeFile)), strtoupper(trim((string)($_POST['install_code'] ?? ''))))) {
            $error = 'The installation code is not correct. Open the file storage/install-code.txt on the server to find it.';
        } else {
            $error = install_run($v);
            if ($error === null) {
                @unlink($codeFile);
            }
        }
        if ($error === null) {
            install_page('done', $v, null);
        }
    }
    // Friendly status: can we reach the database with the current settings?
    $status = null;
    try {
        $pdo = Installer::serverPdo($v['host'], $v['port'], $v['user'], $v['pass']);
        $status = ['ok', 'Database server found: ' . $pdo->query('SELECT VERSION()')->fetchColumn()];
    } catch (Throwable $e) {
        $status = ['bad', install_db_message($e)];
    }
    install_page('form', $v, $error, $status);
}

/** Simple per-session throttle (the database may not exist yet, so the DB-backed limiter cannot be used). */
function rate_limit_soft_install(): void
{
    $_SESSION['install_tries'] = array_values(array_filter($_SESSION['install_tries'] ?? [], fn($t) => $t > time() - 600));
    if (count($_SESSION['install_tries']) >= 10) {
        http_response_code(429);
        exit('Too many attempts. Wait 10 minutes.');
    }
    $_SESSION['install_tries'][] = time();
}

function install_db_message(Throwable $e): string
{
    $code = $e instanceof PDOException ? (int)($e->errorInfo[1] ?? $e->getCode()) : 0;
    return match (true) {
        in_array($code, [2002, 2006], true) => 'The database server is not running. In the XAMPP Control Panel, press Start next to MySQL, then reload this page.',
        $code === 1045 => 'The database username or password is not accepted. XAMPP normally uses username root with an empty password.',
        default => 'Could not connect to the database (' . $code . ').',
    };
}

function install_run(array &$v): ?string
{
    if (!preg_match('/^[A-Za-z0-9_]{1,64}$/', $v['db'])) {
        return 'Database name may contain only letters, numbers and underscores.';
    }
    if (preg_match('/[\r\n]/', $v['pass'] . $v['user'] . $v['host'])) {
        return 'Settings may not contain line breaks.';
    }
    if (!ctype_digit($v['port'])) {
        return 'Port must be a number (usually 3306).';
    }
    $adminWanted = $v['admin_name'] !== '' || $v['admin_phone'] !== '' || $v['admin_pass'] !== '';
    if (!$v['demo'] && !$adminWanted) {
        return 'Without demo accounts, fill in the administrator details so you can log in.';
    }
    if ($adminWanted) {
        if (mb_strlen($v['admin_name']) < 3) {
            return 'Enter the administrator’s full name.';
        }
        if (!preg_match('/^(?:\+?254|0)(7|1)\d{8}$/', preg_replace('/\s+/', '', $v['admin_phone']))) {
            return 'Enter the administrator’s mobile number, e.g. 0712345678.';
        }
        if ($p = Auth::passwordProblems($v['admin_pass'])) {
            return 'Administrator password: ' . $p;
        }
    }
    if (!is_writable(BASE_PATH) || !is_writable(BASE_PATH . '/storage')) {
        return 'The project folder is not writable, so the settings file cannot be saved. Give the web server write access to the folder and its storage/ folder.';
    }
    try {
        $pdo = Installer::serverPdo($v['host'], $v['port'], $v['user'], $v['pass']);
    } catch (Throwable $e) {
        return install_db_message($e);
    }
    // Find a usable database. A database name is skipped automatically when it holds other tables,
    // a half-finished earlier attempt, or leftover table files from a failed import — the XAMPP/MariaDB
    // "#1813 Tablespace exists" (errno 184) problem. Nothing in an existing database is ever deleted.
    $base = $v['db'];
    $reuse = false;
    $seeded = false;
    $last = '';
    for ($n = 1; $n <= 9; $n++) {
        $name = $n === 1 ? $base : $base . '_' . $n;
        try {
            $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . $name . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
            $pdo->exec('USE `' . $name . '`');
            $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
            $complete = in_array('roles', $tables, true) && in_array('settings', $tables, true)
                && (int)$pdo->query('SELECT COUNT(*) FROM roles')->fetchColumn() > 0
                && in_array('audit_logs', $tables, true) && count($tables) >= 40;
            if ($complete) {
                $reuse = true;
                $seeded = (int)$pdo->query('SELECT COUNT(*) FROM wards')->fetchColumn() > 0;
            } elseif ($tables) {
                $last = 'database “' . $name . '” already holds other or incomplete tables';
                continue; // never touch it; try the next name
            } else {
                Installer::runSqlFile($pdo, BASE_PATH . '/database/schema.sql');
            }
            $v['db'] = $name;
            $v['db_note'] = $name !== $base ? $last : '';
            break;
        } catch (Throwable $e) {
            $code = $e instanceof PDOException ? (int)($e->errorInfo[1] ?? 0) : 0;
            $msg = $e->getMessage();
            error_log('[install] ' . $name . ': ' . $msg);
            $tablespace = $code === 1813 || ($code === 1005 && str_contains($msg, '184')) || stripos($msg, 'tablespace') !== false;
            if ($tablespace || $code === 1050) {
                $last = 'database “' . $name . '” has leftover table files from an earlier failed import (error #1813)';
                continue;
            }
            return 'Creating the tables failed: ' . $msg;
        }
    }
    if (!isset($v['db_note'])) {
        return 'Could not find a clean database to install into (' . $last . '). In phpMyAdmin create an empty database with a new name and type that name under Database settings.';
    }

    // Keep existing secret keys if a settings file is already there (never break issued sheets).
    $old = is_file(BASE_PATH . '/.env') ? (string)file_get_contents(BASE_PATH . '/.env') : '';
    $env = Installer::envContent(['url' => APP_URL, 'host' => $v['host'], 'port' => $v['port'], 'db' => $v['db'], 'user' => $v['user'], 'pass' => $v['pass']]);
    foreach (['APP_KEY', 'APP_SEAL_KEY'] as $k) {
        if (preg_match('/^' . $k . '=([A-Za-z0-9]{32,})\s*$/m', $old, $m)) {
            $env = preg_replace('/^' . $k . '=.*$/m', $k . '=' . $m[1], $env);
        }
    }
    if (file_put_contents(BASE_PATH . '/.env', $env) === false) {
        return 'Could not save the settings file (.env).';
    }
    Installer::loadEnv($env);

    try {
        if (!$seeded) {
            Installer::seed($v['demo']);
        }
        if ($adminWanted) {
            $phone = normalize_phone($v['admin_phone']);
            if (!DB::val('SELECT 1 FROM users WHERE phone = ?', [$phone])) {
                $id = DB::insert('users', ['full_name' => $v['admin_name'], 'phone' => $phone, 'password_hash' => Auth::hashPassword($v['admin_pass']), 'account_type' => 'staff']);
                DB::run("INSERT INTO user_roles (user_id, role_id) SELECT ?, id FROM roles WHERE slug = 'admin'", [$id]);
                Audit::log('config', 'admin_created_installer', 'user', $id, [], null);
            }
        }
    } catch (Throwable $e) {
        error_log('[install] ' . $e->getMessage());
        return 'Loading the starter data failed: ' . $e->getMessage();
    }
    Installer::markInstalled();
    return null;
}

function install_page(string $mode, array $v, ?string $error, ?array $status = null): never
{
    http_response_code($error ? 422 : 200);
    header('Content-Type: text/html; charset=utf-8');
    $b = BASE_URL;
    $h = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES);
    ?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Install — Kitui West Digital Bursary</title>
<link rel="icon" href="<?= $h($b) ?>/assets/img/logo.svg" type="image/svg+xml">
<link rel="stylesheet" href="<?= $h($b) ?>/assets/css/app.css"></head>
<body class="setup-body">
<main class="setup-card install">
  <div class="install-top"><img src="<?= $h($b) ?>/assets/img/logo.svg" alt="" width="58" height="58"><div><p class="eyebrow">Kitui West Digital Bursary</p><h1><?= $mode === 'done' ? 'Installed — ready to use' : 'Install in one click' ?></h1></div></div>
<?php if ($mode === 'done'): ?>
  <p class="install-ok"><?= icon('check') ?> Settings saved with new secret keys, database <b><?= $h($v['db']) ?></b> created, tables and starter data loaded.</p>
  <?php if (!empty($v['db_note'])): ?><div class="flash flash-info">Note: the <?= $h($v['db_note']) ?>, so the system was installed into <b><?= $h($v['db']) ?></b> instead. Nothing was deleted. You may remove the old one later (see README, “Error #1813”).</div><?php endif; ?>
  <?php if ($v['demo']): ?>
  <h2>Demo logins</h2>
  <p class="small">Password for every demo account: <code>Demo@2026pass</code></p>
  <table class="install-table"><tbody>
    <tr><td>Parent</td><td><code>0711000001</code></td></tr>
    <tr><td>Document officer</td><td><code>0700000002</code></td></tr>
    <tr><td>Ward officer (Matinyani)</td><td><code>0700000003</code></td></tr>
    <tr><td>Committee</td><td><code>0700000005</code></td></tr>
    <tr><td>Approver</td><td><code>0700000007</code></td></tr>
    <tr><td>Finance (two officers)</td><td><code>0700000009</code> · <code>0700000010</code></td></tr>
    <tr><td>Auditor</td><td><code>0700000011</code></td></tr>
    <tr><td>Administrator</td><td><code>0700000001</code> <span class="small">(asks you to set up an authenticator app at first login)</span></td></tr>
  </tbody></table>
  <?php endif; ?>
  <?php if ($v['admin_phone'] !== ''): ?><p>Your administrator login: <code><?= $h(normalize_phone($v['admin_phone'])) ?></code> with the password you chose. At first login you will link an authenticator app (Google Authenticator or Microsoft Authenticator).</p><?php endif; ?>
  <p class="small muted">Before real use: remove demo accounts (Administration → Users → disable), set the office phone/email under Administration → Settings, and read README.md for SMS and backups.</p>
  <div class="btn-row"><a class="btn btn-gold btn-lg" href="<?= $h($b) ?>/">Open the website <?= icon('arrow') ?></a><a class="btn btn-line btn-lg" href="<?= $h($b) ?>/login">Log in</a></div>
<?php else: ?>
  <p>This sets everything up for you: settings file, secret keys, database, tables and starter data (Kitui West wards, institutions, an open application cycle, FAQs and mentorship events).</p>
  <?php if ($status): ?><p class="install-status install-<?= $status[0] ?>"><?= icon($status[0] === 'ok' ? 'check' : 'alert') ?> <?= $h($status[1]) ?></p><?php endif; ?>
  <?php if ($error): ?><div class="flash flash-error"><?= $h($error) ?></div><?php endif; ?>
  <form method="post" action="<?= $h($b) ?>/install">
    <?= csrf_field() ?>
    <?php if (!empty($v['need_code'])): ?>
      <div class="field"><label for="ic">Installation code <span class="hint">This site is being installed from the internet. For safety, open the file <code>storage/install-code.txt</code> on the server and type the code here.</span></label>
      <input id="ic" name="install_code" type="text" autocomplete="off" required></div>
    <?php endif; ?>
    <label class="check install-demo"><input type="checkbox" name="demo" value="1" <?= $v['demo'] ? 'checked' : '' ?>> <span><b>Include demo accounts</b><br><span class="small muted">One login per role so you can try the full journey. Recommended for testing.</span></span></label>
    <details class="install-more"<?= ($status && $status[0] === 'bad') || $error ? ' open' : '' ?>>
      <summary>Database settings <span class="small muted">— XAMPP defaults already filled in</span></summary>
      <div class="grid-2">
        <div class="field"><label for="host">Server</label><input id="host" name="host" type="text" value="<?= $h($v['host']) ?>"></div>
        <div class="field"><label for="port">Port</label><input id="port" name="port" type="text" inputmode="numeric" value="<?= $h($v['port']) ?>"></div>
        <div class="field"><label for="user">Username</label><input id="user" name="user" type="text" value="<?= $h($v['user']) ?>"></div>
        <div class="field"><label for="pass">Password <span class="hint">(empty on XAMPP)</span></label><input id="pass" name="pass" type="password" value="<?= $h($v['pass']) ?>"></div>
      </div>
      <div class="field"><label for="db">Database name</label><input id="db" name="db" type="text" value="<?= $h($v['db']) ?>"></div>
    </details>
    <details class="install-more">
      <summary>Your own administrator account <span class="small muted">— optional</span></summary>
      <div class="field"><label for="an">Full name</label><input id="an" name="admin_name" type="text" value="<?= $h($v['admin_name']) ?>"></div>
      <div class="grid-2">
        <div class="field"><label for="ap">Mobile number</label><input id="ap" name="admin_phone" type="tel" value="<?= $h($v['admin_phone']) ?>" placeholder="07XXXXXXXX"></div>
        <div class="field"><label for="apw">Password</label><input id="apw" name="admin_pass" type="password" placeholder="At least 10 characters"></div>
      </div>
    </details>
    <button class="btn btn-gold btn-lg install-btn"><?= icon('check') ?> Install now</button>
  </form>
  <p class="small muted">This page disappears for good once installation finishes.</p>
<?php endif; ?>
</main>
</body></html>
<?php
    exit;
}
