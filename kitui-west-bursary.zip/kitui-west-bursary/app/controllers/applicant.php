<?php
declare(strict_types=1);

const WIZARD = [1 => 'Applicant', 2 => 'Student', 3 => 'Education', 4 => 'Household', 5 => 'Documents', 6 => 'Review', 7 => 'Declaration'];
const EDITABLE = ['draft', 'returned'];

function applicant_user(): array
{
    $u = Auth::require('parent', 'student');
    return $u;
}

/** Applications this account may see: ones it made, or (for students) ones about the student linked to it. */
function applicant_app(int $id, bool $mustEdit = false): array
{
    $u = applicant_user();
    $a = Workflow::app($id);
    $linked = DB::val('SELECT 1 FROM students WHERE id = ? AND user_id = ?', [$a['student_id'], $u['id']]);
    if ((int)$a['applicant_user_id'] !== (int)$u['id'] && !$linked) {
        Audit::log('access', 'forbidden_application', 'application', $id);
        abort(404);
    }
    if ($mustEdit && ((int)$a['applicant_user_id'] !== (int)$u['id'] || !in_array($a['status'], EDITABLE, true))) {
        flash('info', 'This application can no longer be changed.');
        redirect('/portal/applications/' . $id);
    }
    return $a;
}

function applicant_dashboard(): void
{
    $u = applicant_user();
    $apps = DB::all("SELECT a.*, s.first_name, s.last_name, i.name AS institution_name, c.name AS cycle_name
        FROM applications a JOIN application_cycles c ON c.id = a.cycle_id
        LEFT JOIN students s ON s.id = a.student_id LEFT JOIN institutions i ON i.id = a.institution_id
        WHERE a.applicant_user_id = ? OR s.user_id = ? ORDER BY a.created_at DESC", [$u['id'], $u['id']]);
    $cycle = current_cycle();
    $continuable = [];
    if ($cycle) {
        $continuable = DB::all("SELECT a.id, a.reference, s.id AS student_id, s.first_name, s.last_name FROM applications a JOIN students s ON s.id = a.student_id
            WHERE a.applicant_user_id = ? AND a.cycle_id <> ? AND a.status IN ('approved','partially_approved','ready_for_payment','payment_processing','disbursed','closed','not_approved')
            AND a.id = (SELECT MAX(a2.id) FROM applications a2 WHERE a2.student_id = a.student_id AND a2.status NOT IN ('draft','withdrawn'))
            AND NOT EXISTS (SELECT 1 FROM applications x WHERE x.student_id = a.student_id AND x.cycle_id = ?)", [$u['id'], $cycle['id'], $cycle['id']]);
    }
    $notes = DB::all('SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 4', [$u['id']]);
    render('applicant/dashboard', ['title' => 'My applications', 'u' => $u, 'apps' => $apps, 'cycle' => $cycle, 'continuable' => $continuable, 'notes' => $notes]);
}

function applicant_start(): void
{
    $u = applicant_user();
    $cycle = current_cycle();
    if (!$cycle) {
        flash('error', 'Applications are closed. Check the application period page for the next cycle.');
        redirect('/portal');
    }
    rate_limit('start_app', 10, 3600, (string)$u['id']);
    $drafts = (int)DB::val("SELECT COUNT(*) FROM applications WHERE applicant_user_id = ? AND cycle_id = ? AND status = 'draft'", [$u['id'], $cycle['id']]);
    if ($drafts >= 3) {
        flash('error', 'Finish or delete one of your drafts before starting another.');
        redirect('/portal');
    }
    $prevId = input_int('continue_from');
    $data = ['cycle_id' => $cycle['id'], 'applicant_user_id' => $u['id'], 'student_access_code' => strtoupper(bin2hex(random_bytes(4)))];
    if ($prevId) {
        $prev = DB::one("SELECT * FROM applications WHERE id = ? AND applicant_user_id = ? AND status NOT IN ('draft','withdrawn')", [$prevId, $u['id']]) ?? abort(404);
        if (DB::val('SELECT 1 FROM applications WHERE student_id = ? AND cycle_id = ?', [$prev['student_id'], $cycle['id']])) {
            flash('error', 'This student already has an application in the current cycle.');
            redirect('/portal');
        }
        $data += [
            'student_id' => $prev['student_id'], 'guardian_id' => $prev['guardian_id'], 'guardian_relationship' => $prev['guardian_relationship'],
            'institution_id' => $prev['institution_id'], 'level' => $prev['level'], 'admission_no' => $prev['admission_no'],
            'household_size' => $prev['household_size'], 'siblings_in_school' => $prev['siblings_in_school'],
            'parental_status' => $prev['parental_status'], 'income_band' => $prev['income_band'],
            'is_continuation' => 1, 'previous_application_id' => $prev['id'], 'wizard_step' => 3,
        ];
    }
    $id = DB::tx(function () use ($data, $prevId) {
        $id = DB::insert('applications', $data);
        Workflow::event($id, 'applicant', $prevId ? 'continuation_started' : 'draft_started', null, true);
        if ($prevId) {
            // Carry over documents that do not change between years and were already verified.
            DB::run("INSERT INTO documents (application_id, document_type_id, storage_driver, storage_key, original_name, mime, size_bytes, sha256, status, uploaded_by, verified_by, verified_at)
                SELECT ?, d.document_type_id, d.storage_driver, d.storage_key, d.original_name, d.mime, d.size_bytes, d.sha256, 'verified', d.uploaded_by, d.verified_by, d.verified_at
                FROM documents d JOIN document_types t ON t.id = d.document_type_id
                WHERE d.application_id = ? AND d.status = 'verified' AND t.code IN ('birth_cert','death_cert')", [$id, $prevId]);
        }
        Audit::log('data', 'application_draft_created', 'application', $id, ['continuation_of' => $prevId]);
        return $id;
    });
    redirect('/portal/applications/' . $id . '/step/' . ($prevId ? 3 : 1));
}

function applicant_step(string $id, string $step): void
{
    $a = applicant_app((int)$id, true);
    $step = max(1, min(7, (int)$step));
    if ($step > (int)$a['wizard_step'] + 1 && $step > 1) {
        redirect('/portal/applications/' . $id . '/step/' . min(7, (int)$a['wizard_step']));
    }
    render('applicant/wizard', applicant_step_data($a, $step, []));
}

function applicant_step_data(array $a, int $step, array $errors): array
{
    $u = Auth::user();
    $draft = json_decode($a['draft_data'] ?? '{}', true) ?: [];
    $d = [
        'title' => WIZARD[$step] . ' — application', 'a' => $a, 'step' => $step, 'errors' => $errors, 'u' => $u,
        'draft' => $draft[$step] ?? [], 'wards' => DB::all('SELECT id, name FROM wards WHERE is_active = 1 ORDER BY name'),
    ];
    if ($step === 2) {
        $d['children'] = DB::all("SELECT s.id, s.first_name, s.last_name, s.verified_at FROM students s JOIN student_guardians sg ON sg.student_id = s.id JOIN guardians g ON g.id = sg.guardian_id
            WHERE g.user_id = ? AND NOT EXISTS (SELECT 1 FROM applications x WHERE x.student_id = s.id AND x.cycle_id = ? AND x.id <> ?)", [$u['id'], $a['cycle_id'], $a['id']]);
        $d['student'] = $a['student_id'] ? DB::one('SELECT * FROM students WHERE id = ?', [$a['student_id']]) : null;
    }
    if ($step === 3) {
        $d['levels'] = DB::all('SELECT * FROM cycle_levels WHERE cycle_id = ? AND is_eligible = 1', [$a['cycle_id']]);
        $d['institutions'] = DB::all('SELECT id, name, level FROM institutions WHERE is_active = 1 ORDER BY name');
    }
    if ($step === 5 || $step === 6) {
        $d['docTypes'] = applicant_doc_types($a);
        $d['docs'] = applicant_docs((int)$a['id']);
        $d['chiefForm'] = DB::one("SELECT code FROM issued_documents WHERE application_id = ? AND kind = 'recommendation_form' AND revoked_at IS NULL", [$a['id']]);
        $d['maxMb'] = (int)setting('max_upload_mb', '8');
    }
    if ($step >= 6) {
        $d['missing'] = applicant_missing($a);
    }
    return $d;
}

function applicant_doc_types(array $a): array
{
    return DB::all("SELECT t.id, t.code, t.name, t.description, MAX(cd.is_required) AS is_required
        FROM cycle_documents cd JOIN document_types t ON t.id = cd.document_type_id
        WHERE cd.cycle_id = ? AND t.staff_only = 0 AND t.is_active = 1 AND (cd.level = 'all' OR cd.level = ?)
        GROUP BY t.id, t.code, t.name, t.description ORDER BY MAX(cd.is_required) DESC, t.id", [$a['cycle_id'], $a['level'] ?? 'secondary']);
}

function applicant_docs(int $appId): array
{
    $rows = DB::all("SELECT d.*, t.code FROM documents d JOIN document_types t ON t.id = d.document_type_id WHERE d.application_id = ? AND d.status <> 'superseded' AND d.field_visit_id IS NULL ORDER BY d.id", [$appId]);
    $by = [];
    foreach ($rows as $r) {
        $by[$r['document_type_id']][] = $r;
    }
    return $by;
}

/** Everything still needed before the application can be submitted (rules come from the cycle configuration). */
function applicant_missing(array $a): array
{
    $m = [];
    if (!$a['guardian_id']) { $m[1] = 'Applicant and guardian details'; }
    if (!$a['student_id']) { $m[2] = 'Student details'; }
    if (!$a['institution_id'] || !$a['amount_requested']) { $m[3] = 'Education details and amount requested'; }
    if (!$a['parental_status'] || !$a['household_size']) { $m[4] = 'Household details'; }
    $docs = applicant_docs((int)$a['id']);
    $need = [];
    foreach (applicant_doc_types($a) as $t) {
        if ($t['is_required'] && empty($docs[$t['id']])) {
            $need[] = $t['name'];
        }
        foreach ($docs[$t['id']] ?? [] as $d) {
            if ($d['status'] === 'rejected') {
                $need[] = $t['name'] . ' (replace the rejected file)';
            }
        }
    }
    if ($need) { $m[5] = 'Documents: ' . implode(', ', $need); }
    return $m;
}

function applicant_saveStep(string $id, string $step): void
{
    $a = applicant_app((int)$id, true);
    $step = (int)$step;
    $errors = applicant_persist($a, $step, $_POST, false);
    if ($errors) {
        $a = Workflow::app((int)$id);
        render('applicant/wizard', applicant_step_data($a, $step, $errors));
    }
    $go = (string)input('go', 'next');
    if ($go === 'exit') {
        flash('success', 'Saved. You can continue any time before the closing date.');
        redirect('/portal');
    }
    redirect('/portal/applications/' . $id . '/step/' . min(7, $step + 1));
}

/** Autosave keeps unvalidated keystrokes in draft_data so nothing is lost on a dropped connection. */
function applicant_autosave(string $id): void
{
    $a = applicant_app((int)$id);
    if ((int)$a['applicant_user_id'] !== Auth::id() || !in_array($a['status'], EDITABLE, true)) {
        json_out(['ok' => false], 409);
    }
    rate_limit('autosave', 120, 600, (string)Auth::id());
    $step = (int)input('step');
    if ($step < 1 || $step > 4) {
        json_out(['ok' => false], 422);
    }
    $fields = array_diff_key($_POST, ['_csrf' => 1, 'step' => 1, 'go' => 1]);
    $fields = array_map(fn($v) => is_string($v) ? mb_substr($v, 0, 1000) : '', array_slice($fields, 0, 30, true));
    // Read-modify-write in PHP (portable across MySQL 8 and MariaDB/XAMPP), locked to avoid lost updates.
    DB::tx(function () use ($a, $step, $fields) {
        $cur = DB::val('SELECT draft_data FROM applications WHERE id = ? FOR UPDATE', [$a['id']]);
        $draft = json_decode((string)$cur, true) ?: [];
        $draft[(string)$step] = $fields;
        DB::run('UPDATE applications SET draft_data = ? WHERE id = ?', [json_encode($draft, JSON_UNESCAPED_UNICODE), $a['id']]);
    });
    json_out(['ok' => true, 'saved_at' => date('H:i')]);
}

function applicant_persist(array $a, int $step, array $d, bool $lenient): array
{
    $u = Auth::user();
    $appId = (int)$a['id'];
    $errors = [];
    switch ($step) {
        case 1:
            $errors = validate($d, [
                'guardian_full_name' => 'required|min:3|max:120', 'guardian_phone' => 'required|phone',
                'guardian_national_id' => 'required|nid', 'guardian_occupation' => 'max:80',
                'guardian_relationship' => 'required|in:mother,father,guardian,grandparent,sibling,other',
            ], ['guardian_full_name' => 'Parent or guardian name', 'guardian_phone' => 'Parent or guardian phone', 'guardian_national_id' => 'Parent or guardian ID number', 'guardian_relationship' => 'Relationship']);
            if ($errors) { return $errors; }
            DB::tx(function () use ($a, $d, $u, $appId) {
                $row = ['full_name' => trim($d['guardian_full_name']), 'phone' => normalize_phone($d['guardian_phone']),
                    'national_id' => trim($d['guardian_national_id']), 'occupation' => trim((string)($d['guardian_occupation'] ?? '')) ?: null];
                $gid = $a['guardian_id'];
                if (!$gid && $u['account_type'] === 'parent') {
                    $gid = DB::val('SELECT id FROM guardians WHERE user_id = ? ORDER BY id LIMIT 1', [$u['id']]);
                }
                if ($gid) {
                    DB::update('guardians', $row, 'id = ?', [$gid]);
                } else {
                    $gid = DB::insert('guardians', $row + ['user_id' => $u['account_type'] === 'parent' ? $u['id'] : null]);
                }
                if ($a['student_id']) {
                    DB::run('INSERT INTO student_guardians (student_id, guardian_id, relationship) VALUES (?,?,?) ON DUPLICATE KEY UPDATE relationship = VALUES(relationship)', [$a['student_id'], $gid, $d['guardian_relationship']]);
                }
                applicant_update($appId, ['guardian_id' => $gid, 'guardian_relationship' => $d['guardian_relationship']], 1);
            });
            break;

        case 2:
            $existing = input_int('existing_student');
            if ($existing) {
                $ok = DB::val('SELECT 1 FROM students s JOIN student_guardians sg ON sg.student_id = s.id JOIN guardians g ON g.id = sg.guardian_id WHERE s.id = ? AND g.user_id = ?', [$existing, $u['id']]);
                if (!$ok) { return ['existing_student' => 'Choose one of your own students.']; }
                if (DB::val('SELECT 1 FROM applications WHERE student_id = ? AND cycle_id = ? AND id <> ?', [$existing, $a['cycle_id'], $appId])) {
                    return ['existing_student' => 'This student already has an application in this cycle.'];
                }
                applicant_update($appId, ['student_id' => $existing], 2);
                break;
            }
            $current = $a['student_id'] ? DB::one('SELECT * FROM students WHERE id = ?', [$a['student_id']]) : null;
            if ($current && $current['verified_at']) {
                // Verified identity details are locked; only location may be updated.
                $errors = validate($d, ['sub_location' => 'required|max:80', 'village' => 'required|max:80'], ['sub_location' => 'Sub-location']);
                if ($errors) { return $errors; }
                DB::update('students', ['sub_location' => trim($d['sub_location']), 'village' => trim($d['village'])], 'id = ?', [$current['id']]);
                applicant_update($appId, [], 2);
                break;
            }
            $errors = validate($d, [
                'first_name' => 'required|max:60', 'middle_name' => 'max:60', 'last_name' => 'required|max:60',
                'gender' => 'required|in:female,male', 'date_of_birth' => 'required|date', 'birth_cert_no' => 'max:30', 'upi_no' => 'max:30',
                'ward_id' => 'required|numeric', 'sub_location' => 'required|max:80', 'village' => 'required|max:80',
            ], ['upi_no' => 'NEMIS / UPI number', 'ward_id' => 'Ward', 'sub_location' => 'Sub-location', 'birth_cert_no' => 'Birth certificate number']);
            if (!$errors && (strtotime($d['date_of_birth']) > strtotime('-4 years') || strtotime($d['date_of_birth']) < strtotime('-60 years'))) {
                $errors['date_of_birth'] = 'Check the date of birth.';
            }
            if (!$errors && !DB::val('SELECT 1 FROM wards WHERE id = ? AND is_active = 1', [(int)$d['ward_id']])) {
                $errors['ward_id'] = 'Choose a Kitui West ward.';
            }
            if (empty($d['birth_cert_no']) && empty($d['upi_no'])) {
                $errors['birth_cert_no'] = 'Give the birth certificate number or the NEMIS/UPI number (or both).';
            }
            if ($errors) { return $errors; }
            DB::tx(function () use ($a, $d, $u, $appId, $current) {
                $row = [
                    'first_name' => trim($d['first_name']), 'middle_name' => trim((string)($d['middle_name'] ?? '')) ?: null, 'last_name' => trim($d['last_name']),
                    'gender' => $d['gender'], 'date_of_birth' => $d['date_of_birth'], 'birth_cert_no' => strtoupper(trim((string)($d['birth_cert_no'] ?? ''))) ?: null,
                    'upi_no' => strtoupper(trim((string)($d['upi_no'] ?? ''))) ?: null, 'ward_id' => (int)$d['ward_id'],
                    'sub_location' => trim($d['sub_location']), 'village' => trim($d['village']), 'has_disability' => empty($d['has_disability']) ? 0 : 1,
                ];
                $editable = $current && (int)$current['created_by'] === (int)$u['id'] && !DB::val("SELECT 1 FROM applications WHERE student_id = ? AND id <> ? AND status <> 'draft'", [$current['id'], $appId]);
                if ($editable) {
                    DB::update('students', $row, 'id = ?', [$current['id']]);
                    $sid = (int)$current['id'];
                } else {
                    $sid = DB::insert('students', $row + ['created_by' => $u['id'], 'user_id' => $u['account_type'] === 'student' && !DB::val('SELECT 1 FROM students WHERE user_id = ?', [$u['id']]) ? $u['id'] : null]);
                }
                if ($a['guardian_id']) {
                    DB::run('INSERT IGNORE INTO student_guardians (student_id, guardian_id, relationship) VALUES (?,?,?)', [$sid, $a['guardian_id'], $a['guardian_relationship'] ?? 'guardian']);
                }
                applicant_update($appId, ['student_id' => $sid], 2);
            });
            break;

        case 3:
            $errors = validate($d, [
                'level' => 'required|in:secondary,tvet,college,university,special', 'institution_id' => 'required|numeric',
                'class_year' => 'required|max:30', 'admission_no' => 'required|max:40',
                'annual_fees' => 'required|numeric', 'fee_balance' => 'required|numeric', 'amount_requested' => 'required|numeric',
            ], ['institution_id' => 'Institution', 'class_year' => 'Class, form or year', 'admission_no' => 'Admission or registration number']);
            if ($errors) { return $errors; }
            $rule = DB::one('SELECT * FROM cycle_levels WHERE cycle_id = ? AND level = ? AND is_eligible = 1', [$a['cycle_id'], $d['level']]);
            $inst = DB::one('SELECT * FROM institutions WHERE id = ? AND is_active = 1', [(int)$d['institution_id']]);
            $fees = input_money('annual_fees');
            $bal = input_money('fee_balance');
            $req = input_money('amount_requested');
            if (!$rule) { $errors['level'] = 'This level of education is not supported in this cycle.'; }
            if (!$inst) { $errors['institution_id'] = 'Choose an institution from the list.'; }
            elseif ($inst['level'] !== $d['level']) { $errors['institution_id'] = 'This institution does not match the level you chose.'; }
            if ($fees !== null && $fees <= 0) { $errors['annual_fees'] = 'Enter the annual fees.'; }
            if ($bal !== null && $fees !== null && $bal > $fees) { $errors['fee_balance'] = 'The balance cannot be more than the annual fees.'; }
            if ($rule && $req !== null && ($req < (float)$rule['min_amount'] || $req > (float)$rule['max_amount'])) {
                $errors['amount_requested'] = 'Request between ' . money($rule['min_amount']) . ' and ' . money($rule['max_amount']) . ' for this level.';
            }
            if ($errors) { return $errors; }
            applicant_update($appId, ['level' => $d['level'], 'institution_id' => (int)$d['institution_id'], 'class_year' => trim($d['class_year']),
                'admission_no' => trim($d['admission_no']), 'annual_fees' => $fees, 'fee_balance' => $bal, 'amount_requested' => $req], 3);
            break;

        case 4:
            $errors = validate($d, [
                'parental_status' => 'required|in:both_parents,single_parent,partial_orphan,total_orphan,other',
                'household_size' => 'required|numeric', 'siblings_in_school' => 'required|numeric',
                'income_band' => 'required|in:none,below_5k,5k_15k,15k_30k,above_30k', 'special_circumstances' => 'max:1500',
            ], ['parental_status' => 'Parents', 'income_band' => 'Monthly household income']);
            $hs = (int)($d['household_size'] ?? 0);
            $sib = (int)($d['siblings_in_school'] ?? 0);
            if (!$errors && ($hs < 1 || $hs > 40)) { $errors['household_size'] = 'Enter the number of people in the household.'; }
            if (!$errors && ($sib < 0 || $sib > 30)) { $errors['siblings_in_school'] = 'Enter a realistic number.'; }
            if ($errors) { return $errors; }
            applicant_update($appId, ['parental_status' => $d['parental_status'], 'household_size' => $hs, 'siblings_in_school' => $sib,
                'income_band' => $d['income_band'], 'special_circumstances' => trim((string)($d['special_circumstances'] ?? '')) ?: null], 4);
            break;

        case 5:
        case 6:
            applicant_update($appId, [], $step);
            break;
    }
    return [];
}

function applicant_update(int $appId, array $data, int $step): void
{
    $a = DB::one('SELECT wizard_step, draft_data FROM applications WHERE id = ?', [$appId]);
    $draft = json_decode($a['draft_data'] ?? '{}', true) ?: [];
    unset($draft[(string)$step]);
    $data['draft_data'] = $draft ? json_encode($draft) : null;
    $data['wizard_step'] = max((int)$a['wizard_step'], $step + 1 > 7 ? 7 : $step + 1);
    DB::update('applications', $data, 'id = ?', [$appId]);
    if (array_diff_key($data, ['draft_data' => 1, 'wizard_step' => 1])) {
        Audit::log('data', 'application_step_saved', 'application', $appId, ['step' => $step, 'fields' => implode(',', array_keys(array_diff_key($data, ['draft_data' => 1, 'wizard_step' => 1])))]);
    }
}

function applicant_submit(string $id): void
{
    $a = applicant_app((int)$id, true);
    $cycle = DB::one('SELECT * FROM application_cycles WHERE id = ?', [$a['cycle_id']]);
    if ($cycle['status'] !== 'open' || strtotime($cycle['closes_at']) < time()) {
        flash('error', 'The application period has closed.');
        redirect('/portal/applications/' . $id);
    }
    $missing = applicant_missing($a);
    if ($missing) {
        flash('error', 'Complete these first: ' . implode('; ', $missing));
        redirect('/portal/applications/' . $id . '/step/' . array_key_first($missing));
    }
    if (empty($_POST['declaration_true']) || empty($_POST['declaration_consent']) || empty($_POST['declaration_fraud'])) {
        render('applicant/wizard', applicant_step_data($a, 7, ['declaration' => 'Tick all three statements to submit.']));
    }
    $resubmit = $a['status'] === 'returned';
    DB::tx(function () use ($a, $resubmit) {
        $ref = $a['reference'];
        if (!$ref) {
            $year = (int)date('Y');
            $ref = sprintf('KWB-%d-%06d', $year, next_sequence('application', $year));
        }
        $extra = ['reference' => $ref, 'declaration_at' => now(), 'declaration_ip' => client_ip(), 'return_reason' => null];
        if (!$resubmit) {
            $extra['submitted_at'] = now();
        }
        Workflow::move($a, 'applicant', $resubmit ? 'resubmitted' : 'submitted', 'submitted', $resubmit ? 'Updated and submitted again' : null, $extra);
    });
    Risk::scan((int)$id);
    if (!$resubmit) {
        Risk::sample((int)$id);
    }
    flash('success', 'Application submitted. Your reference and receipt are below.');
    redirect('/portal/applications/' . $id);
}

function applicant_deleteDraft(string $id): void
{
    $a = applicant_app((int)$id, true);
    if ($a['status'] !== 'draft' || $a['reference']) {
        abort(403, 'Only unsubmitted drafts can be deleted.');
    }
    DB::tx(function () use ($a) {
        DB::run("UPDATE applications SET status = 'withdrawn', version = version + 1 WHERE id = ?", [$a['id']]);
        Workflow::event((int)$a['id'], 'applicant', 'draft_discarded', null, true, 'draft', 'withdrawn');
        Audit::log('data', 'draft_discarded', 'application', $a['id']);
    });
    flash('success', 'Draft deleted.');
    redirect('/portal');
}

function applicant_show(string $id): void
{
    $a = applicant_app((int)$id);
    $history = Workflow::history((int)$id, true);
    $docs = DB::all("SELECT d.id, d.status, d.rejection_reason, d.created_at, t.name FROM documents d JOIN document_types t ON t.id = d.document_type_id
        WHERE d.application_id = ? AND d.status <> 'superseded' AND t.staff_only = 0 ORDER BY d.id", [$id]);
    $payment = DB::one("SELECT p.payment_reference, p.paid_on, p.amount, p.status FROM payments p WHERE p.application_id = ? AND p.status IN ('paid','processing','queued') ORDER BY p.id DESC LIMIT 1", [$id]);
    $sheets = DB::all('SELECT kind, code, issued_at FROM issued_documents WHERE application_id = ? AND revoked_at IS NULL', [$id]);
    render('applicant/show', ['title' => $a['reference'] ?? 'Draft application', 'a' => $a, 'history' => $history, 'docs' => $docs, 'payment' => $payment, 'sheets' => $sheets,
        'isOwner' => (int)$a['applicant_user_id'] === Auth::id()]);
}

function applicant_history(): void
{
    $u = applicant_user();
    $rows = DB::all("SELECT a.id, a.reference, a.status, a.amount_requested, a.amount_approved, a.amount_paid, c.name AS cycle_name, s.id AS student_id, s.first_name, s.last_name, i.name AS institution_name
        FROM applications a JOIN application_cycles c ON c.id = a.cycle_id JOIN students s ON s.id = a.student_id LEFT JOIN institutions i ON i.id = a.institution_id
        WHERE (a.applicant_user_id = ? OR s.user_id = ?) AND a.status NOT IN ('draft','withdrawn') ORDER BY s.first_name, c.year DESC", [$u['id'], $u['id']]);
    render('applicant/history', ['title' => 'Support history', 'rows' => $rows]);
}

function applicant_notifications(): void
{
    $u = applicant_user();
    $p = paginate('SELECT COUNT(*) FROM notifications WHERE user_id = ?', 'SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC', [$u['id']]);
    DB::run('UPDATE notifications SET read_at = NOW() WHERE user_id = ? AND read_at IS NULL', [$u['id']]);
    render('applicant/notifications', ['title' => 'Messages', 'p' => $p]);
}

function applicant_profile(): void
{
    $u = applicant_user();
    $linked = DB::all('SELECT id, first_name, last_name FROM students WHERE user_id = ?', [$u['id']]);
    render('applicant/profile', ['title' => 'Profile', 'u' => $u, 'linked' => $linked, 'errors' => []]);
}

function applicant_saveProfile(): void
{
    $u = applicant_user();
    $action = (string)input('action');
    if ($action === 'email') {
        $email = trim((string)input('email', '')) ?: null;
        $errors = validate(['email' => $email], ['email' => 'email|max:160']);
        if (!$errors && $email && DB::val('SELECT 1 FROM users WHERE email = ? AND id <> ?', [$email, $u['id']])) {
            $errors['email'] = 'This email is already used by another account.';
        }
        if ($errors) {
            render('applicant/profile', ['title' => 'Profile', 'u' => $u, 'linked' => [], 'errors' => $errors]);
        }
        DB::run('UPDATE users SET email = ? WHERE id = ?', [$email, $u['id']]);
        Audit::log('data', 'profile_updated', 'user', $u['id'], ['field' => 'email']);
        flash('success', 'Profile saved.');
    } elseif ($action === 'link' && $u['account_type'] === 'student') {
        rate_limit('student_link', 5, 3600, (string)$u['id']);
        $app = DB::one('SELECT a.student_id FROM applications a WHERE a.reference = ? AND a.student_access_code = ?', [strtoupper(trim((string)input('reference'))), strtoupper(trim((string)input('code')))]);
        if (!$app || DB::val('SELECT user_id FROM students WHERE id = ?', [$app['student_id']]) || DB::val('SELECT 1 FROM students WHERE user_id = ?', [$u['id']])) {
            flash('error', 'Those details did not match, or the student record is already linked to an account.');
        } else {
            DB::run('UPDATE students SET user_id = ? WHERE id = ?', [$u['id'], $app['student_id']]);
            Audit::log('data', 'student_account_linked', 'student', $app['student_id']);
            flash('success', 'Your student record is now linked. You can see its applications and support history.');
        }
    }
    redirect('/portal/profile');
}
