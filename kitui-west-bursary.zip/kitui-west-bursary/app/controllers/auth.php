<?php
declare(strict_types=1);

function auth_loginForm(): void
{
    if (Auth::user()) {
        redirect(Auth::homeFor());
    }
    render('auth/login', ['title' => 'Log in', 'errors' => []], 'public');
}

function auth_login(): void
{
    rate_limit('login', 40, 600); // generous per IP: many families share one cyber café IP; per-phone limit below is the real guard
    $phone = (string)input('phone', '');
    rate_limit('login_phone', 8, 900, normalize_phone($phone));
    $res = Auth::attempt($phone, (string)($_POST['password'] ?? ''));
    if ($res === 'invalid' || $res === 'locked') {
        $_SESSION['old'] = ['phone' => $phone];
        $msg = $res === 'locked' ? 'This account is locked for 15 minutes after repeated failed attempts.' : 'The phone number or password is not correct.';
        render('auth/login', ['title' => 'Log in', 'errors' => ['form' => $msg]], 'public');
    }
    clear_old();
    if ($res === '2fa') {
        redirect('/2fa');
    }
    $to = $_SESSION['intended'] ?? Auth::homeFor();
    unset($_SESSION['intended']);
    redirect(str_starts_with($to, '/') && !str_starts_with($to, '//') ? $to : Auth::homeFor());
}

function auth_logout(): void
{
    Auth::logout();
    flash('success', 'You have logged out.');
    redirect('/login');
}

function auth_registerForm(): void
{
    if (Auth::user()) {
        redirect(Auth::homeFor());
    }
    render('auth/register', ['title' => 'Create an account', 'errors' => []], 'public');
}

function auth_register(): void
{
    rate_limit('register', 10, 3600);
    $d = $_POST;
    $errors = validate($d, [
        'full_name' => 'required|min:3|max:120', 'phone' => 'required|phone', 'email' => 'email|max:160',
        'account_type' => 'required|in:parent,student', 'national_id' => 'nid',
    ], ['full_name' => 'Full name', 'national_id' => 'ID number']);
    $phone = normalize_phone((string)($d['phone'] ?? ''));
    $pw = (string)($d['password'] ?? '');
    if ($p = Auth::passwordProblems($pw, [$phone, $d['national_id'] ?? '', ...explode(' ', (string)($d['full_name'] ?? ''))])) {
        $errors['password'] = $p;
    } elseif ($pw !== ($d['password_confirmation'] ?? '')) {
        $errors['password_confirmation'] = 'The two passwords do not match.';
    }
    if (empty($d['consent'])) {
        $errors['consent'] = 'You must agree to how your information is used.';
    }
    if (!$errors && DB::val('SELECT 1 FROM users WHERE phone = ?', [$phone])) {
        $errors['phone'] = 'An account with this phone number already exists. Log in or reset your password.';
    }
    $email = trim((string)($d['email'] ?? '')) ?: null;
    if (!$errors && $email && DB::val('SELECT 1 FROM users WHERE email = ?', [$email])) {
        $errors['email'] = 'This email is already registered.';
    }
    if ($errors) {
        keep_old();
        render('auth/register', ['title' => 'Create an account', 'errors' => $errors], 'public');
    }
    $pending = [
        'full_name' => trim((string)$d['full_name']), 'phone' => $phone, 'email' => $email,
        'national_id' => trim((string)($d['national_id'] ?? '')) ?: null,
        'password_hash' => Auth::hashPassword($pw), 'account_type' => $d['account_type'],
    ];
    clear_old();
    // Without an SMS provider on a public server the number cannot be checked; the account is created
    // unverified and the administrator's security checklist shows the warning.
    if (Sms::testMode() && !is_local_request()) {
        auth_createAccount($pending, false);
    }
    $_SESSION['reg'] = ['data' => $pending, 'tries' => 0, 'sends' => 0];
    auth_sendRegCode();
    redirect('/register/verify');
}

function auth_sendRegCode(): void
{
    $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $_SESSION['reg']['hash'] = hash_hmac('sha256', $code, (string)env('APP_KEY', 'k'));
    $_SESSION['reg']['expires'] = time() + 900;
    $_SESSION['reg']['sent_at'] = time();
    $_SESSION['reg']['sends']++;
    Sms::send($_SESSION['reg']['data']['phone'], 'KWB: Your verification code is ' . $code . '. It expires in 15 minutes. Do not share it.', 'verify_phone', null, true);
    $_SESSION['reg']['test_code'] = Sms::testMode() && is_local_request() ? $code : null;
}

function auth_verifyPhoneForm(): void
{
    $r = $_SESSION['reg'] ?? redirect('/register');
    render('auth/verify_phone', ['title' => 'Confirm your phone number', 'phone' => $r['data']['phone'], 'testCode' => $r['test_code'] ?? null, 'errors' => []], 'public');
}

function auth_verifyPhone(): void
{
    $r = $_SESSION['reg'] ?? redirect('/register');
    rate_limit('verify_phone', 10, 900, $r['data']['phone']);
    $code = preg_replace('/\D/', '', (string)input('code', ''));
    $ok = time() < (int)$r['expires'] && hash_equals((string)$r['hash'], hash_hmac('sha256', $code, (string)env('APP_KEY', 'k')));
    if (!$ok) {
        $_SESSION['reg']['tries']++;
        if ($_SESSION['reg']['tries'] >= 5) {
            unset($_SESSION['reg']);
            Audit::log('security', 'phone_verify_failed', 'user', null, ['phone' => mask_phone($r['data']['phone'])], null);
            flash('error', 'Too many wrong codes. Please register again.');
            redirect('/register');
        }
        render('auth/verify_phone', ['title' => 'Confirm your phone number', 'phone' => $r['data']['phone'], 'testCode' => $r['test_code'] ?? null,
            'errors' => ['code' => 'That code is not correct or has expired.']], 'public');
    }
    unset($_SESSION['reg']);
    auth_createAccount($r['data'], true);
}

function auth_resendCode(): void
{
    $r = $_SESSION['reg'] ?? redirect('/register');
    if ($r['sends'] >= 3 || time() - (int)$r['sent_at'] < 60) {
        flash('info', 'Please wait a minute before asking for another code (maximum 3).');
    } else {
        auth_sendRegCode();
        flash('success', 'A new code was sent.');
    }
    redirect('/register/verify');
}

function auth_createAccount(array $p, bool $verified): never
{
    if (DB::val('SELECT 1 FROM users WHERE phone = ?', [$p['phone']])) {
        flash('error', 'An account with this phone number already exists. Log in or reset your password.');
        redirect('/login');
    }
    $id = DB::tx(function () use ($p, $verified) {
        $id = DB::insert('users', $p + ['phone_verified_at' => $verified ? now() : null]);
        DB::run('INSERT INTO user_roles (user_id, role_id) SELECT ?, id FROM roles WHERE slug = ?', [$id, $p['account_type']]);
        Audit::log('security', 'account_created', 'user', $id, ['type' => $p['account_type'], 'phone_verified' => $verified ? 'yes' : 'no'], $id);
        return $id;
    });
    Auth::complete($id);
    flash('success', 'Your account is ready. You can start an application now.');
    redirect('/portal');
}

function auth_pending2fa(): array
{
    if (empty($_SESSION['pending_2fa']) || empty($_SESSION['uid'])) {
        redirect('/login');
    }
    if (time() - (int)($_SESSION['pending_2fa_at'] ?? 0) > 300) { // the password step is only valid for 5 minutes
        Auth::logout();
        flash('info', 'That took too long. Please log in again.');
        redirect('/login');
    }
    return DB::one('SELECT id, phone, totp_enabled, totp_secret, totp_last_step FROM users WHERE id = ?', [$_SESSION['uid']]);
}

function auth_twofaForm(): void
{
    $u = auth_pending2fa();
    $enrol = !$u['totp_enabled'];
    if ($enrol && empty($_SESSION['totp_setup'])) {
        $_SESSION['totp_setup'] = Totp::secret();
    }
    render('auth/twofa', ['title' => 'Two-step verification', 'enrol' => $enrol, 'secret' => $_SESSION['totp_setup'] ?? null,
        'uri' => $enrol ? Totp::uri($_SESSION['totp_setup'], $u['phone']) : null, 'errors' => []], 'public');
}

function auth_twofa(): void
{
    $u = auth_pending2fa();
    rate_limit('2fa', 6, 600, (string)$u['id']);
    $secret = $u['totp_enabled'] ? (string)Crypto::decrypt($u['totp_secret'], 'totp') : (string)($_SESSION['totp_setup'] ?? '');
    $step = Totp::matchStep($secret, (string)input('code', ''), $u['totp_last_step'] !== null ? (int)$u['totp_last_step'] : null);
    if ($step === null) {
        Audit::log('security', '2fa_failed', 'user', $u['id'], [], (int)$u['id']);
        render('auth/twofa', ['title' => 'Two-step verification', 'enrol' => !$u['totp_enabled'], 'secret' => $_SESSION['totp_setup'] ?? null,
            'uri' => !$u['totp_enabled'] ? Totp::uri($secret, $u['phone']) : null, 'errors' => ['code' => 'That code is not correct (or was already used). Enter the current 6-digit code from your authenticator app.']], 'public');
    }
    if (!$u['totp_enabled']) {
        DB::run('UPDATE users SET totp_secret = ?, totp_enabled = 1, totp_last_step = ? WHERE id = ?', [Crypto::encrypt($secret, 'totp'), $step, $u['id']]);
        Audit::log('security', '2fa_enabled', 'user', $u['id'], [], (int)$u['id']);
        unset($_SESSION['totp_setup']);
    } else {
        DB::run('UPDATE users SET totp_last_step = ? WHERE id = ?', [$step, $u['id']]);
    }
    Auth::complete((int)$u['id']);
    redirect(Auth::homeFor());
}

function auth_setup2faForm(): void
{
    $u = Auth::require();
    if (!isset($_SESSION['totp_setup'])) {
        $_SESSION['totp_setup'] = Totp::secret();
    }
    render('auth/setup2fa', ['title' => 'Two-step verification', 'u' => $u, 'secret' => $_SESSION['totp_setup'], 'uri' => Totp::uri($_SESSION['totp_setup'], $u['phone']), 'errors' => []]);
}

function auth_setup2fa(): void
{
    $u = Auth::require();
    rate_limit('2fa_setup', 6, 600, (string)$u['id']);
    $step = Totp::matchStep((string)($_SESSION['totp_setup'] ?? ''), (string)input('code', ''));
    if ($step === null) {
        render('auth/setup2fa', ['title' => 'Two-step verification', 'u' => $u, 'secret' => $_SESSION['totp_setup'], 'uri' => Totp::uri($_SESSION['totp_setup'], $u['phone']), 'errors' => ['code' => 'That code is not correct.']]);
    }
    DB::run('UPDATE users SET totp_secret = ?, totp_enabled = 1, totp_last_step = ? WHERE id = ?', [Crypto::encrypt($_SESSION['totp_setup'], 'totp'), $step, $u['id']]);
    unset($_SESSION['totp_setup']);
    Audit::log('security', '2fa_enabled', 'user', $u['id']);
    flash('success', 'Two-step verification is on. You will need a code each time you log in.');
    redirect(Auth::homeFor());
}

function auth_forgotForm(): void
{
    render('auth/forgot', ['title' => 'Reset your password', 'errors' => []], 'public');
}

function auth_forgot(): void
{
    rate_limit('forgot', 10, 3600);
    $phone = normalize_phone((string)input('phone', ''));
    rate_limit('forgot_phone', 3, 3600, $phone); // stops anyone flooding a family's phone with SMS
    $u = DB::one('SELECT id, phone FROM users WHERE phone = ? AND is_active = 1', [$phone]);
    if ($u) {
        $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        DB::run('UPDATE password_resets SET used_at = NOW() WHERE user_id = ? AND used_at IS NULL', [$u['id']]);
        DB::insert('password_resets', ['user_id' => $u['id'], 'token_hash' => hash_hmac('sha256', $code . '|' . $u['id'], env('APP_KEY', 'k')), 'expires_at' => date('Y-m-d H:i:s', time() + 1800)]);
        Sms::template('password_reset', $u['phone'], ['code' => $code]);
        if (Sms::testMode() && is_local_request()) {
            $_SESSION['test_code'] = $code; // XAMPP/testing only: no SMS provider, so show it on this computer
        }
        Audit::log('security', 'password_reset_requested', 'user', $u['id'], [], (int)$u['id']);
    }
    // Same response whether or not the number exists, so accounts cannot be discovered.
    flash('info', 'If that number has an account, we sent a 6-digit code by SMS. It expires in 30 minutes.');
    redirect('/reset-password?phone=' . urlencode($phone));
}

function auth_resetForm(): void
{
    render('auth/reset', ['title' => 'Choose a new password', 'phone' => (string)input('phone', ''), 'errors' => []], 'public');
}

function auth_reset(): void
{
    $phone = normalize_phone((string)input('phone', ''));
    rate_limit('reset', 5, 1800, $phone);
    $pw = (string)($_POST['password'] ?? '');
    $errors = [];
    $u = DB::one('SELECT id, full_name, national_id FROM users WHERE phone = ? AND is_active = 1', [$phone]);
    $row = $u ? DB::one('SELECT * FROM password_resets WHERE user_id = ? AND token_hash = ? AND used_at IS NULL AND expires_at > NOW()',
        [$u['id'], hash_hmac('sha256', preg_replace('/\D/', '', (string)input('code', '')) . '|' . $u['id'], env('APP_KEY', 'k'))]) : null;
    if (!$row) {
        $errors['code'] = 'The code is wrong or has expired. Request a new one.';
    } elseif ($p = Auth::passwordProblems($pw, [$phone, $u['national_id'], ...explode(' ', $u['full_name'])])) {
        $errors['password'] = $p;
    } elseif ($pw !== ($_POST['password_confirmation'] ?? '')) {
        $errors['password_confirmation'] = 'The two passwords do not match.';
    }
    if ($errors) {
        render('auth/reset', ['title' => 'Choose a new password', 'phone' => $phone, 'errors' => $errors], 'public');
    }
    DB::tx(function () use ($u, $row, $pw) {
        DB::run('UPDATE users SET password_hash = ?, failed_logins = 0, locked_until = NULL, must_change_password = 0 WHERE id = ?', [Auth::hashPassword($pw), $u['id']]);
        DB::run('UPDATE password_resets SET used_at = NOW() WHERE id = ?', [$row['id']]);
        Auth::bumpEpoch((int)$u['id']); // anyone signed in with the old password is signed out
        Audit::log('security', 'password_reset', 'user', $u['id'], [], (int)$u['id']);
    });
    unset($_SESSION['test_code']);
    flash('success', 'Password changed. Log in with your new password.');
    redirect('/login');
}

function auth_passwordForm(): void
{
    Auth::require();
    render('auth/password', ['title' => 'Change password', 'errors' => []]);
}

function auth_password(): void
{
    $u = Auth::require();
    $hash = DB::val('SELECT password_hash FROM users WHERE id = ?', [$u['id']]);
    $pw = (string)($_POST['password'] ?? '');
    $errors = [];
    if (!password_verify((string)($_POST['current_password'] ?? ''), $hash)) {
        $errors['current_password'] = 'Your current password is not correct.';
    } elseif ($p = Auth::passwordProblems($pw, [$u['phone'], ...explode(' ', $u['full_name'])])) {
        $errors['password'] = $p;
    } elseif (password_verify($pw, $hash)) {
        $errors['password'] = 'Choose a password different from the current one.';
    } elseif ($pw !== ($_POST['password_confirmation'] ?? '')) {
        $errors['password_confirmation'] = 'The two passwords do not match.';
    }
    if ($errors) {
        render('auth/password', ['title' => 'Change password', 'errors' => $errors]);
    }
    DB::run('UPDATE users SET password_hash = ?, must_change_password = 0 WHERE id = ?', [Auth::hashPassword($pw), $u['id']]);
    Auth::bumpEpoch((int)$u['id']); // other devices are signed out; this one stays signed in
    Audit::log('security', 'password_changed', 'user', $u['id']);
    session_regenerate_id(true);
    flash('success', 'Password changed. Any other device that was logged in has been signed out.');
    redirect(Auth::homeFor());
}
