<?php
declare(strict_types=1);

/*
 * Resumable, chunked uploads: /upload/start -> /upload/chunk (repeat) -> /upload/finish.
 * If the connection drops, calling start again with the same file returns the bytes already
 * received so the browser continues from there instead of starting over.
 */

const CHUNK_MAX = 1048576;

function files_tmp_dir(): string
{
    $d = BASE_PATH . '/storage/uploads';
    if (!is_dir($d)) {
        mkdir($d, 0750, true);
    }
    return $d;
}

/** Who may upload which document type to which application. Returns the application row. */
function files_authorize_upload(int $appId, int $typeId): array
{
    $u = Auth::user() ?? json_out(['ok' => false, 'error' => 'Please log in again.'], 401);
    $type = DB::one('SELECT * FROM document_types WHERE id = ? AND is_active = 1', [$typeId]) ?? json_out(['ok' => false, 'error' => 'Unknown document type.'], 422);
    $app = DB::one('SELECT a.*, g.phone AS guardian_phone, g.national_id AS guardian_nid, s.ward_id FROM applications a LEFT JOIN guardians g ON g.id = a.guardian_id LEFT JOIN students s ON s.id = a.student_id WHERE a.id = ?', [$appId]);
    if (!$app) {
        json_out(['ok' => false, 'error' => 'Application not found.'], 404);
    }
    if ($type['staff_only']) {
        // Homestead photos: only a ward/field officer allowed to verify this application, during verification.
        $why = Workflow::blockReason($app, 'verification');
        if ($why !== null) {
            json_out(['ok' => false, 'error' => $why === 'coi_required' ? 'Declare conflict of interest first.' : $why], 403);
        }
        return [$app, $type];
    }
    if ((int)$app['applicant_user_id'] !== (int)$u['id'] || !in_array($app['status'], ['draft', 'returned'], true)) {
        json_out(['ok' => false, 'error' => 'You cannot add documents to this application.'], 403);
    }
    $allowed = DB::val("SELECT 1 FROM cycle_documents WHERE cycle_id = ? AND document_type_id = ? AND (level = 'all' OR level = ?)", [$app['cycle_id'], $typeId, $app['level'] ?? 'secondary']);
    if (!$allowed) {
        json_out(['ok' => false, 'error' => 'This document is not needed for this application.'], 422);
    }
    return [$app, $type];
}

function files_start(): void
{
    Auth::user() ?? json_out(['ok' => false, 'error' => 'Please log in again.'], 401);
    rate_limit('upload_start', 60, 600, (string)Auth::id());
    $appId = (int)input_int('application_id');
    $typeId = (int)input_int('document_type_id');
    $size = (int)input_int('size');
    $name = mb_substr(preg_replace('/[^\w .\-()]/u', '_', (string)input('file_name', 'file')), 0, 180) ?: 'file';
    files_authorize_upload($appId, $typeId);
    // Stop storage abuse: a real application never needs more than a few dozen files.
    if ((int)DB::val('SELECT COUNT(*) FROM documents WHERE application_id = ?', [$appId]) >= 60
        || (int)DB::val('SELECT COUNT(*) FROM documents WHERE uploaded_by = ? AND created_at > NOW() - INTERVAL 1 DAY', [Auth::id()]) >= 150) {
        Audit::log('security', 'upload_cap_reached', 'application', $appId);
        json_out(['ok' => false, 'error' => 'Upload limit reached for this application. Contact the bursary office if you need to add more.'], 429);
    }
    $max = (int)setting('max_upload_mb', '8') * 1048576;
    if ($size <= 0 || $size > $max) {
        json_out(['ok' => false, 'error' => 'The file must be smaller than ' . setting('max_upload_mb', '8') . ' MB.'], 422);
    }
    $existing = DB::one('SELECT token, received FROM upload_sessions WHERE user_id = ? AND application_id = ? AND document_type_id = ? AND file_name = ? AND total_size = ? AND created_at > NOW() - INTERVAL 1 DAY',
        [Auth::id(), $appId, $typeId, $name, $size]);
    if ($existing && is_file(files_tmp_dir() . '/' . $existing['token'] . '.part')) {
        json_out(['ok' => true, 'token' => $existing['token'], 'received' => (int)$existing['received']]);
    }
    $token = bin2hex(random_bytes(16));
    DB::insert('upload_sessions', ['token' => $token, 'user_id' => Auth::id(), 'application_id' => $appId, 'document_type_id' => $typeId, 'file_name' => $name, 'total_size' => $size]);
    touch(files_tmp_dir() . '/' . $token . '.part');
    json_out(['ok' => true, 'token' => $token, 'received' => 0]);
}

function files_session(): array
{
    Auth::user() ?? json_out(['ok' => false, 'error' => 'Please log in again.'], 401);
    $token = (string)input('token', '');
    if (!preg_match('/^[a-f0-9]{32}$/', $token)) {
        json_out(['ok' => false, 'error' => 'Upload expired. Choose the file again.'], 410);
    }
    $s = DB::one('SELECT * FROM upload_sessions WHERE token = ? AND user_id = ?', [$token, Auth::id()]);
    if (!$s) {
        json_out(['ok' => false, 'error' => 'Upload expired. Choose the file again.'], 410);
    }
    return $s;
}

function files_chunk(): void
{
    $s = files_session();
    $offset = (int)input_int('offset');
    $part = files_tmp_dir() . '/' . $s['token'] . '.part';
    $received = is_file($part) ? filesize($part) : 0;
    if ($offset !== $received) {
        json_out(['ok' => true, 'received' => $received]); // client resyncs to our offset
    }
    $f = $_FILES['chunk'] ?? null;
    if (!$f || $f['error'] !== UPLOAD_ERR_OK || $f['size'] > CHUNK_MAX || $f['size'] < 1) {
        json_out(['ok' => false, 'error' => 'Part of the file did not arrive. Retrying…', 'received' => $received], 422);
    }
    if ($received + $f['size'] > (int)$s['total_size']) {
        json_out(['ok' => false, 'error' => 'File is larger than announced.'], 422);
    }
    $in = fopen($f['tmp_name'], 'rb');
    $out = fopen($part, 'ab');
    stream_copy_to_stream($in, $out);
    fclose($in);
    fclose($out);
    clearstatcache(true, $part);
    $received = filesize($part);
    DB::run('UPDATE upload_sessions SET received = ? WHERE token = ?', [$received, $s['token']]);
    json_out(['ok' => true, 'received' => $received]);
}

function files_finish(): void
{
    $s = files_session();
    [$app, $type] = files_authorize_upload((int)$s['application_id'], (int)$s['document_type_id']);
    $part = files_tmp_dir() . '/' . $s['token'] . '.part';
    clearstatcache(true, $part);
    if (!is_file($part) || filesize($part) !== (int)$s['total_size']) {
        json_out(['ok' => false, 'error' => 'The upload is incomplete. Choose the file again to resume.'], 422);
    }
    $mime = Storage::detectMime($part);
    if (!$mime) {
        @unlink($part);
        DB::run('DELETE FROM upload_sessions WHERE token = ?', [$s['token']]);
        Audit::log('security', 'upload_rejected', 'application', $app['id'], ['reason' => 'type', 'name' => $s['file_name']]);
        json_out(['ok' => false, 'error' => 'Only clear photos (JPG, PNG, WEBP) or PDF files are accepted.'], 422);
    }
    $mime = Storage::optimiseImage($part, $mime, $type['code'] !== 'homestead_photo');
    clearstatcache(true, $part);
    $sha = hash_file('sha256', $part);
    $size = filesize($part);
    $key = 'applications/' . (int)$app['id'] . '/' . date('Y') . '/' . bin2hex(random_bytes(12)) . '.' . Storage::ALLOWED[$mime];
    Storage::put($key, $part, $mime);
    @unlink($part);

    $docId = DB::tx(function () use ($app, $type, $s, $mime, $sha, $size, $key) {
        if (!in_array($type['code'], ['homestead_photo', 'other'], true)) {
            DB::run("UPDATE documents SET status = 'superseded' WHERE application_id = ? AND document_type_id = ? AND status IN ('pending','rejected','verified') AND field_visit_id IS NULL",
                [$app['id'], $type['id']]);
        }
        $id = DB::insert('documents', [
            'application_id' => $app['id'], 'document_type_id' => $type['id'], 'storage_driver' => Storage::driver(), 'storage_key' => $key,
            'original_name' => $s['file_name'], 'mime' => $mime, 'size_bytes' => $size, 'sha256' => $sha, 'uploaded_by' => Auth::id(),
        ]);
        DB::run('DELETE FROM upload_sessions WHERE token = ?', [$s['token']]);
        Audit::log('data', 'document_uploaded', 'document', $id, ['application_id' => $app['id'], 'type' => $type['code'], 'sha256' => $sha, 'bytes' => $size]);
        return $id;
    });
    json_out(['ok' => true, 'document_id' => $docId, 'size' => $size]);
}

/** Stream a private document after checking the viewer is entitled to see it. Every view is logged. */
function files_serve(string $id): void
{
    $u = Auth::require();
    $d = DB::one('SELECT d.*, t.staff_only, t.name AS type_name, a.applicant_user_id, a.student_id, g.phone AS guardian_phone, g.national_id AS guardian_nid
        FROM documents d JOIN document_types t ON t.id = d.document_type_id JOIN applications a ON a.id = d.application_id
        LEFT JOIN guardians g ON g.id = a.guardian_id WHERE d.id = ?', [(int)$id]) ?? abort(404);
    $ok = false;
    if ($u['account_type'] === 'staff') {
        // Finance may see enrolment/fee evidence to confirm the payee institution, but not homestead photos.
        $ok = Auth::has('doc_officer', 'ward_officer', 'committee', 'approver', 'auditor') || (Auth::has('finance') && !$d['staff_only']);
        $me = DB::one('SELECT phone, national_id FROM users WHERE id = ?', [$u['id']]);
        if ($ok && ($me['phone'] === $d['guardian_phone'] || ($me['national_id'] && $me['national_id'] === $d['guardian_nid']))) {
            $ok = false;
        }
    } elseif (!$d['staff_only']) {
        $ok = (int)$d['applicant_user_id'] === (int)$u['id'] || (bool)DB::val('SELECT 1 FROM students WHERE id = ? AND user_id = ?', [$d['student_id'], $u['id']]);
    }
    if (!$ok) {
        Audit::log('access', 'document_denied', 'document', $d['id']);
        abort(404);
    }
    Audit::log('access', 'document_viewed', 'document', $d['id'], ['application_id' => $d['application_id']]);
    $body = Storage::read($d['storage_driver'], $d['storage_key']);
    header_remove('Content-Security-Policy');
    if ($d['mime'] !== 'application/pdf') {
        header("Content-Security-Policy: default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox");
    }
    header('Content-Type: ' . $d['mime']);
    header('Content-Length: ' . strlen($body));
    header('Cache-Control: private, no-store');
    header('Content-Disposition: ' . (input('download') ? 'attachment' : 'inline') . '; filename="' . preg_replace('/[^\w.\-]/', '_', $d['type_name'] . '-' . $d['id']) . '.' . (Storage::ALLOWED[$d['mime']] ?? 'bin') . '"');
    echo $body;
    exit;
}
