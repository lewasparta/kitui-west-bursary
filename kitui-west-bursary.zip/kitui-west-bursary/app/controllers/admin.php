<?php
declare(strict_types=1);

/*
 * Administration. Everything that shapes eligibility and money (cycles, levels and amount bands,
 * required documents, ward budgets, approval limits) is configuration stored in the database,
 * never hard-coded. Every change is written to the audit trail with before/after values.
 */

const LEVEL_OPTS = ['secondary' => 'Secondary school', 'tvet' => 'TVET / technical', 'college' => 'College (diploma/certificate)', 'university' => 'University', 'special' => 'Special needs institution'];
const EDITABLE_SETTINGS = [
    'site_name' => ['Site name', 'text'],
    'contact_phone' => ['Office phone', 'text'],
    'contact_email' => ['Office email', 'email'],
    'office_address' => ['Office address', 'text'],
    'office_hours' => ['Office hours', 'text'],
    'max_upload_mb' => ['Maximum upload size (MB, 1–20)', 'number'],
    'privacy_threshold' => ['Transparency: hide groups smaller than', 'number'],
    'twofa_roles' => ['Two-step login required for (administrators always)', 'roles'],
];

function admin_user(): array
{
    return Auth::require('admin');
}

/** Generic, validated configuration resources. */
function admin_resources(): array
{
    $cycles = fn() => array_column(DB::all('SELECT id, name FROM application_cycles ORDER BY opens_at DESC'), 'name', 'id');
    $wards = fn() => array_column(DB::all('SELECT id, name FROM wards ORDER BY name'), 'name', 'id');
    return [
        'wards' => ['Wards', 'wards', 'name', [
            'name' => ['Ward name', 'text', 'required|max:80'], 'code' => ['Short code', 'text', 'required|max:10'], 'is_active' => ['Active', 'bool', ''],
        ]],
        'institutions' => ['Institutions', 'institutions', 'name', [
            'name' => ['Institution name', 'text', 'required|max:160'], 'level' => ['Level', LEVEL_OPTS, 'required'],
            'county' => ['County', 'text', 'max:60'], 'bank_name' => ['Bank', 'text', 'max:80'], 'bank_branch' => ['Branch', 'text', 'max:80'],
            'account_name' => ['Account name', 'text', 'max:160'], 'account_no' => ['Account number', 'text', 'max:40'], 'is_active' => ['Active', 'bool', ''],
        ]],
        'cycles' => ['Application cycles', 'application_cycles', 'opens_at DESC', [
            'name' => ['Cycle name', 'text', 'required|max:100'], 'year' => ['Year', 'number', 'required|numeric'],
            'opens_at' => ['Opens', 'datetime', 'required'], 'closes_at' => ['Closes', 'datetime', 'required'],
            'status' => ['Status', ['draft' => 'Draft (hidden)', 'open' => 'Open', 'closed' => 'Closed', 'archived' => 'Archived'], 'required'],
            'field_verification_rate' => ['Random field visits (% of applications)', 'number', 'required|numeric'],
            'secondary_audit_rate' => ['Random secondary audits (%)', 'number', 'required|numeric'],
            'max_applications_per_guardian' => ['Max applications per guardian before a flag', 'number', 'required|numeric'],
            'notes' => ['Eligibility notes shown to the public', 'textarea', 'max:5000'],
        ]],
        'levels' => ['Levels & amount bands', 'cycle_levels', 'cycle_id DESC, level', [
            'cycle_id' => ['Cycle', $cycles, 'required'], 'level' => ['Level', LEVEL_OPTS, 'required'],
            'min_amount' => ['Minimum award (KES)', 'money', 'required'], 'max_amount' => ['Maximum award (KES)', 'money', 'required'],
            'is_eligible' => ['Eligible this cycle', 'bool', ''],
        ]],
        'cycle_docs' => ['Required documents', 'cycle_documents', 'cycle_id DESC, document_type_id', [
            'cycle_id' => ['Cycle', $cycles, 'required'],
            'document_type_id' => ['Document', fn() => array_column(DB::all('SELECT id, name FROM document_types WHERE staff_only = 0 ORDER BY name'), 'name', 'id'), 'required'],
            'level' => ['Applies to', ['all' => 'All levels'] + LEVEL_OPTS, 'required'], 'is_required' => ['Required (untick = optional)', 'bool', ''],
        ]],
        'budgets' => ['Ward budgets', 'cycle_ward_budgets', 'cycle_id DESC, ward_id', [
            'cycle_id' => ['Cycle', $cycles, 'required'], 'ward_id' => ['Ward', $wards, 'required'], 'amount' => ['Budget (KES)', 'money', 'required'],
        ]],
        'doc_types' => ['Document types', 'document_types', 'name', [
            'code' => ['Code', 'text', 'required|max:40'], 'name' => ['Name', 'text', 'required|max:120'], 'description' => ['Guidance for applicants', 'text', 'max:255'],
            'staff_only' => ['Uploaded by staff only', 'bool', ''], 'is_active' => ['Active', 'bool', ''],
        ]],
        'sms_templates' => ['SMS templates', 'sms_templates', 'code', [
            'code' => ['Code (used by the system)', 'readonly', ''], 'name' => ['Name', 'text', 'required|max:100'],
            'body' => ['Message ({ref} {student} {amount} {institution} {reason} {payref} {url} {title})', 'textarea', 'required|max:480'], 'is_active' => ['Send this message', 'bool', ''],
        ]],
        'announcements' => ['Announcements', 'announcements', 'id DESC', [
            'title' => ['Title', 'text', 'required|max:160'], 'body' => ['Text', 'textarea', 'required|max:10000'],
            'is_published' => ['Published', 'bool', ''], 'notify_sms' => ['SMS all registered families when first published', 'bool', ''],
        ]],
        'faqs' => ['FAQs', 'faqs', 'sort_order, id', [
            'question' => ['Question', 'text', 'required|max:255'], 'answer' => ['Answer', 'textarea', 'required|max:5000'],
            'sort_order' => ['Order', 'number', 'numeric'], 'is_active' => ['Show', 'bool', ''],
        ]],
        'programs' => ['Mentorship programmes', 'mentorship_programs', 'category, title', [
            'category' => ['Category', ['career' => 'Career guidance', 'academic' => 'Academic guidance', 'entrepreneurship' => 'Entrepreneurship', 'digital_skills' => 'Digital skills', 'financial_literacy' => 'Financial literacy', 'leadership' => 'Leadership', 'scholarship' => 'Scholarship / university / TVET guidance'], 'required'],
            'title' => ['Title', 'text', 'required|max:140'], 'description' => ['Description', 'textarea', 'required|max:3000'], 'is_active' => ['Active', 'bool', ''],
        ]],
        'events' => ['Mentorship events', 'mentorship_events', 'starts_at DESC', [
            'program_id' => ['Programme', fn() => array_column(DB::all('SELECT id, title FROM mentorship_programs ORDER BY title'), 'title', 'id'), 'required'],
            'title' => ['Title', 'text', 'required|max:140'], 'venue' => ['Venue', 'text', 'required|max:140'],
            'starts_at' => ['Starts', 'datetime', 'required'], 'capacity' => ['Capacity', 'number', 'required|numeric'], 'is_active' => ['Open for registration', 'bool', ''],
        ]],
    ];
}

function admin_res(string $res): array
{
    $all = admin_resources();
    if (!isset($all[$res])) {
        abort(404);
    }
    [$label, $table, $order, $fields] = $all[$res];
    foreach ($fields as $k => $f) {
        if ($f[1] instanceof Closure) {
            $fields[$k][1] = ($f[1])();
        }
    }
    return [$label, $table, $order, $fields];
}

function admin_index(): void
{
    admin_user();
    $counts = [
        'users' => (int)DB::val("SELECT COUNT(*) FROM users WHERE account_type = 'staff'"),
        'families' => (int)DB::val("SELECT COUNT(*) FROM users WHERE account_type <> 'staff'"),
        'wards' => (int)DB::val('SELECT COUNT(*) FROM wards WHERE is_active = 1'),
        'institutions' => (int)DB::val('SELECT COUNT(*) FROM institutions WHERE is_active = 1'),
        'no2fa' => (int)DB::val("SELECT COUNT(*) FROM users u WHERE u.account_type = 'staff' AND u.is_active = 1 AND u.totp_enabled = 0"),
    ];
    $cycle = current_cycle() ?? latest_cycle();
    $budget = $cycle ? DB::all('SELECT w.name, b.amount,
            COALESCE((SELECT SUM(a.amount_approved) FROM applications a JOIN students s ON s.id = a.student_id WHERE a.cycle_id = b.cycle_id AND s.ward_id = b.ward_id AND a.amount_approved IS NOT NULL), 0) AS committed
        FROM cycle_ward_budgets b JOIN wards w ON w.id = b.ward_id WHERE b.cycle_id = ? ORDER BY w.name', [$cycle['id']]) : [];
    $res = array_map(fn($r) => $r[0], admin_resources());
    render('admin/index', ['title' => 'Administration', 'counts' => $counts, 'cycle' => $cycle, 'budget' => $budget, 'res' => $res]);
}

function admin_users(): void
{
    admin_user();
    $q = trim((string)input('q', ''));
    $type = input('type') === 'families' ? 'families' : 'staff';
    $where = $type === 'staff' ? "u.account_type = 'staff'" : "u.account_type <> 'staff'";
    $params = [];
    if ($q !== '') {
        $where .= ' AND (u.full_name LIKE ? OR u.phone LIKE ?)';
        $params = ['%' . $q . '%', '%' . $q . '%'];
    }
    $p = paginate("SELECT COUNT(*) FROM users u WHERE $where", "SELECT u.*, w.name AS ward_name,
        (SELECT GROUP_CONCAT(r.name ORDER BY r.id SEPARATOR ', ') FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = u.id) AS role_names
        FROM users u LEFT JOIN wards w ON w.id = u.ward_id WHERE $where ORDER BY u.full_name", $params, 30);
    render('admin/users', ['title' => 'Users', 'p' => $p, 'type' => $type]);
}

function admin_userForm(?string $id = null): void
{
    admin_user();
    $user = $id ? (DB::one('SELECT * FROM users WHERE id = ?', [(int)$id]) ?? abort(404)) : null;
    $mine = $user ? array_column(DB::all('SELECT r.slug FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = ?', [$user['id']]), 'slug') : [];
    render('admin/user', [
        'title' => $user ? 'Edit user' : 'New staff user', 'user' => $user, 'mine' => $mine, 'errors' => [],
        'roles' => DB::all('SELECT * FROM roles WHERE is_staff = 1 ORDER BY id'), 'wards' => DB::all('SELECT id, name FROM wards WHERE is_active = 1 ORDER BY name'),
    ]);
}

function admin_saveUser(): void
{
    $me = admin_user();
    $id = input_int('id');
    $user = $id ? (DB::one('SELECT * FROM users WHERE id = ?', [$id]) ?? abort(404)) : null;
    $isStaff = !$user || $user['account_type'] === 'staff';
    $d = [
        'full_name' => trim((string)input('full_name', '')), 'phone' => normalize_phone((string)input('phone', '')),
        'email' => trim((string)input('email', '')), 'national_id' => trim((string)input('national_id', '')),
    ];
    $errors = validate($d, ['full_name' => 'required|min:3|max:120', 'phone' => 'required|phone', 'email' => 'email|max:160', 'national_id' => 'nid']);
    if (!$errors && DB::val('SELECT 1 FROM users WHERE phone = ? AND id <> ?', [$d['phone'], $id ?? 0])) {
        $errors['phone'] = 'Another account already uses this phone number.';
    }
    if (!$errors && $d['email'] !== '' && DB::val('SELECT 1 FROM users WHERE email = ? AND id <> ?', [$d['email'], $id ?? 0])) {
        $errors['email'] = 'Another account already uses this email.';
    }
    $roleSlugs = $isStaff ? array_values(array_intersect((array)($_POST['roles'] ?? []), array_column(DB::all('SELECT slug FROM roles WHERE is_staff = 1'), 'slug'))) : [];
    if ($isStaff && !$roleSlugs) {
        $errors['roles'] = 'Choose at least one role.';
    }
    // Separation of duties at account level: payment and approval powers never sit with one person.
    if (array_intersect($roleSlugs, ['finance']) && array_intersect($roleSlugs, ['approver', 'committee'])) {
        $errors['roles'] = 'Finance cannot be combined with committee or approver roles.';
    }
    if (in_array('auditor', $roleSlugs, true) && count($roleSlugs) > 1) {
        $errors['roles'] = 'Auditors must be independent: the auditor role cannot be combined with any other role.';
    }
    if ($user && (int)$user['id'] === (int)$me['id'] && !in_array('admin', $roleSlugs, true)) {
        $errors['roles'] = 'You cannot remove your own administrator role.';
    }
    $limit = input_money('approval_limit');
    if (in_array('approver', $roleSlugs, true) && ($limit === null || $limit <= 0)) {
        $errors['approval_limit'] = 'Approvers need an approval limit (the largest single award they may approve).';
    }
    $ward = input_int('ward_id');
    if (in_array('ward_officer', $roleSlugs, true) && !$ward) {
        $errors['ward_id'] = 'Ward officers must be assigned a ward.';
    }
    if ($errors) {
        $_POST['roles'] = $roleSlugs;
        render('admin/user', [
            'title' => $user ? 'Edit user' : 'New staff user', 'user' => $user, 'mine' => $roleSlugs, 'errors' => $errors,
            'roles' => DB::all('SELECT * FROM roles WHERE is_staff = 1 ORDER BY id'), 'wards' => DB::all('SELECT id, name FROM wards WHERE is_active = 1 ORDER BY name'),
        ]);
    }
    $temp = null;
    DB::tx(function () use ($user, $d, $roleSlugs, $limit, $ward, $isStaff, $me, &$temp) {
        $row = ['full_name' => $d['full_name'], 'phone' => $d['phone'], 'email' => $d['email'] ?: null, 'national_id' => $d['national_id'] ?: null,
            'is_active' => input('is_active') ? 1 : 0];
        if ($isStaff) {
            $row += ['ward_id' => $ward ?: null, 'approval_limit' => in_array('approver', $roleSlugs, true) ? $limit : null];
        }
        if (!$user || input('reset_password')) {
            $temp = 'Kw-' . substr(strtr(base64_encode(random_bytes(9)), '+/', 'xy'), 0, 10) . random_int(10, 99);
            $row += ['password_hash' => Auth::hashPassword($temp), 'must_change_password' => 1, 'failed_logins' => 0, 'locked_until' => null];
        }
        if (input('reset_2fa') && $user) {
            $row += ['totp_enabled' => 0, 'totp_secret' => null];
        }
        if ($user) {
            DB::update('users', $row, 'id = ?', [$user['id']]);
            $uid = (int)$user['id'];
            if (isset($row['password_hash']) || !$row['is_active'] || isset($row['totp_enabled'])) {
                Auth::bumpEpoch($uid); // sign the user out everywhere
            }
        } else {
            $uid = DB::insert('users', $row + ['account_type' => 'staff']);
        }
        if ($isStaff) {
            $before = array_column(DB::all('SELECT r.slug FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = ?', [$uid]), 'slug');
            DB::run('DELETE FROM user_roles WHERE user_id = ?', [$uid]);
            foreach ($roleSlugs as $slug) {
                DB::run('INSERT INTO user_roles (user_id, role_id, granted_by) SELECT ?, id, ? FROM roles WHERE slug = ?', [$uid, $me['id'], $slug]);
            }
            Audit::log('config', $user ? 'user_updated' : 'user_created', 'user', $uid, [
                'roles_before' => implode(',', $before), 'roles_after' => implode(',', $roleSlugs), 'approval_limit' => (string)$row['approval_limit'],
                'ward' => (string)$row['ward_id'], 'active' => (string)$row['is_active'], 'password_reset' => isset($row['password_hash']) ? 'yes' : 'no', '2fa_reset' => isset($row['totp_enabled']) ? 'yes' : 'no',
            ]);
        } else {
            Audit::log('config', 'family_account_updated', 'user', $uid, ['active' => (string)$row['is_active'], 'password_reset' => isset($row['password_hash']) ? 'yes' : 'no']);
        }
    });
    if ($temp) {
        // Shown once to the administrator, and also sent by SMS so it can be handed over securely.
        Sms::send($d['phone'], 'KWB: Your temporary password is ' . $temp . '. You must change it when you first log in. ' . APP_URL . '/login', null, null, true);
        flash('success', 'Saved. Temporary password (shown once, also sent by SMS): ' . $temp);
    } else {
        flash('success', 'User saved.');
    }
    redirect('/admin/users' . ($isStaff ? '' : '?type=families'));
}

function admin_settings(): void
{
    admin_user();
    $vals = [];
    foreach (EDITABLE_SETTINGS as $k => $_) {
        $vals[$k] = setting($k);
    }
    render('admin/settings', ['title' => 'System settings', 'vals' => $vals, 'errors' => []]);
}

function admin_saveSettings(): void
{
    admin_user();
    $vals = [];
    $errors = [];
    foreach (EDITABLE_SETTINGS as $k => [$label, $type]) {
        if ($type === 'roles') {
            $staff = array_column(DB::all('SELECT slug FROM roles WHERE is_staff = 1'), 'slug');
            $vals[$k] = implode(',', array_values(array_intersect($staff, array_unique(array_merge(['admin'], (array)($_POST[$k] ?? []))))));
            continue;
        }
        $v = trim((string)input($k, ''));
        if ($type === 'number' && (!ctype_digit($v) || (int)$v < 1 || ($k === 'max_upload_mb' && (int)$v > 20) || (int)$v > 1000)) {
            $errors[$k] = 'Enter a whole number in the allowed range.';
        } elseif ($type === 'email' && $v !== '' && !filter_var($v, FILTER_VALIDATE_EMAIL)) {
            $errors[$k] = 'Enter a valid email.';
        } elseif (mb_strlen($v) > 255 || ($k === 'site_name' && $v === '')) {
            $errors[$k] = 'Required, up to 255 characters.';
        }
        $vals[$k] = $v;
    }
    if ($errors) {
        render('admin/settings', ['title' => 'System settings', 'vals' => $vals, 'errors' => $errors]);
    }
    DB::tx(function () use ($vals) {
        foreach ($vals as $k => $v) {
            $old = setting($k);
            if ($old !== $v) {
                DB::run('INSERT INTO settings (skey, svalue, updated_by) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE svalue = VALUES(svalue), updated_by = VALUES(updated_by)', [$k, $v, Auth::id()]);
                Audit::log('config', 'setting_changed', 'setting', $k, ['from' => $old, 'to' => $v]);
            }
        }
    });
    flash('success', 'Settings saved.');
    redirect('/admin/settings');
}

function admin_smsLog(): void
{
    admin_user();
    $p = paginate('SELECT COUNT(*) FROM sms_messages', 'SELECT m.*, a.reference FROM sms_messages m LEFT JOIN applications a ON a.id = m.application_id ORDER BY m.id DESC', [], 40);
    render('admin/sms', ['title' => 'SMS log', 'p' => $p]);
}

function admin_list(string $res): void
{
    admin_user();
    [$label, $table, $order, $fields] = admin_res($res);
    $p = paginate("SELECT COUNT(*) FROM $table", "SELECT * FROM $table ORDER BY $order", [], 40);
    render('admin/list', ['title' => $label, 'res' => $res, 'fields' => $fields, 'p' => $p]);
}

function admin_form(string $res, ?string $id = null): void
{
    admin_user();
    [$label, $table, , $fields] = admin_res($res);
    $row = $id ? (DB::one("SELECT * FROM $table WHERE id = ?", [(int)$id]) ?? abort(404)) : null;
    if (!$row && $res === 'sms_templates') {
        abort(404); // templates are tied to system events; they can be edited or switched off, not invented
    }
    render('admin/form', ['title' => ($row ? 'Edit: ' : 'New: ') . $label, 'res' => $res, 'fields' => $fields, 'row' => $row, 'errors' => []]);
}

function admin_save(string $res): void
{
    admin_user();
    [$label, $table, , $fields] = admin_res($res);
    $id = input_int('id');
    $row = $id ? (DB::one("SELECT * FROM $table WHERE id = ?", [$id]) ?? abort(404)) : null;
    if (!$row && $res === 'sms_templates') {
        abort(404);
    }
    $data = [];
    $rules = [];
    $check = [];
    $errors = [];
    foreach ($fields as $k => [$flabel, $type, $rule]) {
        if ($type === 'readonly') {
            continue;
        }
        $v = input($k);
        if ($type === 'bool') {
            $data[$k] = $v ? 1 : 0;
            continue;
        }
        $v = is_string($v) ? trim($v) : '';
        if ($type === 'money') {
            $m = input_money($k);
            if ($v !== '' && ($m === null || $m < 0)) {
                $errors[$k] = 'Enter an amount in KES.';
            }
            $data[$k] = $m;
            $v = $m === null ? '' : (string)$m;
        } elseif ($type === 'datetime') {
            $ts = $v !== '' ? strtotime($v) : false;
            if ($v !== '' && $ts === false) {
                $errors[$k] = 'Enter a valid date and time.';
            }
            $data[$k] = $ts ? date('Y-m-d H:i:s', $ts) : null;
        } elseif (is_array($type)) {
            if ($v !== '' && !array_key_exists($v, $type)) {
                $errors[$k] = 'Choose one of the options.';
            }
            $data[$k] = $v === '' ? null : $v;
        } elseif ($type === 'number') {
            $data[$k] = $v === '' ? null : (int)$v;
        } else {
            $data[$k] = $v === '' ? null : $v;
        }
        $rules[$k] = $rule;
        $check[$k] = $v;
    }
    $errors += validate($check, array_filter($rules), array_map(fn($f) => $f[0], $fields));
    // Cross-field rules
    if ($res === 'cycles' && !$errors && strtotime($data['closes_at']) <= strtotime($data['opens_at'])) {
        $errors['closes_at'] = 'Closing must be after opening.';
    }
    if ($res === 'cycles' && !$errors && ($data['field_verification_rate'] > 100 || $data['secondary_audit_rate'] > 100)) {
        $errors['field_verification_rate'] = 'Rates are percentages from 0 to 100.';
    }
    if ($res === 'cycles' && !$errors && $data['status'] === 'open' && DB::val("SELECT 1 FROM application_cycles WHERE status = 'open' AND id <> ?", [$id ?? 0])) {
        $errors['status'] = 'Another cycle is already open. Close it first.';
    }
    if ($res === 'levels' && !$errors && $data['max_amount'] < $data['min_amount']) {
        $errors['max_amount'] = 'Maximum must be at least the minimum.';
    }
    if ($res === 'events' && !$errors && ($data['capacity'] < 1 || $data['capacity'] > 5000)) {
        $errors['capacity'] = 'Capacity must be between 1 and 5000.';
    }
    if ($res === 'budgets' && !$errors && $row) {
        $committed = (float)DB::val('SELECT COALESCE(SUM(a.amount_approved),0) FROM applications a JOIN students s ON s.id = a.student_id WHERE a.cycle_id = ? AND s.ward_id = ?', [$data['cycle_id'], $data['ward_id']]);
        if ($data['amount'] < $committed) {
            $errors['amount'] = 'Already ' . money($committed) . ' approved in this ward; the budget cannot go below that.';
        }
    }
    if ($errors) {
        render('admin/form', ['title' => ($row ? 'Edit: ' : 'New: ') . $label, 'res' => $res, 'fields' => $fields, 'row' => $row ? array_merge($row, $_POST) : $_POST, 'errors' => $errors]);
    }
    $sendAnnouncement = false;
    if ($res === 'announcements') {
        $wasPublished = $row && $row['published_at'];
        if ($data['is_published'] && !$wasPublished) {
            $data['published_at'] = now();
            $sendAnnouncement = (bool)$data['notify_sms'];
        }
        if (!$row) {
            $data['created_by'] = Auth::id();
        }
    }
    try {
        $newId = DB::tx(function () use ($table, $data, $row, $res) {
            if ($row) {
                DB::update($table, $data, 'id = ?', [$row['id']]);
                $changed = [];
                foreach ($data as $k => $v) {
                    if ((string)($row[$k] ?? '') !== (string)($v ?? '')) {
                        $changed[$k] = ['from' => mb_substr((string)$row[$k], 0, 200), 'to' => mb_substr((string)$v, 0, 200)];
                    }
                }
                Audit::log('config', $res . '_updated', $res, $row['id'], $changed);
                return (int)$row['id'];
            }
            $nid = DB::insert($table, $data);
            Audit::log('config', $res . '_created', $res, $nid, array_map(fn($v) => mb_substr((string)$v, 0, 200), $data));
            return $nid;
        });
    } catch (PDOException $ex) {
        if ((int)($ex->errorInfo[1] ?? 0) === 1062) {
            render('admin/form', ['title' => $label, 'res' => $res, 'fields' => $fields, 'row' => $row ? array_merge($row, $_POST) : $_POST, 'errors' => ['_' => 'An entry with these details already exists.']]);
        }
        throw $ex;
    }
    if ($sendAnnouncement) {
        $phones = DB::all("SELECT phone FROM users WHERE account_type <> 'staff' AND is_active = 1");
        foreach ($phones as $ph) {
            Sms::template('announcement', $ph['phone'], ['title' => mb_substr($data['title'], 0, 100), 'url' => APP_URL . '/announcements/' . $newId]);
        }
        foreach (DB::all("SELECT id FROM users WHERE account_type <> 'staff' AND is_active = 1") as $uu) {
            notify_user((int)$uu['id'], $data['title'], mb_substr($data['body'], 0, 300), '/announcements/' . $newId);
        }
        flash('info', 'Announcement sent to ' . count($phones) . ' registered famil' . (count($phones) === 1 ? 'y' : 'ies') . ' by SMS.');
    }
    flash('success', 'Saved.');
    redirect('/admin/r/' . $res);
}

/** Live security self-check: every item is measured on this installation, not a static list. */
function admin_security(): void
{
    admin_user();
    $c = [];
    $add = function (string $state, string $title, string $detail, ?string $fix = null) use (&$c) {
        $c[] = compact('state', 'title', 'detail', 'fix');
    };
    $local = is_local_request();
    $https = str_starts_with(APP_URL, 'https://');
    $add($https ? 'ok' : ($local ? 'info' : 'bad'), 'Encrypted connection (HTTPS)',
        $https ? 'The site is served over HTTPS; login cookies are marked Secure.' : 'The site is running without HTTPS.',
        $https ? null : 'Before going live, install a certificate (free with Let’s Encrypt / cPanel AutoSSL) and set APP_URL to https://… in .env.');
    $debug = filter_var(env('APP_DEBUG', 'false'), FILTER_VALIDATE_BOOLEAN);
    $add($debug ? 'bad' : 'ok', 'Technical errors hidden from users', $debug ? 'APP_DEBUG is on: error details could be shown to visitors.' : 'Visitors see a friendly message; details go to the private error log.', $debug ? 'Set APP_DEBUG=false in .env.' : null);
    $k = (string)env('APP_KEY', '');
    $s = (string)env('APP_SEAL_KEY', '');
    $keysOk = strlen($k) >= 32 && strlen($s) >= 32 && $k !== $s;
    $add($keysOk ? 'ok' : 'bad', 'Secret keys', $keysOk ? 'APP_KEY and APP_SEAL_KEY are long, random and different.' : 'A secret key is missing, too short or reused.', $keysOk ? 'Keep a sealed offline copy of .env: losing APP_SEAL_KEY means old sheets cannot be verified.' : 'Generate new keys (64 random hex characters each) before issuing any sheets.');
    $demo = 0;
    foreach (DB::all("SELECT password_hash FROM users WHERE is_active = 1 AND (phone LIKE '07000000%' OR phone = '0711000001')") as $r) {
        $demo += password_verify('Demo@2026pass', $r['password_hash']) ? 1 : 0;
    }
    $add($demo ? 'bad' : 'ok', 'Demo accounts', $demo ? "$demo demo account(s) with the public demo password are active." : 'No active account uses the public demo password.', $demo ? 'Before real use: Administration → Users → open each demo account → untick “Account active”.' : null);
    $req = array_filter(explode(',', setting('twofa_roles', 'admin')));
    $missing = DB::all("SELECT DISTINCT u.full_name FROM users u JOIN user_roles ur ON ur.user_id = u.id JOIN roles r ON r.id = ur.role_id
        WHERE u.is_active = 1 AND u.totp_enabled = 0 AND r.slug IN ('" . implode("','", array_map(fn($x) => preg_replace('/[^a-z_]/', '', $x), array_merge($req, ['admin']))) . "')");
    $moneyCovered = !array_diff(['approver', 'finance'], $req);
    $add($moneyCovered ? 'ok' : 'warn', 'Two-step login required for money roles', 'Required for: ' . implode(', ', array_unique(array_merge(['admin'], $req))) . '.', $moneyCovered ? null : 'Recommended: Settings → tick Approver, Finance and Auditor under “Two-step login required for”.');
    $add($missing ? 'info' : 'ok', 'Staff who still need to set up two-step login', $missing ? implode(', ', array_column($missing, 'full_name')) . ' — they will be asked at their next login.' : 'Everyone who needs it has set it up.');
    $sms = !Sms::testMode();
    $add($sms ? 'ok' : 'warn', 'SMS provider', $sms ? 'Messages are delivered by Africa’s Talking.' : 'Test mode: messages are only recorded, not sent. Phone numbers of new accounts are not verified by SMS on the public internet.', $sms ? null : 'Set SMS_DRIVER=africastalking with AT_USERNAME, AT_API_KEY and AT_SENDER_ID in .env.');
    $unverified = (int)DB::val("SELECT COUNT(*) FROM users WHERE account_type <> 'staff' AND phone_verified_at IS NULL");
    if ($unverified) {
        $add('info', 'Family accounts with unverified phone numbers', "$unverified account(s) were created while SMS was in test mode.");
    }
    [$chainOk, $checked] = Audit::verify();
    $add($chainOk ? 'ok' : 'bad', 'Tamper-proof audit trail', $chainOk ? "Hash chain intact ($checked entries checked just now)." : 'The audit chain does not verify: records may have been altered directly in the database.', $chainOk ? null : 'Tell the auditor immediately and compare with the latest backup.');
    $triggers = (int)DB::val('SELECT COUNT(*) FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA = DATABASE()');
    $add($triggers >= 7 ? 'ok' : 'bad', 'Database protections', $triggers >= 7 ? 'Audit log, sealed sheets and paid payments are locked by the database itself.' : 'Protective database triggers are missing.', $triggers >= 7 ? null : 'Re-import database/schema.sql into an empty database or ask your developer.');
    $backups = glob(BASE_PATH . '/storage/backups/db-*.enc') ?: [];
    $last = $backups ? max(array_map('filemtime', $backups)) : 0;
    $add($last > time() - 2 * 86400 ? 'ok' : 'warn', 'Backups', $last ? 'Latest automatic backup: ' . date('j M Y H:i', $last) . '.' : 'No automatic backup found on this server.', $last > time() - 2 * 86400 ? null : 'Linux: install the cron jobs in deploy/crontab.txt. Windows/XAMPP: export the database from phpMyAdmin and copy storage/private to another disk at least weekly.');
    $add(is_file(BASE_PATH . '/storage/install-code.txt') ? 'warn' : 'ok', 'Installer locked', 'The one-click installer can no longer run on this site.', is_file(BASE_PATH . '/storage/install-code.txt') ? 'Delete storage/install-code.txt.' : null);
    $add(version_compare(PHP_VERSION, '8.2', '>=') ? 'ok' : 'bad', 'PHP version', 'PHP ' . PHP_VERSION . (version_compare(PHP_VERSION, '8.2', '>=') ? ' (supported).' : ' — too old.'));
    $add(ini_get('display_errors') && !in_array(strtolower((string)ini_get('display_errors')), ['0', 'off', 'stderr'], true) ? 'warn' : 'ok', 'PHP error display', 'The application hides errors itself; the server setting display_errors is ' . (ini_get('display_errors') ?: 'off') . '.');
    $events = DB::all("SELECT action, COUNT(*) n FROM audit_logs WHERE category = 'security' AND created_at > NOW() - INTERVAL 1 DAY
        AND action IN ('login_failed','account_locked','2fa_failed','session_hijack_suspected','sheet_verify_failed','upload_cap_reached','phone_verify_failed','forbidden') GROUP BY action ORDER BY n DESC");
    $score = count(array_filter($c, fn($x) => $x['state'] === 'ok')) . ' of ' . count($c);
    render('admin/security', ['title' => 'Security checklist', 'checks' => $c, 'events' => $events, 'score' => $score]);
}
