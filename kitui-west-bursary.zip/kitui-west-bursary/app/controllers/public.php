<?php
declare(strict_types=1);

function public_home(): void
{
    $cycle = current_cycle() ?? DB::one("SELECT * FROM application_cycles WHERE status IN ('open','draft') AND closes_at > NOW() ORDER BY opens_at LIMIT 1");
    $news = DB::all('SELECT id, title, published_at FROM announcements WHERE is_published = 1 ORDER BY published_at DESC LIMIT 3');
    $stats = public_stats(latest_cycle()['id'] ?? 0);
    $levels = $cycle ? DB::all('SELECT level, min_amount, max_amount FROM cycle_levels WHERE cycle_id = ? AND is_eligible = 1 ORDER BY FIELD(level,"secondary","tvet","college","university","special")', [$cycle['id']]) : [];
    $events = DB::all('SELECT e.title, e.venue, e.starts_at FROM mentorship_events e JOIN mentorship_programs p ON p.id = e.program_id WHERE e.is_active = 1 AND p.is_active = 1 AND e.starts_at >= NOW() ORDER BY e.starts_at LIMIT 3');
    render('public/home', ['title' => '', 'cycle' => $cycle, 'news' => $news, 'stats' => $stats, 'levels' => $levels, 'events' => $events], 'public');
}

function public_about(): void { render('public/about', ['title' => 'About'], 'public'); }
function public_how(): void { render('public/how', ['title' => 'How it works'], 'public'); }
function public_contact(): void { render('public/contact', ['title' => 'Contact'], 'public'); }

function public_eligibility(): void
{
    $cycle = current_cycle() ?? latest_cycle();
    $levels = $cycle ? DB::all('SELECT * FROM cycle_levels WHERE cycle_id = ? AND is_eligible = 1 ORDER BY FIELD(level,"secondary","tvet","college","university","special")', [$cycle['id']]) : [];
    $docs = $cycle ? DB::all('SELECT dt.name, dt.description, cd.level, cd.is_required FROM cycle_documents cd JOIN document_types dt ON dt.id = cd.document_type_id WHERE cd.cycle_id = ? AND dt.staff_only = 0 ORDER BY cd.is_required DESC, dt.id', [$cycle['id']]) : [];
    render('public/eligibility', ['title' => 'Eligibility and requirements', 'cycle' => $cycle, 'levels' => $levels, 'docs' => $docs], 'public');
}

function public_period(): void
{
    $cycles = DB::all("SELECT * FROM application_cycles WHERE status <> 'draft' ORDER BY opens_at DESC LIMIT 6");
    $upcoming = DB::all("SELECT * FROM application_cycles WHERE status IN ('draft','open') AND opens_at > NOW() ORDER BY opens_at LIMIT 3");
    render('public/period', ['title' => 'Application period', 'cycles' => $cycles, 'current' => current_cycle(), 'upcoming' => $upcoming], 'public');
}

function public_faqs(): void
{
    render('public/faqs', ['title' => 'Frequently asked questions', 'faqs' => DB::all('SELECT * FROM faqs WHERE is_active = 1 ORDER BY sort_order, id')], 'public');
}

function public_announcements(): void
{
    $p = paginate('SELECT COUNT(*) FROM announcements WHERE is_published = 1', 'SELECT * FROM announcements WHERE is_published = 1 ORDER BY published_at DESC', [], 10);
    render('public/announcements', ['title' => 'Announcements', 'p' => $p], 'public');
}

function public_announcement(string $id): void
{
    $a = DB::one('SELECT * FROM announcements WHERE id = ? AND is_published = 1', [(int)$id]) ?? abort(404);
    render('public/announcement', ['title' => $a['title'], 'a' => $a], 'public');
}

/** Aggregates only. Groups smaller than the privacy threshold are suppressed to avoid identifying anyone. */
function public_stats(int $cycleId): array
{
    $paid = "a.status IN ('disbursed','closed')";
    $approved = "a.status IN ('approved','partially_approved','ready_for_payment','payment_processing','disbursed','payment_failed','closed')";
    $verified = "a.status IN ('committee_review','recommended','not_approved') OR $approved";
    $row = DB::one("SELECT
        COUNT(*) AS received,
        SUM(CASE WHEN $verified THEN 1 ELSE 0 END) AS verified,
        SUM(CASE WHEN $approved THEN 1 ELSE 0 END) AS approved,
        SUM(CASE WHEN $paid THEN 1 ELSE 0 END) AS disbursed,
        COALESCE(SUM(CASE WHEN $approved THEN a.amount_approved END),0) AS amount_approved,
        COALESCE(SUM(a.amount_paid),0) AS amount_paid
        FROM applications a WHERE a.cycle_id = ? AND a.status NOT IN ('draft','withdrawn')", [$cycleId]) ?? [];
    return array_map(fn($v) => (float)($v ?? 0), $row);
}

function public_transparency(): void
{
    $cycles = DB::all("SELECT id, name FROM application_cycles WHERE status <> 'draft' ORDER BY opens_at DESC");
    $cycleId = input_int('cycle') ?? ($cycles[0]['id'] ?? 0);
    $min = max(1, (int)setting('privacy_threshold', '5'));
    $stats = public_stats($cycleId);
    $approvedSet = "('approved','partially_approved','ready_for_payment','payment_processing','disbursed','payment_failed','closed')";
    $wards = DB::all("SELECT w.name, COUNT(a.id) AS apps,
            SUM(a.status IN $approvedSet) AS approved,
            COALESCE(SUM(CASE WHEN a.status IN $approvedSet THEN a.amount_approved END),0) AS amount,
            COALESCE(SUM(a.amount_paid),0) AS paid,
            (SELECT amount FROM cycle_ward_budgets b WHERE b.cycle_id = ? AND b.ward_id = w.id) AS budget
        FROM wards w LEFT JOIN students s ON s.ward_id = w.id
        LEFT JOIN applications a ON a.student_id = s.id AND a.cycle_id = ? AND a.status NOT IN ('draft','withdrawn')
        WHERE w.is_active = 1 GROUP BY w.id ORDER BY w.name", [$cycleId, $cycleId]);
    $levels = DB::all("SELECT a.level, COUNT(*) AS apps, SUM(a.status IN $approvedSet) AS approved,
            COALESCE(SUM(CASE WHEN a.status IN $approvedSet THEN a.amount_approved END),0) AS amount
        FROM applications a WHERE a.cycle_id = ? AND a.status NOT IN ('draft','withdrawn') GROUP BY a.level", [$cycleId]);
    $gender = DB::all("SELECT s.gender, COUNT(*) AS n FROM applications a JOIN students s ON s.id = a.student_id WHERE a.cycle_id = ? AND a.status IN $approvedSet GROUP BY s.gender", [$cycleId]);
    $mentor = DB::one('SELECT COUNT(DISTINCT er.user_id) AS participants, SUM(er.attended = 1) AS attended, COUNT(DISTINCT e.id) AS events
        FROM mentorship_events e LEFT JOIN event_registrations er ON er.event_id = e.id WHERE YEAR(e.starts_at) = (SELECT year FROM application_cycles WHERE id = ?)', [$cycleId]);
    render('public/transparency', ['title' => 'Transparency dashboard', 'cycles' => $cycles, 'cycleId' => $cycleId, 'stats' => $stats,
        'wards' => $wards, 'levels' => $levels, 'gender' => $gender, 'mentor' => $mentor, 'min' => $min], 'public');
}

function public_verify(): void
{
    $code = strtoupper(trim((string)input('code', '')));
    $result = null;
    if ($code !== '') {
        rate_limit('verify', 30, 600);
        $result = Seal::verify($code);
        if ($result['doc']) {
            $result['payload'] = json_decode($result['doc']['payload'], true);
        }
    }
    render('public/verify', ['title' => 'Check an official document', 'code' => $code, 'result' => $result], 'public');
}

function public_lang(string $code): void
{
    $_SESSION['lang'] = in_array($code, ['en', 'sw'], true) ? $code : 'en';
    back('/');
}

function public_privacy(): void
{
    render('public/privacy', ['title' => 'Privacy notice'], 'public');
}
