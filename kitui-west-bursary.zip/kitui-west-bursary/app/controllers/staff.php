<?php
declare(strict_types=1);

const STAFF_CASE_ROLES = ['doc_officer', 'ward_officer', 'committee', 'approver', 'finance', 'auditor'];

function staff_user(): array
{
    $u = Auth::require();
    if ($u['account_type'] !== 'staff') {
        abort(403);
    }
    return $u;
}

/** Deny case access to officers whose phone/ID matches the household, and log every view. */
function staff_case(int $id, bool $logView = false): array
{
    $u = staff_user();
    if (!Auth::has(...STAFF_CASE_ROLES)) {
        abort(403);
    }
    $a = Workflow::app($id);
    if ($a['status'] === 'draft' || $a['status'] === 'withdrawn') {
        abort(404);
    }
    $me = DB::one('SELECT phone, national_id FROM users WHERE id = ?', [$u['id']]);
    if ((int)$a['applicant_user_id'] === (int)$u['id'] || $me['phone'] === $a['guardian_phone'] || ($me['national_id'] && $me['national_id'] === $a['guardian_nid'])) {
        Audit::log('access', 'household_conflict_block', 'application', $id);
        abort(403, 'This application is linked to your own phone or ID number, so it is hidden from you.');
    }
    if ($logView) {
        Audit::log('access', 'application_viewed', 'application', $id);
    }
    return $a;
}

function staff_queue_sql(string $duty, array $u): array
{
    $statuses = Workflow::DUTIES[$duty][1];
    $where = 'a.status IN (' . implode(',', array_fill(0, count($statuses), '?')) . ')';
    $params = $statuses;
    if ($duty === 'approval') {
        $where = "a.status = 'recommended'";
        $params = [];
    }
    if ($duty === 'verification' && $u['ward_id']) {
        $where .= ' AND s.ward_id = ?';
        $params[] = $u['ward_id'];
    }
    if ($duty === 'audit_sample') {
        $where .= " AND a.secondary_audit = 1 AND NOT EXISTS (SELECT 1 FROM application_events e WHERE e.application_id = a.id AND e.action = 'secondary_audit_done')";
    }
    return [$where, $params];
}

function staff_dashboard(): void
{
    $u = staff_user();
    $roles = Auth::roles();
    $cards = [];
    $dutyRole = ['doc_check' => 'doc_officer', 'verification' => 'ward_officer', 'committee' => 'committee', 'approval' => 'approver', 'audit_sample' => 'auditor'];
    foreach ($dutyRole as $duty => $role) {
        if (in_array($role, $roles, true)) {
            [$where, $params] = staff_queue_sql($duty, $u);
            $cards[$duty] = (int)DB::val("SELECT COUNT(*) FROM applications a LEFT JOIN students s ON s.id = a.student_id WHERE $where", $params);
        }
    }
    $amendRows = in_array('approver', $roles, true) ? DB::all("SELECT m.*, a.reference, u.full_name AS requester FROM amendments m JOIN applications a ON a.id = m.application_id JOIN users u ON u.id = m.requested_by
        WHERE m.status = 'pending' AND m.requested_by <> ? ORDER BY m.id", [$u['id']]) : [];
    $amend = in_array('approver', $roles, true) ? count($amendRows) : null;
    $flags = array_intersect(['doc_officer', 'ward_officer', 'auditor'], $roles) ? (int)DB::val("SELECT COUNT(*) FROM risk_flags f JOIN applications a ON a.id = f.application_id WHERE f.status = 'open' AND a.status NOT IN ('closed','withdrawn','not_approved')") : null;
    $cycle = latest_cycle();
    $stats = $cycle ? DB::one("SELECT COUNT(*) AS total, SUM(status NOT IN ('draft','withdrawn')) AS submitted, SUM(status IN ('approved','partially_approved','ready_for_payment','payment_processing','disbursed','closed','payment_failed')) AS approved,
        COALESCE(SUM(amount_approved),0) AS approved_amt, COALESCE(SUM(amount_paid),0) AS paid_amt FROM applications WHERE cycle_id = ?", [$cycle['id']]) : null;
    $recent = DB::all("SELECT e.created_at, e.action, e.to_status, a.id, a.reference FROM application_events e JOIN applications a ON a.id = e.application_id WHERE e.user_id = ? ORDER BY e.id DESC LIMIT 8", [$u['id']]);
    render('staff/dashboard', ['title' => 'Staff dashboard', 'u' => $u, 'roles' => $roles, 'cards' => $cards, 'amend' => $amend, 'amendRows' => $amendRows, 'flags' => $flags, 'cycle' => $cycle, 'stats' => $stats, 'recent' => $recent,
        'noTotp' => !$u['totp_enabled']]);
}

function staff_queue(string $duty): void
{
    $u = staff_user();
    if (!isset(Workflow::DUTIES[$duty]) || in_array($duty, ['payment_prep', 'payment_authorize', 'payment_record', 'reconcile'], true)) {
        abort(404);
    }
    if (!Auth::has(...Workflow::DUTIES[$duty][0])) {
        abort(403);
    }
    [$where, $params] = staff_queue_sql($duty, $u);
    $sel = "SELECT a.*, s.first_name, s.last_name, s.ward_id, w.name AS ward_name, i.name AS institution_name, g.phone AS guardian_phone, g.national_id AS guardian_nid,
        (SELECT COUNT(*) FROM risk_flags f WHERE f.application_id = a.id AND f.status = 'open') AS open_flags
        FROM applications a LEFT JOIN students s ON s.id = a.student_id LEFT JOIN wards w ON w.id = s.ward_id LEFT JOIN institutions i ON i.id = a.institution_id LEFT JOIN guardians g ON g.id = a.guardian_id
        WHERE $where ORDER BY a.submitted_at";
    $p = paginate("SELECT COUNT(*) FROM applications a LEFT JOIN students s ON s.id = a.student_id WHERE $where", $sel, $params, 25);
    foreach ($p['rows'] as &$r) {
        $why = Workflow::blockReason($r, $duty);
        $r['_block'] = $why === 'coi_required' ? null : $why;
    }
    unset($r);
    render('staff/queue', ['title' => Workflow::DUTY_NAMES[$duty] . ' queue', 'duty' => $duty, 'p' => $p]);
}

function staff_committee(): void
{
    staff_user();
    if (!Auth::has('committee', 'approver', 'auditor')) {
        abort(403);
    }
    $view = (string)input('view', 'pending');
    $statusSql = match ($view) {
        'recommended' => "a.status = 'recommended'",
        'decided' => "a.status IN ('approved','partially_approved','not_approved','ready_for_payment','payment_processing','payment_failed','disbursed','closed')",
        default => "a.status = 'committee_review'",
    };
    $params = [];
    $ward = input_int('ward');
    if ($ward) {
        $statusSql .= ' AND s.ward_id = ?';
        $params[] = $ward;
    }
    $cycle = input_int('cycle') ?? (int)(latest_cycle()['id'] ?? 0);
    $statusSql .= ' AND a.cycle_id = ?';
    $params[] = $cycle;
    $sel = "SELECT a.id, a.reference, a.status, a.level, a.amount_requested, a.amount_recommended, a.amount_approved, a.amount_paid, a.field_visit_required,
            s.first_name, s.last_name, w.name AS ward_name, i.name AS institution_name,
            (SELECT COALESCE(SUM(p.amount_paid),0) FROM applications p WHERE p.student_id = a.student_id AND p.id <> a.id) AS previous_support,
            (SELECT COUNT(*) FROM documents d WHERE d.application_id = a.id AND d.status = 'verified') AS docs_ok,
            (SELECT COUNT(*) FROM documents d WHERE d.application_id = a.id AND d.status <> 'superseded') AS docs_all,
            (SELECT fv.outcome FROM field_visits fv WHERE fv.application_id = a.id ORDER BY fv.id DESC LIMIT 1) AS field_outcome,
            (SELECT GROUP_CONCAT(CONCAT(f.severity, ':', f.code) SEPARATOR ', ') FROM risk_flags f WHERE f.application_id = a.id AND f.status = 'open') AS flags,
            (SELECT COUNT(*) FROM committee_reviews cr WHERE cr.application_id = a.id) AS reviews
        FROM applications a JOIN students s ON s.id = a.student_id LEFT JOIN wards w ON w.id = s.ward_id LEFT JOIN institutions i ON i.id = a.institution_id
        WHERE $statusSql ORDER BY w.name, a.submitted_at";
    $p = paginate("SELECT COUNT(*) FROM applications a JOIN students s ON s.id = a.student_id WHERE $statusSql", $sel, $params, 30);
    $totals = DB::one("SELECT COALESCE(SUM(a.amount_requested),0) req, COALESCE(SUM(a.amount_recommended),0) rec, COALESCE(SUM(a.amount_approved),0) appr, COALESCE(SUM(a.amount_paid),0) paid
        FROM applications a JOIN students s ON s.id = a.student_id WHERE $statusSql", $params);
    $budgets = DB::all("SELECT w.name, b.amount, (SELECT COALESCE(SUM(a.amount_approved),0) FROM applications a JOIN students s ON s.id = a.student_id WHERE s.ward_id = w.id AND a.cycle_id = b.cycle_id
            AND a.status IN ('approved','partially_approved','ready_for_payment','payment_processing','payment_failed','disbursed','closed')) AS committed
        FROM cycle_ward_budgets b JOIN wards w ON w.id = b.ward_id WHERE b.cycle_id = ? ORDER BY w.name", [$cycle]);
    render('staff/committee', ['title' => 'Committee dashboard', 'p' => $p, 'view' => $view, 'ward' => $ward, 'cycle' => $cycle, 'totals' => $totals, 'budgets' => $budgets,
        'wards' => DB::all('SELECT id, name FROM wards ORDER BY name'), 'cycles' => DB::all('SELECT id, name FROM application_cycles ORDER BY opens_at DESC')]);
}

function staff_search(): void
{
    staff_user();
    if (!Auth::has(...STAFF_CASE_ROLES)) {
        abort(403);
    }
    $q = trim((string)input('q', ''));
    $rows = [];
    if ($q !== '') {
        rate_limit('staff_search', 60, 300, (string)Auth::id());
        $like = '%' . str_replace(['%', '_'], ['\%', '\_'], $q) . '%';
        $rows = DB::all("SELECT a.id, a.reference, a.status, s.first_name, s.last_name, w.name AS ward_name, i.name AS institution_name, c.name AS cycle_name
            FROM applications a JOIN students s ON s.id = a.student_id JOIN application_cycles c ON c.id = a.cycle_id LEFT JOIN wards w ON w.id = s.ward_id LEFT JOIN institutions i ON i.id = a.institution_id
            LEFT JOIN guardians g ON g.id = a.guardian_id
            WHERE a.status NOT IN ('draft','withdrawn') AND (a.reference = ? OR CONCAT(s.first_name, ' ', s.last_name) LIKE ? OR s.birth_cert_no = ? OR s.upi_no = ? OR g.phone = ?)
            ORDER BY a.id DESC LIMIT 50", [strtoupper($q), $like, strtoupper($q), strtoupper($q), normalize_phone($q)]);
        Audit::log('access', 'staff_search', 'search', null, ['q' => mb_substr($q, 0, 40), 'results' => count($rows)]);
    }
    render('staff/search', ['title' => 'Find application', 'q' => $q, 'rows' => $rows]);
}

function staff_show(string $id): void
{
    $u = staff_user();
    $a = staff_case((int)$id, true);
    $roles = Auth::roles();
    $duties = [];
    foreach (Workflow::DUTIES as $duty => [$dRoles]) {
        if (array_intersect($dRoles, $roles) && !in_array($duty, ['payment_prep', 'payment_authorize', 'payment_record', 'reconcile'], true)) {
            $duties[$duty] = Workflow::blockReason($a, $duty);
        }
    }
    $docs = DB::all("SELECT d.*, t.name AS type_name, t.code, t.staff_only, u.full_name AS verifier FROM documents d JOIN document_types t ON t.id = d.document_type_id
        LEFT JOIN users u ON u.id = d.verified_by WHERE d.application_id = ? AND d.status <> 'superseded' ORDER BY t.staff_only, d.document_type_id, d.id", [$id]);
    if (!Auth::has('doc_officer', 'ward_officer', 'committee', 'approver', 'auditor')) {
        $docs = array_values(array_filter($docs, fn($d) => !$d['staff_only'])); // finance never sees homestead photos
    }
    $required = DB::all("SELECT t.id, t.name FROM cycle_documents cd JOIN document_types t ON t.id = cd.document_type_id WHERE cd.cycle_id = ? AND cd.is_required = 1 AND (cd.level = 'all' OR cd.level = ?) AND t.staff_only = 0",
        [$a['cycle_id'], $a['level']]);
    $prev = DB::all("SELECT a.id, a.reference, a.status, a.amount_approved, a.amount_paid, c.name AS cycle_name FROM applications a JOIN application_cycles c ON c.id = a.cycle_id
        WHERE a.student_id = ? AND a.id <> ? AND a.status NOT IN ('draft','withdrawn') ORDER BY a.id DESC", [$a['student_id'], $id]);
    render('staff/show', [
        'title' => $a['reference'], 'a' => $a, 'u' => $u, 'duties' => $duties, 'docs' => $docs, 'required' => $required, 'prev' => $prev,
        'history' => Workflow::history((int)$id),
        'flags' => DB::all('SELECT f.*, u.full_name AS resolver FROM risk_flags f LEFT JOIN users u ON u.id = f.resolved_by WHERE f.application_id = ? ORDER BY FIELD(f.status, "open") DESC, FIELD(f.severity, "high", "medium", "low")', [$id]),
        'visits' => DB::all('SELECT v.*, u.full_name AS officer FROM field_visits v JOIN users u ON u.id = v.officer_id WHERE v.application_id = ? ORDER BY v.id', [$id]),
        'reviews' => DB::all('SELECT r.*, u.full_name AS member FROM committee_reviews r JOIN users u ON u.id = r.member_id WHERE r.application_id = ? ORDER BY r.id', [$id]),
        'approvals' => DB::all('SELECT p.*, u.full_name AS approver FROM approvals p JOIN users u ON u.id = p.approver_id WHERE p.application_id = ? ORDER BY p.id', [$id]),
        'amendments' => DB::all('SELECT m.*, r.full_name AS requester, v.full_name AS reviewer FROM amendments m JOIN users r ON r.id = m.requested_by LEFT JOIN users v ON v.id = m.reviewed_by WHERE m.application_id = ? ORDER BY m.id', [$id]),
        'payments' => DB::all('SELECT p.*, b.reference AS batch_ref FROM payments p JOIN payment_batches b ON b.id = p.batch_id WHERE p.application_id = ? ORDER BY p.id', [$id]),
        'coi' => DB::one('SELECT * FROM coi_declarations WHERE user_id = ? AND application_id = ?', [$u['id'], $id]),
        'rule' => DB::one('SELECT * FROM cycle_levels WHERE cycle_id = ? AND level = ?', [$a['cycle_id'], $a['level']]),
    ]);
}

function staff_coi(string $id): void
{
    $u = staff_user();
    $a = staff_case((int)$id);
    if (DB::val('SELECT 1 FROM coi_declarations WHERE user_id = ? AND application_id = ?', [$u['id'], $id])) {
        redirect('/staff/applications/' . $id);
    }
    $conflict = input('has_conflict') === '1';
    $details = mb_substr(trim((string)input('details', '')), 0, 255);
    if ($conflict && $details === '') {
        flash('error', 'Briefly describe the conflict (for example: relative, neighbour, business partner).');
        redirect('/staff/applications/' . $id);
    }
    DB::tx(function () use ($u, $id, $conflict, $details) {
        DB::insert('coi_declarations', ['user_id' => $u['id'], 'application_id' => (int)$id, 'has_conflict' => $conflict ? 1 : 0, 'details' => $details ?: null]);
        Workflow::event((int)$id, 'system', $conflict ? 'conflict_declared' : 'no_conflict_declared', $conflict ? $details : null);
        Audit::log('workflow', 'coi_declared', 'application', $id, ['conflict' => $conflict ? 'yes' : 'no']);
    });
    flash($conflict ? 'info' : 'success', $conflict ? 'Conflict recorded. The application is locked for you and another officer will handle it.' : 'Declaration recorded.');
    redirect('/staff/applications/' . $id);
}

function staff_reviewDocument(string $id, string $doc): void
{
    $a = staff_case((int)$id);
    Workflow::assertCan($a, 'doc_check');
    $d = DB::one("SELECT * FROM documents WHERE id = ? AND application_id = ? AND status IN ('pending','verified','rejected')", [(int)$doc, (int)$id]) ?? abort(404);
    $decision = (string)input('decision');
    $reason = mb_substr(trim((string)input('reason', '')), 0, 255);
    if (!in_array($decision, ['verified', 'rejected'], true) || ($decision === 'rejected' && $reason === '')) {
        flash('error', 'Choose verify or reject. A rejection needs a reason the applicant will see.');
        redirect('/staff/applications/' . $id . '#doc-' . $doc);
    }
    DB::tx(function () use ($d, $a, $decision, $reason) {
        DB::update('documents', ['status' => $decision, 'rejection_reason' => $decision === 'rejected' ? $reason : null, 'verified_by' => Auth::id(), 'verified_at' => now()], 'id = ?', [$d['id']]);
        Workflow::event((int)$a['id'], 'doc_check', 'document_' . $decision, $decision === 'rejected' ? $reason : null);
        Audit::log('workflow', 'document_' . $decision, 'document', $d['id'], ['application_id' => $a['id'], 'reason' => $reason]);
    });
    redirect('/staff/applications/' . $id . '#documents');
}

function staff_docCheck(string $id): void
{
    $a = staff_case((int)$id);
    Workflow::assertCan($a, 'doc_check');
    $decision = (string)input('decision');
    $comment = trim((string)input('comment', ''));
    if ($decision === 'return') {
        if (mb_strlen($comment) < 10) {
            flash('error', 'Tell the applicant exactly what to fix (at least 10 characters).');
            redirect('/staff/applications/' . $id);
        }
        Workflow::move($a, 'doc_check', 'returned_for_documents', 'returned', $comment, ['return_reason' => $comment, 'wizard_step' => 5]);
        flash('success', 'Returned to the applicant with your note. They were notified by SMS.');
        redirect('/staff/queue/doc_check');
    }
    $pending = (int)DB::val("SELECT COUNT(*) FROM documents d JOIN document_types t ON t.id = d.document_type_id WHERE d.application_id = ? AND d.status IN ('pending','rejected') AND t.staff_only = 0", [$id]);
    $missing = DB::val("SELECT t.name FROM cycle_documents cd JOIN document_types t ON t.id = cd.document_type_id WHERE cd.cycle_id = ? AND cd.is_required = 1 AND t.staff_only = 0 AND (cd.level = 'all' OR cd.level = ?)
        AND NOT EXISTS (SELECT 1 FROM documents d WHERE d.application_id = ? AND d.document_type_id = t.id AND d.status = 'verified') LIMIT 1", [$a['cycle_id'], $a['level'], $id]);
    if ($pending || $missing) {
        flash('error', $missing ? "“$missing” has not been verified. Verify every required document, or return the application." : 'Some documents are still unchecked or rejected. Verify them or return the application.');
        redirect('/staff/applications/' . $id);
    }
    Workflow::move($a, 'doc_check', 'documents_passed', 'verification', $comment ?: null);
    flash('success', 'Documents passed. The application moved to verification.');
    redirect('/staff/queue/doc_check');
}

function staff_verify(string $id): void
{
    $a = staff_case((int)$id);
    Workflow::assertCan($a, 'verification');
    $decision = (string)input('decision');
    $comment = trim((string)input('comment', ''));
    if (mb_strlen($comment) < 10) {
        flash('error', 'Record your verification findings (at least 10 characters).');
        redirect('/staff/applications/' . $id);
    }
    if ($decision === 'field') {
        if ($a['status'] !== 'verification') {
            abort(409, 'A field visit is already required.');
        }
        Workflow::move($a, 'verification', 'field_visit_scheduled', 'field_verification', $comment, ['field_visit_required' => 1]);
        flash('success', 'Field visit required. Record the visit on this page when done.');
    } elseif ($decision === 'return') {
        Workflow::move($a, 'verification', 'returned_for_clarification', 'returned', $comment, ['return_reason' => $comment]);
        flash('success', 'Returned to the applicant.');
    } elseif ($decision === 'committee') {
        $visited = DB::val("SELECT outcome FROM field_visits WHERE application_id = ? ORDER BY id DESC LIMIT 1", [$id]);
        if ((int)$a['field_visit_required'] === 1 && !$visited) {
            flash('error', 'This application was selected for a field visit. Record the visit before sending it to the committee.');
            redirect('/staff/applications/' . $id);
        }
        $highOpen = (int)DB::val("SELECT COUNT(*) FROM risk_flags WHERE application_id = ? AND severity = 'high' AND status = 'open'", [$id]);
        if ($highOpen) {
            flash('error', 'Resolve the high-severity risk flags (clear or confirm them with a note) first.');
            redirect('/staff/applications/' . $id);
        }
        DB::tx(function () use ($a, $comment) {
            DB::run('UPDATE students SET verified_at = COALESCE(verified_at, NOW()) WHERE id = ?', [$a['student_id']]);
            Workflow::move($a, 'verification', 'verified', 'committee_review', $comment);
        });
        flash('success', 'Verified and sent to the committee.');
    } else {
        abort(422, 'Choose an outcome.');
    }
    redirect('/staff/queue/verification');
}

function staff_fieldVisit(string $id): void
{
    $a = staff_case((int)$id);
    Workflow::assertCan($a, 'verification');
    $d = $_POST;
    $errors = validate($d, ['visit_date' => 'required|date', 'household_observation' => 'required|min:10|max:2000', 'findings' => 'required|min:10|max:2000', 'outcome' => 'required|in:confirmed,concerns,not_confirmed']);
    if (!$errors && strtotime($d['visit_date']) > time()) {
        $errors['visit_date'] = 'The visit date cannot be in the future.';
    }
    if ($errors) {
        flash('error', implode(' ', $errors));
        redirect('/staff/applications/' . $id . '#field');
    }
    $lat = is_numeric($d['gps_lat'] ?? null) ? (float)$d['gps_lat'] : null;
    $lng = is_numeric($d['gps_lng'] ?? null) ? (float)$d['gps_lng'] : null;
    DB::tx(function () use ($a, $d, $lat, $lng) {
        $vid = DB::insert('field_visits', ['application_id' => $a['id'], 'officer_id' => Auth::id(), 'visit_date' => $d['visit_date'], 'gps_lat' => $lat, 'gps_lng' => $lng,
            'household_observation' => trim($d['household_observation']), 'findings' => trim($d['findings']), 'outcome' => $d['outcome']]);
        $n = DB::run("UPDATE documents d JOIN document_types t ON t.id = d.document_type_id SET d.field_visit_id = ? WHERE d.application_id = ? AND t.code = 'homestead_photo' AND d.field_visit_id IS NULL AND d.uploaded_by = ?",
            [$vid, $a['id'], Auth::id()])->rowCount();
        Workflow::event((int)$a['id'], 'verification', 'field_visit_recorded', 'Outcome: ' . $d['outcome'] . ", $n photo(s)");
        Audit::log('workflow', 'field_visit_recorded', 'application', $a['id'], ['visit' => $vid, 'outcome' => $d['outcome'], 'photos' => $n, 'gps' => $lat ? 'yes' : 'no']);
        if ($d['outcome'] === 'not_confirmed') {
            Risk::flag((int)$a['id'], 'FIELD_NOT_CONFIRMED', 'high', 'Field visit could not confirm the household details.');
        }
    });
    flash('success', 'Field visit recorded.');
    redirect('/staff/applications/' . $id . '#field');
}

function staff_committeeReview(string $id): void
{
    $a = staff_case((int)$id);
    Workflow::assertCan($a, 'committee');
    $decision = (string)input('decision');
    $comment = trim((string)input('comment', ''));
    $score = input_int('need_score');
    $amount = input_money('recommended_amount');
    if (!in_array($decision, ['recommend', 'return', 'not_recommend'], true) || mb_strlen($comment) < 10) {
        flash('error', 'Choose a decision and give the committee’s reasons (at least 10 characters).');
        redirect('/staff/applications/' . $id);
    }
    if ($score !== null && ($score < 1 || $score > 10)) {
        $score = null;
    }
    if ($decision === 'recommend') {
        $rule = DB::one('SELECT * FROM cycle_levels WHERE cycle_id = ? AND level = ?', [$a['cycle_id'], $a['level']]);
        if ($amount === null || $amount <= 0 || ($rule && $amount > (float)$rule['max_amount'])) {
            flash('error', 'Enter a recommended amount above zero' . ($rule ? ' and not more than ' . money($rule['max_amount']) . ' for this level' : '') . '.');
            redirect('/staff/applications/' . $id);
        }
    }
    DB::tx(function () use ($a, $decision, $comment, $score, $amount) {
        DB::insert('committee_reviews', ['application_id' => $a['id'], 'member_id' => Auth::id(), 'decision' => $decision,
            'recommended_amount' => $decision === 'recommend' ? $amount : null, 'need_score' => $score, 'comment' => $comment]);
        match ($decision) {
            'recommend' => Workflow::move($a, 'committee', 'recommended', 'recommended', null, ['amount_recommended' => $amount], false),
            'not_recommend' => Workflow::move($a, 'committee', 'not_recommended', 'recommended', null, ['amount_recommended' => 0], false),
            'return' => Workflow::move($a, 'committee', 'returned_for_clarification', 'returned', $comment, ['return_reason' => $comment]),
        };
    });
    flash('success', $decision === 'return' ? 'Returned to the applicant for clarification.' : 'Committee decision recorded. It now needs an authorised approver.');
    redirect('/staff/committee');
}

function staff_budget_left(array $a): ?float
{
    $budget = DB::val('SELECT amount FROM cycle_ward_budgets WHERE cycle_id = ? AND ward_id = ?', [$a['cycle_id'], $a['ward_id']]);
    if ($budget === null) {
        return null;
    }
    $used = (float)DB::val("SELECT COALESCE(SUM(a.amount_approved),0) FROM applications a JOIN students s ON s.id = a.student_id WHERE a.cycle_id = ? AND s.ward_id = ? AND a.id <> ?
        AND a.status IN ('approved','partially_approved','ready_for_payment','payment_processing','payment_failed','disbursed','closed')", [$a['cycle_id'], $a['ward_id'], $a['id']]);
    return (float)$budget - $used;
}

function staff_approve(string $id): void
{
    $u = staff_user();
    $a = staff_case((int)$id);
    Workflow::assertCan($a, 'approval');
    if ($a['status'] !== 'recommended') {
        abort(409, 'Only applications recommended by the committee can be decided.');
    }
    $decision = (string)input('decision');
    $comment = trim((string)input('comment', ''));
    $amount = input_money('amount');
    if ($decision === 'not_approved') {
        if (mb_strlen($comment) < 10) {
            flash('error', 'Give the reason for not approving (the applicant will see it).');
            redirect('/staff/applications/' . $id);
        }
        DB::tx(function () use ($a, $comment) {
            DB::insert('approvals', ['application_id' => $a['id'], 'approver_id' => Auth::id(), 'decision' => 'not_approved', 'amount' => 0, 'comment' => $comment]);
            Workflow::move($a, 'approval', 'not_approved', 'not_approved', $comment, ['amount_approved' => 0, 'decided_at' => now()]);
        });
        flash('success', 'Decision recorded and the applicant notified.');
        redirect('/staff/committee?view=recommended');
    }
    if ($decision !== 'approve' || $amount === null || $amount <= 0) {
        flash('error', 'Enter the amount to approve.');
        redirect('/staff/applications/' . $id);
    }
    if ((float)$a['amount_recommended'] <= 0) {
        flash('error', 'The committee did not recommend this application. It cannot be approved without a new committee review.');
        redirect('/staff/applications/' . $id);
    }
    if ($amount > (float)$a['amount_recommended']) {
        flash('error', 'You cannot approve more than the committee recommended (' . money($a['amount_recommended']) . ').');
        redirect('/staff/applications/' . $id);
    }
    if ($u['approval_limit'] === null || $amount > (float)$u['approval_limit']) {
        Audit::log('access', 'approval_limit_block', 'application', $id, ['amount' => $amount, 'limit' => $u['approval_limit']]);
        flash('error', 'This is above your approval limit (' . money($u['approval_limit']) . '). An approver with a higher limit must decide it.');
        redirect('/staff/applications/' . $id);
    }
    $left = staff_budget_left($a);
    if ($left === null) {
        flash('error', 'No budget is set for ' . $a['ward_name'] . ' ward in this cycle. Ask the administrator to set it.');
        redirect('/staff/applications/' . $id);
    }
    if ($amount > $left) {
        flash('error', 'Not enough ward budget left. Remaining: ' . money($left) . '.');
        redirect('/staff/applications/' . $id);
    }
    $status = $amount < (float)$a['amount_requested'] ? 'partially_approved' : 'approved';
    DB::tx(function () use ($a, $amount, $status, $comment) {
        DB::insert('approvals', ['application_id' => $a['id'], 'approver_id' => Auth::id(), 'decision' => $status, 'amount' => $amount, 'comment' => $comment ?: null]);
        Workflow::move($a, 'approval', $status, $status, $comment ?: null, ['amount_approved' => $amount, 'decided_at' => now()]);
    });
    flash('success', status_label($status) . ' for ' . money($amount) . '. The applicant was notified and can download the award letter.');
    redirect('/staff/committee?view=recommended');
}

function staff_amend(string $id): void
{
    $a = staff_case((int)$id);
    Workflow::assertCan($a, 'approval');
    if (!in_array($a['status'], ['approved', 'partially_approved'], true)) {
        abort(409, 'Amounts can only be amended before the application is queued for payment.');
    }
    $new = input_money('new_amount');
    $reason = trim((string)input('reason', ''));
    if ($new === null || $new < 0 || $new > (float)$a['amount_recommended'] || mb_strlen($reason) < 15) {
        flash('error', 'Enter a new amount (not above the committee recommendation) and a full reason (at least 15 characters).');
        redirect('/staff/applications/' . $id);
    }
    if (DB::val("SELECT 1 FROM amendments WHERE application_id = ? AND status = 'pending'", [$id])) {
        flash('error', 'An amendment is already waiting for review.');
        redirect('/staff/applications/' . $id);
    }
    DB::tx(function () use ($a, $new, $reason) {
        $mid = DB::insert('amendments', ['application_id' => $a['id'], 'requested_by' => Auth::id(), 'old_amount' => $a['amount_approved'], 'new_amount' => $new, 'reason' => $reason]);
        Workflow::event((int)$a['id'], 'approval', 'amendment_requested', 'From ' . money($a['amount_approved']) . ' to ' . money($new) . ': ' . $reason);
        Audit::log('workflow', 'amendment_requested', 'amendment', $mid, ['application_id' => $a['id'], 'old' => $a['amount_approved'], 'new' => $new]);
    });
    flash('success', 'Amendment requested. A different approver must confirm it before it takes effect.');
    redirect('/staff/applications/' . $id);
}

function staff_reviewAmendment(string $mid): void
{
    $u = staff_user();
    $m = DB::one("SELECT * FROM amendments WHERE id = ? AND status = 'pending'", [(int)$mid]) ?? abort(404);
    $a = staff_case((int)$m['application_id']);
    Workflow::assertCan($a, 'approval');
    if ((int)$m['requested_by'] === (int)$u['id']) {
        abort(403, 'Maker-checker: you cannot confirm an amendment you requested.');
    }
    if (!in_array($a['status'], ['approved', 'partially_approved'], true)) {
        abort(409, 'The application has moved on; the amendment can no longer be applied.');
    }
    $decision = input('decision') === 'confirm' ? 'confirmed' : 'rejected';
    $note = mb_substr(trim((string)input('note', '')), 0, 255);
    if ($decision === 'confirmed') {
        $new = (float)$m['new_amount'];
        if ($new > 0 && ($u['approval_limit'] === null || $new > (float)$u['approval_limit'])) {
            abort(403, 'The new amount is above your approval limit.');
        }
        $left = staff_budget_left($a);
        if ($left !== null && $new > $left) {
            abort(409, 'Not enough ward budget left for this amendment (' . money($left) . ').');
        }
    }
    DB::tx(function () use ($m, $a, $decision, $note) {
        DB::update('amendments', ['status' => $decision, 'reviewed_by' => Auth::id(), 'review_note' => $note ?: null, 'reviewed_at' => now()], 'id = ?', [$m['id']]);
        if ($decision === 'confirmed') {
            $new = (float)$m['new_amount'];
            $status = $new <= 0 ? 'not_approved' : ($new < (float)$a['amount_requested'] ? 'partially_approved' : 'approved');
            DB::run("UPDATE issued_documents SET revoked_at = NOW(), revoked_reason = 'Award amount amended' WHERE application_id = ? AND kind = 'award_letter' AND revoked_at IS NULL", [$a['id']]);
            Workflow::move($a, 'approval', 'amendment_confirmed', $status, 'Approved amount changed from ' . money($m['old_amount']) . ' to ' . money($new) . '.', ['amount_approved' => $new]);
        } else {
            Workflow::event((int)$a['id'], 'approval', 'amendment_rejected', $note ?: null);
            Audit::log('workflow', 'amendment_rejected', 'amendment', $m['id']);
        }
    });
    flash('success', 'Amendment ' . $decision . '.');
    redirect('/staff/applications/' . $a['id']);
}

function staff_resolveFlag(string $id, string $flag): void
{
    $a = staff_case((int)$id);
    $duty = null;
    foreach (['doc_check', 'verification', 'audit_sample'] as $try) {
        if (array_intersect(Workflow::DUTIES[$try][0], Auth::roles()) && Workflow::blockReason($a, $try) === null) {
            $duty = $try;
            break;
        }
    }
    if (!$duty) {
        abort(403, 'Only the document officer, verifying officer or an auditor currently handling this application can resolve its flags.');
    }
    $f = DB::one("SELECT * FROM risk_flags WHERE id = ? AND application_id = ? AND status = 'open'", [(int)$flag, (int)$id]) ?? abort(404);
    $status = input('status') === 'confirmed' ? 'confirmed' : 'cleared';
    $note = mb_substr(trim((string)input('note', '')), 0, 500);
    if (mb_strlen($note) < 10) {
        flash('error', 'Explain how you checked this flag (at least 10 characters).');
        redirect('/staff/applications/' . $id . '#flags');
    }
    DB::tx(function () use ($f, $a, $status, $note, $duty) {
        DB::update('risk_flags', ['status' => $status, 'resolved_by' => Auth::id(), 'resolution_note' => $note, 'resolved_at' => now()], 'id = ?', [$f['id']]);
        Workflow::event((int)$a['id'], $duty, 'flag_' . $status, $f['code'] . ': ' . $note);
        Audit::log('workflow', 'risk_flag_' . $status, 'risk_flag', $f['id'], ['application_id' => $a['id'], 'code' => $f['code']]);
    });
    flash('success', 'Flag ' . $status . '.');
    redirect('/staff/applications/' . $id . '#flags');
}

function staff_auditSample(string $id): void
{
    $a = staff_case((int)$id);
    Workflow::assertCan($a, 'audit_sample');
    $outcome = input('outcome') === 'issues' ? 'issues' : 'no_issues';
    $note = trim((string)input('note', ''));
    if (mb_strlen($note) < 10) {
        flash('error', 'Record what you re-checked (at least 10 characters).');
        redirect('/staff/applications/' . $id);
    }
    DB::tx(function () use ($a, $outcome, $note) {
        Workflow::event((int)$a['id'], 'audit_sample', 'secondary_audit_done', ($outcome === 'issues' ? 'Issues found: ' : 'No issues: ') . $note);
        Audit::log('workflow', 'secondary_audit', 'application', $a['id'], ['outcome' => $outcome]);
        if ($outcome === 'issues') {
            Risk::flag((int)$a['id'], 'AUDIT_FINDING', 'high', 'Secondary audit: ' . $note);
        }
    });
    flash('success', 'Secondary audit recorded.');
    redirect('/staff/queue/audit_sample');
}
