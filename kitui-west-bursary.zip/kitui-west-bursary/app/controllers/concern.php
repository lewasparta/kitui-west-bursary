<?php
declare(strict_types=1);

const CONCERN_CATEGORIES = [
    'bribery' => 'Bribery or request for money', 'fraud' => 'Fraud', 'forged_documents' => 'Forged documents',
    'favoritism' => 'Favouritism', 'false_beneficiary' => 'False or ghost beneficiary', 'payment_irregularity' => 'Payment irregularity',
    'officer_misconduct' => 'Officer misconduct', 'conflict_of_interest' => 'Conflict of interest', 'other' => 'Something else',
];

function concern_form(): void
{
    render('concern/form', ['title' => 'Report a concern', 'errors' => [], 'wards' => DB::all('SELECT id, name FROM wards WHERE is_active = 1 ORDER BY name')], 'public');
}

function concern_submit(): void
{
    rate_limit('concern', 5, 3600);
    $d = $_POST;
    $anon = empty($d['identify']);
    $rules = ['category' => 'required|in:' . implode(',', array_keys(CONCERN_CATEGORIES)), 'description' => 'required|min:20|max:5000', 'related_reference' => 'max:40'];
    if (!$anon) {
        $rules += ['reporter_name' => 'required|max:120', 'reporter_phone' => 'required|phone'];
    }
    $errors = validate($d, $rules, ['description' => 'What happened', 'reporter_name' => 'Your name', 'reporter_phone' => 'Your phone', 'related_reference' => 'Related reference']);
    $ward = input_int('ward_id');
    if ($ward && !DB::val('SELECT 1 FROM wards WHERE id = ?', [$ward])) {
        $ward = null;
    }
    if ($errors) {
        keep_old();
        render('concern/form', ['title' => 'Report a concern', 'errors' => $errors, 'wards' => DB::all('SELECT id, name FROM wards WHERE is_active = 1 ORDER BY name')], 'public');
    }
    $pin = (string)random_int(100000, 999999);
    $ref = DB::tx(function () use ($d, $anon, $ward, $pin) {
        $year = (int)date('Y');
        $ref = sprintf('KWC-%d-%05d', $year, next_sequence('concern', $year));
        $id = DB::insert('complaints', [
            'reference' => $ref, 'pin_hash' => password_hash($pin, PASSWORD_DEFAULT), 'category' => $d['category'],
            'description' => trim($d['description']), 'is_anonymous' => $anon ? 1 : 0,
            'reporter_name' => $anon ? null : trim($d['reporter_name']), 'reporter_phone' => $anon ? null : normalize_phone($d['reporter_phone']),
            'related_reference' => strtoupper(trim((string)($d['related_reference'] ?? ''))) ?: null, 'ward_id' => $ward,
        ]);
        // Deliberately no IP or user id stored with an anonymous report.
        Audit::log('data', 'concern_received', 'complaint', $id, ['category' => $d['category'], 'anonymous' => $anon ? 'yes' : 'no'], null);
        return $ref;
    });
    if (!$anon) {
        Sms::template('concern', $d['reporter_phone'], ['ref' => $ref]);
    }
    clear_old();
    render('concern/received', ['title' => 'Concern received', 'ref' => $ref, 'pin' => $pin], 'public');
}

function concern_track(): void
{
    render('concern/track', ['title' => 'Track a concern', 'c' => null, 'updates' => [], 'error' => null], 'public');
}

function concern_trackPost(): void
{
    rate_limit('concern_track', 10, 900);
    $ref = strtoupper(trim((string)input('reference')));
    $c = DB::one('SELECT * FROM complaints WHERE reference = ?', [$ref]);
    if (!$c || !password_verify((string)input('pin'), $c['pin_hash'])) {
        render('concern/track', ['title' => 'Track a concern', 'c' => null, 'updates' => [], 'error' => 'The reference and PIN did not match.'], 'public');
    }
    $updates = DB::all('SELECT note, created_at FROM complaint_updates WHERE complaint_id = ? AND is_public = 1 ORDER BY id', [$c['id']]);
    render('concern/track', ['title' => 'Track a concern', 'c' => $c, 'updates' => $updates, 'error' => null], 'public');
}
