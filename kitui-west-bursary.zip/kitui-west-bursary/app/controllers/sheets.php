<?php
declare(strict_types=1);

/*
 * Sealed official sheets. The content is fixed by the system: nothing on a sheet is typed by the
 * holder, and the verification code + QR let anyone compare the paper with the official record.
 */

function sheets_words(int $n): string
{
    $ones = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
    $tens = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
    if ($n === 0) {
        return 'zero';
    }
    $f = function (int $n) use (&$f, $ones, $tens): string {
        if ($n < 20) { return $ones[$n]; }
        if ($n < 100) { return $tens[intdiv($n, 10)] . ($n % 10 ? '-' . $ones[$n % 10] : ''); }
        if ($n < 1000) { return $ones[intdiv($n, 100)] . ' hundred' . ($n % 100 ? ' and ' . $f($n % 100) : ''); }
        if ($n < 1000000) { return $f(intdiv($n, 1000)) . ' thousand' . ($n % 1000 ? ($n % 1000 < 100 ? ' and ' : ' ') . $f($n % 1000) : ''); }
        return $f(intdiv($n, 1000000)) . ' million' . ($n % 1000000 ? ' ' . $f($n % 1000000) : '');
    };
    return $f($n);
}

function sheets_access(array $a): void
{
    $u = Auth::require();
    if ($u['account_type'] === 'staff') {
        if (!Auth::has('doc_officer', 'ward_officer', 'committee', 'approver', 'finance', 'auditor')) {
            abort(403);
        }
        return;
    }
    $linked = DB::val('SELECT 1 FROM students WHERE id = ? AND user_id = ?', [$a['student_id'], $u['id']]);
    if ((int)$a['applicant_user_id'] !== (int)$u['id'] && !$linked) {
        abort(404);
    }
}

function sheets_show(string $kind, string $id): void
{
    if (!isset(Seal::KINDS[$kind])) {
        abort(404);
    }
    $a = Workflow::app((int)$id);
    sheets_access($a);
    $student = trim($a['first_name'] . ' ' . ($a['middle_name'] ? $a['middle_name'] . ' ' : '') . $a['last_name']);
    $rows = [];
    $body = [];

    switch ($kind) {
        case 'application_receipt':
            if (!$a['reference']) {
                flash('info', 'The receipt is issued once the application is submitted.');
                redirect('/portal/applications/' . $id);
            }
            $public = [
                'Reference' => $a['reference'], 'Student' => $student, 'Institution' => $a['institution_name'],
                'Level / class' => level_label($a['level']) . ', ' . $a['class_year'], 'Ward' => $a['ward_name'],
                'Amount requested' => money($a['amount_requested']), 'Submitted on' => fmt_date($a['submitted_at'], 'j M Y, g:ia'),
                'Applicant phone' => mask_phone($a['applicant_phone']),
            ];
            $body = ['intro' => 'This confirms that the bursary application below was received through the Kitui West Digital Bursary system. Keep this receipt. It does not mean the application has been approved.'];
            break;

        case 'recommendation_form':
            if (!$a['guardian_id'] || !$a['student_id'] || !$a['institution_id'] || !$a['household_size']) {
                flash('error', 'Complete the applicant, student, education and household steps first.');
                redirect('/portal/applications/' . $id . '/step/5');
            }
            $public = [
                'Application no.' => 'KWB-APP-' . str_pad((string)$a['id'], 6, '0', STR_PAD_LEFT), 'Student' => $student, 'Date of birth' => fmt_date($a['date_of_birth']),
                'Home' => $a['village'] . ', ' . $a['sub_location'] . ', ' . $a['ward_name'] . ' Ward',
                'Parent / guardian' => $a['guardian_name'] . ' (' . ucfirst((string)$a['guardian_relationship']) . ')',
                'Guardian ID (last 3)' => '*****' . substr((string)$a['guardian_nid'], -3),
                'Institution' => $a['institution_name'] . ' — ' . $a['class_year'],
                'Declared family status' => ucfirst(str_replace('_', ' ', (string)$a['parental_status'])),
            ];
            $body = ['intro' => 'To the Chief / Assistant Chief: please confirm that the student below is a resident of your area and comment on the family’s need. This form was printed from the bursary system and can only be used for this student. A hand-written or re-typed copy is not accepted.', 'chief' => true];
            break;

        case 'award_letter':
            if (!in_array($a['status'], ['approved', 'partially_approved', 'ready_for_payment', 'payment_processing', 'payment_failed', 'disbursed', 'closed'], true) || (float)$a['amount_approved'] <= 0) {
                abort(404, 'An award letter is issued only for approved applications.');
            }
            $amt = (int)round((float)$a['amount_approved']);
            $public = [
                'Reference' => $a['reference'], 'Student' => $student, 'Institution' => $a['institution_name'],
                'Admission no.' => $a['admission_no'], 'Cycle' => $a['cycle_name'], 'Amount awarded' => money($amt),
                'In words' => ucfirst(sheets_words($amt)) . ' shillings only', 'Decision date' => fmt_date($a['decided_at']),
            ];
            $body = ['intro' => 'We are pleased to inform you that the Kitui West Bursary Committee has awarded the bursary below. The amount will be paid directly to the institution’s bank account; no cash is paid to any person. This letter cannot be exchanged for money.',
                'to' => 'The Principal / Registrar, ' . $a['institution_name']];
            break;

        case 'support_statement':
            $rows = DB::all("SELECT a.reference, c.name AS cycle_name, i.name AS institution_name, p.amount, p.paid_on, p.payment_reference
                FROM payments p JOIN applications a ON a.id = p.application_id JOIN application_cycles c ON c.id = a.cycle_id JOIN institutions i ON i.id = p.institution_id
                WHERE a.student_id = ? AND p.status = 'paid' ORDER BY p.paid_on, p.id", [$a['student_id']]);
            if (!$rows) {
                abort(404, 'A support statement is available after the first payment.');
            }
            $total = array_sum(array_map(fn($r) => (float)$r['amount'], $rows));
            $public = ['Student' => $student, 'Payments' => (string)count($rows), 'Total paid' => money($total),
                'Last payment ref.' => end($rows)['payment_reference'], 'Up to' => fmt_date(end($rows)['paid_on'])];
            $rows = array_map(fn($r) => [$r['cycle_name'], $r['reference'], $r['institution_name'], fmt_date($r['paid_on']), $r['payment_reference'], money($r['amount'])], $rows);
            $body = ['intro' => 'Statement of bursary support paid by Kitui West Bursary on behalf of the student below. Every payment was made directly to the institution.'];
            break;
    }
    $payload = ['public' => $public, 'rows' => $rows];
    $doc = Seal::issue((int)$a['id'], $kind, $payload);
    Audit::log('report', 'sheet_viewed', 'issued_document', $doc['code'], ['kind' => $kind]);
    echo with_base(view('sheets/sheet', [
        'title' => Seal::KINDS[$kind], 'kind' => $kind, 'doc' => $doc, 'public' => $public, 'rows' => $rows, 'body' => $body, 'a' => $a,
        'verifyUrl' => abs_url('/verify') . '?code=' . rawurlencode($doc['code']),
    ], 'sheet'));
    exit;
}
