<?php
declare(strict_types=1);

/*
 * Approved -> Ready for payment -> Batch (draft) -> Authorised by a DIFFERENT officer (processing)
 * -> Paid (bank reference required) / Failed -> Reconciled by someone other than the recorder -> Closed.
 */

function finance_user(bool $allowAuditor = false): array
{
    $u = Auth::require();
    $ok = Auth::has('finance') || ($allowAuditor && Auth::has('auditor'));
    if (!$ok) {
        abort(403);
    }
    return $u;
}

function finance_index(): void
{
    $u = finance_user(true);
    $approved = DB::all("SELECT a.id, a.reference, a.status, a.amount_approved, a.version, a.applicant_user_id, s.first_name, s.last_name, s.ward_id, i.name AS institution_name, i.account_no,
            g.phone AS guardian_phone, g.national_id AS guardian_nid
        FROM applications a JOIN students s ON s.id = a.student_id JOIN institutions i ON i.id = a.institution_id LEFT JOIN guardians g ON g.id = a.guardian_id
        WHERE a.status IN ('approved','partially_approved') AND NOT EXISTS (SELECT 1 FROM amendments m WHERE m.application_id = a.id AND m.status = 'pending')
        ORDER BY a.decided_at LIMIT 300");
    $ready = DB::all("SELECT a.id, a.reference, a.amount_approved, s.first_name, s.last_name, i.name AS institution_name, i.account_no
        FROM applications a JOIN students s ON s.id = a.student_id JOIN institutions i ON i.id = a.institution_id
        WHERE a.status = 'ready_for_payment' AND NOT EXISTS (SELECT 1 FROM payments p WHERE p.application_id = a.id AND p.status IN ('queued','processing'))
        ORDER BY i.name LIMIT 300");
    $batches = DB::all("SELECT b.*, c.full_name AS creator, z.full_name AS authoriser, (SELECT COUNT(*) FROM payments p WHERE p.batch_id = b.id AND p.status <> 'removed') AS n,
            (SELECT COUNT(*) FROM payments p WHERE p.batch_id = b.id AND p.status = 'paid') AS paid_n
        FROM payment_batches b JOIN users c ON c.id = b.created_by LEFT JOIN users z ON z.id = b.authorized_by ORDER BY b.id DESC LIMIT 30");
    $unrec = DB::all("SELECT p.*, a.reference, i.name AS institution_name, r.full_name AS recorder FROM payments p JOIN applications a ON a.id = p.application_id JOIN institutions i ON i.id = p.institution_id
        JOIN users r ON r.id = p.recorded_by WHERE p.status = 'paid' AND p.reconciliation_status = 'unreconciled' ORDER BY p.paid_on LIMIT 100");
    foreach ($unrec as &$r) {
        $r['_block'] = (int)$r['recorded_by'] === (int)$u['id'] ? 'You recorded this payment, so another officer or an auditor must reconcile it.' : Workflow::blockReason(Workflow::app((int)$r['application_id']), 'reconcile');
    }
    unset($r);
    $failed = DB::all("SELECT p.*, a.reference, a.status AS app_status FROM payments p JOIN applications a ON a.id = p.application_id WHERE p.status = 'failed' AND a.status = 'payment_failed' ORDER BY p.id DESC LIMIT 100");
    render('finance/index', ['title' => 'Finance', 'u' => $u, 'approved' => $approved, 'ready' => $ready, 'batches' => $batches, 'unrec' => $unrec, 'failed' => $failed, 'isFinance' => Auth::has('finance')]);
}

/** Selected ids from a checkbox list, as integers. */
function finance_ids(): array
{
    $ids = $_POST['ids'] ?? [];
    return is_array($ids) ? array_values(array_unique(array_filter(array_map('intval', $ids)))) : [];
}

function finance_queue(): void
{
    finance_user();
    $ids = finance_ids();
    if (!$ids) {
        flash('error', 'Tick at least one approved application.');
        redirect('/finance');
    }
    $done = 0;
    $skipped = [];
    foreach ($ids as $id) {
        $a = Workflow::app($id);
        $why = Workflow::blockReason($a, 'payment_prep');
        if ($why !== null || !in_array($a['status'], ['approved', 'partially_approved'], true) || DB::val("SELECT 1 FROM amendments WHERE application_id = ? AND status = 'pending'", [$id])) {
            $skipped[] = $a['reference'] . ($why ? " ($why)" : '');
            continue;
        }
        Workflow::move($a, 'payment_prep', 'queued_for_payment', 'ready_for_payment', null, [], false);
        $done++;
    }
    flash($done ? 'success' : 'error', "$done application(s) marked ready for payment." . ($skipped ? ' Skipped: ' . implode('; ', $skipped) : ''));
    redirect('/finance');
}

function finance_createBatch(): void
{
    $u = finance_user();
    $ids = finance_ids();
    if (!$ids) {
        flash('error', 'Tick the applications to include in the batch.');
        redirect('/finance');
    }
    $cycle = null;
    $apps = [];
    foreach ($ids as $id) {
        $a = Workflow::app($id);
        $why = Workflow::blockReason($a, 'payment_prep');
        if ($why !== null || $a['status'] !== 'ready_for_payment') {
            abort(409, $a['reference'] . ': ' . ($why ?? 'not ready for payment'));
        }
        if (DB::val("SELECT 1 FROM payments WHERE application_id = ? AND status IN ('queued','processing')", [$id])) {
            abort(409, $a['reference'] . ' is already in a batch.');
        }
        $cycle ??= (int)$a['cycle_id'];
        $apps[] = $a;
    }
    $batchId = DB::tx(function () use ($apps, $cycle) {
        $year = (int)date('Y');
        $ref = sprintf('KWP-%d-%04d', $year, next_sequence('batch', $year));
        $bid = DB::insert('payment_batches', ['reference' => $ref, 'cycle_id' => $cycle, 'created_by' => Auth::id()]);
        $total = 0.0;
        foreach ($apps as $a) {
            $amt = (float)$a['amount_approved'] - (float)$a['amount_paid'];
            if ($amt <= 0) {
                throw new HttpException(409, $a['reference'] . ' has nothing left to pay.');
            }
            DB::insert('payments', ['batch_id' => $bid, 'application_id' => $a['id'], 'institution_id' => $a['institution_id'], 'amount' => $amt]);
            Workflow::event((int)$a['id'], 'payment_prep', 'added_to_batch', $ref);
            $total += $amt;
        }
        DB::run('UPDATE payment_batches SET total_amount = ? WHERE id = ?', [$total, $bid]);
        Audit::log('finance', 'batch_created', 'payment_batch', $bid, ['reference' => $ref, 'count' => count($apps), 'total' => $total]);
        return $bid;
    });
    flash('success', 'Batch created. A different finance officer must authorise it.');
    redirect('/finance/batches/' . $batchId);
}

function finance_batch(string $id): void
{
    $u = finance_user(true);
    $b = DB::one('SELECT b.*, c.full_name AS creator, z.full_name AS authoriser FROM payment_batches b JOIN users c ON c.id = b.created_by LEFT JOIN users z ON z.id = b.authorized_by WHERE b.id = ?', [(int)$id]) ?? abort(404);
    $rows = DB::all("SELECT p.*, a.reference, a.status AS app_status, s.first_name, s.last_name, i.name AS institution_name, i.bank_name, i.bank_branch, i.account_name, i.account_no, r.full_name AS recorder
        FROM payments p JOIN applications a ON a.id = p.application_id JOIN students s ON s.id = a.student_id JOIN institutions i ON i.id = p.institution_id LEFT JOIN users r ON r.id = p.recorded_by
        WHERE p.batch_id = ? AND p.status <> 'removed' ORDER BY i.name, s.last_name", [$b['id']]);
    foreach ($rows as &$r) {
        $r['_block'] = $r['status'] === 'processing' ? Workflow::blockReason(Workflow::app((int)$r['application_id']), 'payment_record') : null;
    }
    unset($r);
    Audit::log('access', 'batch_viewed', 'payment_batch', $b['id']);
    render('finance/batch', ['title' => 'Batch ' . $b['reference'], 'b' => $b, 'rows' => $rows, 'u' => $u, 'isFinance' => Auth::has('finance')]);
}

function finance_authorize(string $id): void
{
    $u = finance_user();
    $b = DB::one("SELECT * FROM payment_batches WHERE id = ? AND status = 'draft'", [(int)$id]) ?? abort(404);
    if ((int)$b['created_by'] === (int)$u['id']) {
        abort(403, 'Maker-checker: the officer who prepared a batch cannot authorise it.');
    }
    $pays = DB::all("SELECT * FROM payments WHERE batch_id = ? AND status = 'queued'", [$b['id']]);
    if (!$pays) {
        abort(409, 'The batch is empty.');
    }
    foreach ($pays as $p) {
        $a = Workflow::app((int)$p['application_id']);
        $why = Workflow::blockReason($a, 'payment_authorize');
        if ($why !== null) {
            abort(403, $a['reference'] . ': ' . $why);
        }
    }
    DB::tx(function () use ($b, $pays) {
        DB::run("UPDATE payment_batches SET status = 'processing', authorized_by = ?, authorized_at = NOW() WHERE id = ? AND status = 'draft'", [Auth::id(), $b['id']]);
        foreach ($pays as $p) {
            DB::run("UPDATE payments SET status = 'processing' WHERE id = ?", [$p['id']]);
            Workflow::move(Workflow::app((int)$p['application_id']), 'payment_authorize', 'payment_authorised', 'payment_processing', null, [], false);
        }
        Audit::log('finance', 'batch_authorised', 'payment_batch', $b['id'], ['reference' => $b['reference'], 'total' => $b['total_amount']]);
    });
    flash('success', 'Batch authorised. Send the payments through the bank, then record each bank reference here.');
    redirect('/finance/batches/' . $b['id']);
}

function finance_cancel(string $id): void
{
    finance_user();
    $b = DB::one("SELECT * FROM payment_batches WHERE id = ? AND status = 'draft'", [(int)$id]) ?? abort(404);
    DB::tx(function () use ($b) {
        foreach (DB::all("SELECT * FROM payments WHERE batch_id = ? AND status = 'queued'", [$b['id']]) as $p) {
            DB::run("UPDATE payments SET status = 'removed' WHERE id = ?", [$p['id']]);
            Workflow::event((int)$p['application_id'], 'payment_prep', 'removed_from_batch', $b['reference']);
        }
        DB::run("UPDATE payment_batches SET status = 'cancelled' WHERE id = ?", [$b['id']]);
        Audit::log('finance', 'batch_cancelled', 'payment_batch', $b['id'], ['reference' => $b['reference']]);
    });
    flash('success', 'Draft batch cancelled. Its applications are back in the ready-for-payment list.');
    redirect('/finance');
}

function finance_record(string $id): void
{
    finance_user();
    $p = DB::one("SELECT * FROM payments WHERE id = ? AND status = 'processing'", [(int)$id]) ?? abort(404);
    $a = Workflow::app((int)$p['application_id']);
    Workflow::assertCan($a, 'payment_record');
    $outcome = (string)input('outcome');
    if ($outcome === 'paid') {
        $ref = strtoupper(trim((string)input('payment_reference', '')));
        $date = (string)input('paid_on', '');
        $method = (string)input('payment_method', '');
        $errors = validate(['r' => $ref, 'd' => $date, 'm' => $method], ['r' => 'required|min:4|max:60', 'd' => 'required|date', 'm' => 'required|in:eft,cheque,rtgs'], ['r' => 'Bank payment reference', 'd' => 'Payment date', 'm' => 'Payment method']);
        if (!$errors && strtotime($date) > time()) {
            $errors['d'] = 'Payment date cannot be in the future.';
        }
        if (!$errors && DB::val("SELECT 1 FROM payments WHERE payment_reference = ? AND institution_id <> ?", [$ref, $p['institution_id']])) {
            $errors['r'] = 'This bank reference is already recorded for a different institution.';
        }
        if ($errors) {
            flash('error', implode(' ', $errors));
            redirect('/finance/batches/' . $p['batch_id']);
        }
        DB::tx(function () use ($p, $a, $ref, $date, $method) {
            DB::update('payments', ['status' => 'paid', 'payment_reference' => $ref, 'paid_on' => $date, 'payment_method' => $method, 'recorded_by' => Auth::id(), 'recorded_at' => now()], 'id = ?', [$p['id']]);
            Audit::log('finance', 'payment_recorded', 'payment', $p['id'], ['application_id' => $a['id'], 'amount' => $p['amount'], 'reference' => $ref]);
            Workflow::move($a, 'payment_record', 'payment_confirmed', 'disbursed', 'Paid to ' . $a['institution_name'] . ', ref ' . $ref, ['amount_paid' => round((float)$a['amount_paid'] + (float)$p['amount'], 2)]);
            finance_complete_batch((int)$p['batch_id']);
        });
        flash('success', 'Payment recorded and the family notified.');
    } elseif ($outcome === 'failed') {
        $reason = mb_substr(trim((string)input('failure_reason', '')), 0, 255);
        if (mb_strlen($reason) < 5) {
            flash('error', 'Give the reason the bank returned.');
            redirect('/finance/batches/' . $p['batch_id']);
        }
        DB::tx(function () use ($p, $a, $reason) {
            DB::update('payments', ['status' => 'failed', 'failure_reason' => $reason, 'recorded_by' => Auth::id(), 'recorded_at' => now()], 'id = ?', [$p['id']]);
            Audit::log('finance', 'payment_failed', 'payment', $p['id'], ['application_id' => $a['id'], 'reason' => $reason]);
            Workflow::move($a, 'payment_record', 'payment_failed', 'payment_failed', 'Payment could not be completed; it will be re-processed.', [], true);
            finance_complete_batch((int)$p['batch_id']);
        });
        flash('success', 'Failure recorded. Re-queue it from the Finance page once details are corrected.');
    } else {
        abort(422, 'Choose paid or failed.');
    }
    redirect('/finance/batches/' . $p['batch_id']);
}

function finance_complete_batch(int $batchId): void
{
    $open = (int)DB::val("SELECT COUNT(*) FROM payments WHERE batch_id = ? AND status IN ('queued','processing')", [$batchId]);
    if ($open === 0) {
        DB::run("UPDATE payment_batches SET status = 'completed' WHERE id = ? AND status = 'processing'", [$batchId]);
    }
}

function finance_requeue(string $id): void
{
    finance_user();
    $p = DB::one("SELECT * FROM payments WHERE id = ? AND status = 'failed'", [(int)$id]) ?? abort(404);
    $a = Workflow::app((int)$p['application_id']);
    Workflow::assertCan($a, 'payment_prep');
    if ($a['status'] !== 'payment_failed') {
        abort(409, 'Already re-queued.');
    }
    Workflow::move($a, 'payment_prep', 'requeued_for_payment', 'ready_for_payment', 'Re-queued after failed payment', [], false);
    flash('success', $a['reference'] . ' is back in the ready-for-payment list.');
    redirect('/finance');
}

function finance_reconcile(string $id): void
{
    $u = finance_user(true);
    $p = DB::one("SELECT * FROM payments WHERE id = ? AND status = 'paid' AND reconciliation_status = 'unreconciled'", [(int)$id]) ?? abort(404);
    if ((int)$p['recorded_by'] === (int)$u['id']) {
        abort(403, 'The officer who recorded a payment cannot reconcile it.');
    }
    $a = Workflow::app((int)$p['application_id']);
    Workflow::assertCan($a, 'reconcile');
    $status = input('result') === 'discrepancy' ? 'discrepancy' : 'reconciled';
    $note = mb_substr(trim((string)input('note', '')), 0, 255);
    if ($status === 'discrepancy' && mb_strlen($note) < 10) {
        flash('error', 'Describe the discrepancy.');
        back('/finance');
    }
    DB::tx(function () use ($p, $a, $status, $note) {
        DB::update('payments', ['reconciliation_status' => $status, 'reconciled_by' => Auth::id(), 'reconciled_at' => now(), 'reconciliation_note' => $note ?: null], 'id = ?', [$p['id']]);
        Audit::log('finance', 'payment_' . $status, 'payment', $p['id'], ['application_id' => $a['id'], 'note' => $note]);
        if ($status === 'reconciled') {
            Workflow::move($a, 'reconcile', 'reconciled', 'closed', null, [], false);
        } else {
            Workflow::event((int)$a['id'], 'reconcile', 'reconciliation_discrepancy', $note);
            Risk::flag((int)$a['id'], 'PAYMENT_DISCREPANCY', 'high', 'Reconciliation: ' . $note);
        }
    });
    flash('success', 'Payment ' . $status . '.');
    back('/finance');
}
