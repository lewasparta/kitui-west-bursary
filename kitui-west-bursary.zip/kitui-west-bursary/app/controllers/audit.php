<?php
declare(strict_types=1);

function audit_user(): array
{
    return Auth::require('auditor');
}

function audit_index(): void
{
    audit_user();
    [$ok, $checked, $broken] = Audit::verify();
    Audit::log('security', 'audit_chain_verified', 'audit_logs', null, ['ok' => $ok ? 'yes' : 'no', 'rows' => $checked]);
    $counts = [
        'flags' => (int)DB::val("SELECT COUNT(*) FROM risk_flags WHERE status = 'open' AND severity = 'high'"),
        'concerns' => (int)DB::val("SELECT COUNT(*) FROM complaints WHERE status IN ('received','under_review','investigating')"),
        'unrec' => (int)DB::val("SELECT COUNT(*) FROM payments WHERE status = 'paid' AND reconciliation_status = 'unreconciled'"),
        'discrepancy' => (int)DB::val("SELECT COUNT(*) FROM payments WHERE reconciliation_status = 'discrepancy'"),
        'sod' => (int)DB::val("SELECT COUNT(*) FROM audit_logs WHERE action IN ('sod_block','approval_limit_block','household_conflict_block') AND created_at > NOW() - INTERVAL 30 DAY"),
        'samples' => (int)DB::val("SELECT COUNT(*) FROM applications a WHERE a.secondary_audit = 1 AND a.status NOT IN ('draft','withdrawn','submitted','returned') AND NOT EXISTS (SELECT 1 FROM application_events e WHERE e.application_id = a.id AND e.action = 'secondary_audit_done')"),
        'seal' => (int)DB::val("SELECT COUNT(*) FROM audit_logs WHERE action = 'seal_mismatch'"),
    ];
    $security = DB::all("SELECT l.*, u.full_name FROM audit_logs l LEFT JOIN users u ON u.id = l.user_id WHERE l.category IN ('security','access') AND l.action NOT IN ('login','logout','application_viewed','document_viewed','batch_viewed','staff_search','audit_chain_verified')
        ORDER BY l.id DESC LIMIT 15");
    $flags = DB::all("SELECT f.*, a.reference FROM risk_flags f JOIN applications a ON a.id = f.application_id WHERE f.status = 'open' ORDER BY FIELD(f.severity,'high','medium','low'), f.id LIMIT 20");
    render('audit/index', ['title' => 'Audit', 'ok' => $ok, 'checked' => $checked, 'broken' => $broken, 'counts' => $counts, 'security' => $security, 'flags' => $flags]);
}

function audit_logs(): void
{
    Auth::require('auditor', 'admin'); // read-only; nobody can edit or delete log rows (database triggers)
    $where = ['1=1'];
    $params = [];
    if ($c = input('category')) { $where[] = 'l.category = ?'; $params[] = $c; }
    if ($act = input('action')) { $where[] = 'l.action = ?'; $params[] = $act; }
    if ($et = input('entity_type')) { $where[] = 'l.entity_type = ?'; $params[] = $et; }
    if (($eid = input('entity_id')) !== null && $eid !== '') { $where[] = 'l.entity_id = ?'; $params[] = $eid; }
    if ($uid = input_int('user')) { $where[] = 'l.user_id = ?'; $params[] = $uid; }
    if ($from = input('from')) { $where[] = 'l.created_at >= ?'; $params[] = $from . ' 00:00:00'; }
    if ($to = input('to')) { $where[] = 'l.created_at <= ?'; $params[] = $to . ' 23:59:59'; }
    $w = implode(' AND ', $where);
    $p = paginate("SELECT COUNT(*) FROM audit_logs l WHERE $w", "SELECT l.*, u.full_name FROM audit_logs l LEFT JOIN users u ON u.id = l.user_id WHERE $w ORDER BY l.id DESC", $params, 50);
    render('audit/logs', ['title' => 'Audit trail', 'p' => $p, 'users' => DB::all("SELECT id, full_name FROM users WHERE account_type = 'staff' ORDER BY full_name")]);
}

function audit_application(string $id): void
{
    audit_user();
    $a = Workflow::app((int)$id);
    Audit::log('access', 'application_reconstructed', 'application', $id);
    $docIds = array_column(DB::all('SELECT id FROM documents WHERE application_id = ?', [$id]), 'id');
    $docLogs = [];
    if ($docIds) {
        $ph = implode(',', array_fill(0, count($docIds), '?'));
        $docLogs = DB::all("SELECT l.*, u.full_name FROM audit_logs l LEFT JOIN users u ON u.id = l.user_id WHERE l.entity_type = 'document' AND l.entity_id IN ($ph) ORDER BY l.id", array_map('strval', $docIds));
    }
    render('audit/application', [
        'title' => 'Reconstruction ' . $a['reference'], 'a' => $a,
        'events' => Workflow::history((int)$id),
        'logs' => DB::all("SELECT l.*, u.full_name FROM audit_logs l LEFT JOIN users u ON u.id = l.user_id WHERE l.entity_type = 'application' AND l.entity_id = ? ORDER BY l.id", [(string)$id]),
        'docLogs' => $docLogs,
        'docs' => DB::all('SELECT d.*, t.name AS type_name, up.full_name AS uploader, v.full_name AS verifier FROM documents d JOIN document_types t ON t.id = d.document_type_id JOIN users up ON up.id = d.uploaded_by LEFT JOIN users v ON v.id = d.verified_by WHERE d.application_id = ? ORDER BY d.id', [$id]),
        'coi' => DB::all('SELECT c.*, u.full_name FROM coi_declarations c JOIN users u ON u.id = c.user_id WHERE c.application_id = ? ORDER BY c.id', [$id]),
        'visits' => DB::all('SELECT v.*, u.full_name AS officer FROM field_visits v JOIN users u ON u.id = v.officer_id WHERE v.application_id = ?', [$id]),
        'reviews' => DB::all('SELECT r.*, u.full_name FROM committee_reviews r JOIN users u ON u.id = r.member_id WHERE r.application_id = ?', [$id]),
        'approvals' => DB::all('SELECT p.*, u.full_name FROM approvals p JOIN users u ON u.id = p.approver_id WHERE p.application_id = ?', [$id]),
        'amendments' => DB::all('SELECT m.*, r.full_name AS requester, v.full_name AS reviewer FROM amendments m JOIN users r ON r.id = m.requested_by LEFT JOIN users v ON v.id = m.reviewed_by WHERE m.application_id = ?', [$id]),
        'payments' => DB::all('SELECT p.*, b.reference AS batch_ref, c.full_name AS preparer, z.full_name AS authoriser, r.full_name AS recorder, q.full_name AS reconciler FROM payments p JOIN payment_batches b ON b.id = p.batch_id
            JOIN users c ON c.id = b.created_by LEFT JOIN users z ON z.id = b.authorized_by LEFT JOIN users r ON r.id = p.recorded_by LEFT JOIN users q ON q.id = p.reconciled_by WHERE p.application_id = ?', [$id]),
        'sheets' => DB::all('SELECT * FROM issued_documents WHERE application_id = ? ORDER BY id', [$id]),
        'sms' => DB::all('SELECT * FROM sms_messages WHERE application_id = ? ORDER BY id', [$id]),
        'flags' => DB::all('SELECT f.*, u.full_name AS resolver FROM risk_flags f LEFT JOIN users u ON u.id = f.resolved_by WHERE f.application_id = ?', [$id]),
    ]);
}

function audit_concerns(): void
{
    audit_user();
    $status = input('status');
    $where = $status ? 'c.status = ?' : '1=1';
    $params = $status ? [$status] : [];
    $p = paginate("SELECT COUNT(*) FROM complaints c WHERE $where", "SELECT c.*, w.name AS ward_name, u.full_name AS assignee FROM complaints c LEFT JOIN wards w ON w.id = c.ward_id LEFT JOIN users u ON u.id = c.assigned_to WHERE $where ORDER BY c.id DESC", $params);
    render('audit/concerns', ['title' => 'Concerns', 'p' => $p, 'status' => $status]);
}

function audit_concern(string $id): void
{
    audit_user();
    $c = DB::one('SELECT c.*, w.name AS ward_name FROM complaints c LEFT JOIN wards w ON w.id = c.ward_id WHERE c.id = ?', [(int)$id]) ?? abort(404);
    Audit::log('access', 'concern_viewed', 'complaint', $c['id']);
    $related = $c['related_reference'] ? DB::one('SELECT id, reference FROM applications WHERE reference = ?', [$c['related_reference']]) : null;
    render('audit/concern', ['title' => $c['reference'], 'c' => $c, 'related' => $related,
        'updates' => DB::all('SELECT cu.*, u.full_name FROM complaint_updates cu LEFT JOIN users u ON u.id = cu.user_id WHERE cu.complaint_id = ? ORDER BY cu.id', [$c['id']]),
        'auditors' => DB::all("SELECT u.id, u.full_name FROM users u JOIN user_roles ur ON ur.user_id = u.id JOIN roles r ON r.id = ur.role_id WHERE r.slug = 'auditor' AND u.is_active = 1 ORDER BY u.full_name")]);
}

function audit_updateConcern(string $id): void
{
    audit_user();
    $c = DB::one('SELECT * FROM complaints WHERE id = ?', [(int)$id]) ?? abort(404);
    $status = (string)input('status');
    $note = trim((string)input('note', ''));
    if (!in_array($status, ['received', 'under_review', 'investigating', 'resolved', 'closed'], true) || mb_strlen($note) < 5) {
        flash('error', 'Choose a status and write a note.');
        redirect('/audit/concerns/' . $id);
    }
    $assignee = input_int('assigned_to');
    if ($assignee && !DB::val("SELECT 1 FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = ? AND r.slug = 'auditor'", [$assignee])) {
        $assignee = null;
    }
    DB::tx(function () use ($c, $status, $note, $assignee) {
        DB::update('complaints', ['status' => $status, 'assigned_to' => $assignee ?? $c['assigned_to']], 'id = ?', [$c['id']]);
        DB::insert('complaint_updates', ['complaint_id' => $c['id'], 'user_id' => Auth::id(), 'note' => $note, 'is_public' => input('is_public') ? 1 : 0]);
        Audit::log('workflow', 'concern_updated', 'complaint', $c['id'], ['status' => $status, 'public' => input('is_public') ? 'yes' : 'no']);
    });
    flash('success', 'Concern updated.');
    redirect('/audit/concerns/' . $id);
}
