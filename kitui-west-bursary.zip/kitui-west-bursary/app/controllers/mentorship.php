<?php
declare(strict_types=1);

const MENTOR_CATEGORIES = [
    'career' => 'Career guidance', 'academic' => 'Academic guidance', 'entrepreneurship' => 'Entrepreneurship',
    'digital_skills' => 'Digital skills', 'financial_literacy' => 'Financial literacy', 'leadership' => 'Leadership',
    'scholarship' => 'Scholarship, university & TVET guidance',
];

function mentorship_index(): void
{
    $u = Auth::require();
    if ($u['account_type'] === 'staff') {
        redirect('/staff/mentorship');
    }
    $events = DB::all('SELECT e.*, p.title AS program_title, p.category, p.description,
            (SELECT COUNT(*) FROM event_registrations r WHERE r.event_id = e.id) AS registered,
            (SELECT r.id FROM event_registrations r WHERE r.event_id = e.id AND r.user_id = ?) AS my_reg
        FROM mentorship_events e JOIN mentorship_programs p ON p.id = e.program_id
        WHERE e.is_active = 1 AND p.is_active = 1 AND e.starts_at >= NOW() ORDER BY e.starts_at LIMIT 50', [$u['id']]);
    $mine = DB::all('SELECT r.*, e.title, e.venue, e.starts_at, p.category FROM event_registrations r
        JOIN mentorship_events e ON e.id = r.event_id JOIN mentorship_programs p ON p.id = e.program_id
        WHERE r.user_id = ? ORDER BY e.starts_at DESC LIMIT 50', [$u['id']]);
    $programs = DB::all('SELECT * FROM mentorship_programs WHERE is_active = 1 ORDER BY category, title');
    render('mentorship/index', ['title' => 'Mentorship', 'events' => $events, 'mine' => $mine, 'programs' => $programs]);
}

function mentorship_register(string $id): void
{
    $u = Auth::require();
    if ($u['account_type'] === 'staff') {
        abort(403);
    }
    DB::tx(function () use ($id, $u) {
        $e = DB::one('SELECT * FROM mentorship_events WHERE id = ? AND is_active = 1 AND starts_at >= NOW() FOR UPDATE', [(int)$id]);
        if (!$e) {
            flash('error', 'That event is no longer open for registration.');
            return;
        }
        if (DB::val('SELECT 1 FROM event_registrations WHERE event_id = ? AND user_id = ?', [$e['id'], $u['id']])) {
            flash('info', 'You are already registered.');
            return;
        }
        $n = (int)DB::val('SELECT COUNT(*) FROM event_registrations WHERE event_id = ?', [$e['id']]);
        if ($n >= (int)$e['capacity']) {
            flash('error', 'Sorry, this event is full.');
            return;
        }
        DB::insert('event_registrations', ['event_id' => $e['id'], 'user_id' => $u['id']]);
        Audit::log('data', 'mentorship_registered', 'mentorship_event', $e['id']);
        notify_user($u['id'], 'Registered: ' . $e['title'], 'See you at ' . $e['venue'] . ' on ' . fmt_date($e['starts_at'], 'j M Y, g:i a') . '.', '/mentorship');
        flash('success', 'You are registered. We will remind you before the event.');
    });
    redirect('/mentorship');
}

function mentorship_feedback(string $id): void
{
    $u = Auth::require();
    $r = DB::one('SELECT r.*, e.starts_at FROM event_registrations r JOIN mentorship_events e ON e.id = r.event_id WHERE r.id = ? AND r.user_id = ?', [(int)$id, $u['id']]);
    if (!$r) {
        abort(404);
    }
    $rating = input_int('rating');
    if (strtotime($r['starts_at']) > time() || $rating === null || $rating < 1 || $rating > 5) {
        flash('error', 'Feedback can be given after the event, with a rating from 1 to 5.');
        redirect('/mentorship');
    }
    DB::update('event_registrations', ['feedback_rating' => $rating, 'feedback_comment' => mb_substr((string)input('comment', ''), 0, 500) ?: null], 'id = ?', [$r['id']]);
    flash('success', 'Thank you for your feedback.');
    redirect('/mentorship');
}

function mentorship_staff(): array
{
    return Auth::require('admin', 'ward_officer');
}

function mentorship_staffIndex(): void
{
    mentorship_staff();
    $events = DB::all('SELECT e.*, p.title AS program_title, p.category,
            (SELECT COUNT(*) FROM event_registrations r WHERE r.event_id = e.id) AS registered,
            (SELECT COUNT(*) FROM event_registrations r WHERE r.event_id = e.id AND r.attended = 1) AS attended,
            (SELECT ROUND(AVG(r.feedback_rating),1) FROM event_registrations r WHERE r.event_id = e.id) AS rating
        FROM mentorship_events e JOIN mentorship_programs p ON p.id = e.program_id ORDER BY e.starts_at DESC LIMIT 100');
    render('mentorship/staff', ['title' => 'Mentorship events', 'events' => $events]);
}

function mentorship_attendance(string $id): void
{
    mentorship_staff();
    $e = DB::one('SELECT e.*, p.title AS program_title FROM mentorship_events e JOIN mentorship_programs p ON p.id = e.program_id WHERE e.id = ?', [(int)$id]) ?? abort(404);
    $rows = DB::all('SELECT r.*, u.full_name, u.phone, u.account_type FROM event_registrations r JOIN users u ON u.id = r.user_id WHERE r.event_id = ? ORDER BY u.full_name', [$e['id']]);
    render('mentorship/attendance', ['title' => 'Attendance', 'e' => $e, 'rows' => $rows]);
}

function mentorship_saveAttendance(string $id): void
{
    $u = mentorship_staff();
    $e = DB::one('SELECT * FROM mentorship_events WHERE id = ?', [(int)$id]) ?? abort(404);
    if (strtotime($e['starts_at']) > time() + 3600) {
        flash('error', 'Attendance can be marked from the start of the event.');
        redirect('/staff/mentorship/events/' . $e['id']);
    }
    $present = array_map('intval', (array)($_POST['present'] ?? []));
    DB::tx(function () use ($e, $present, $u) {
        foreach (DB::all('SELECT id FROM event_registrations WHERE event_id = ?', [$e['id']]) as $r) {
            DB::update('event_registrations', ['attended' => in_array((int)$r['id'], $present, true) ? 1 : 0, 'attendance_marked_by' => $u['id']], 'id = ?', [$r['id']]);
        }
        Audit::log('data', 'attendance_marked', 'mentorship_event', $e['id'], ['present' => count($present)]);
    });
    flash('success', 'Attendance saved.');
    redirect('/staff/mentorship/events/' . $e['id']);
}
