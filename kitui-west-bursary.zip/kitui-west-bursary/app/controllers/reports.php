<?php
declare(strict_types=1);

/* Every report: who may run it, and the query that builds it. Downloads are audit-logged by Export::send. */
const REPORTS = [
    'applications' => ['Applications register', 'All submitted applications with requested, recommended, approved and paid amounts kept separate.', ['admin', 'auditor', 'committee', 'approver']],
    'verification' => ['Verification report', 'Document checks, verification outcome and field visits per application.', ['admin', 'auditor', 'committee']],
    'committee' => ['Committee decisions', 'Each committee recommendation and each approval decision with the officer responsible.', ['admin', 'auditor', 'committee', 'approver']],
    'payment_schedule' => ['Payment schedule', 'Payments by batch and institution, with bank details, for the bank or cheque run.', ['finance', 'auditor']],
    'reconciliation' => ['Reconciliation report', 'Recorded payments with references, who recorded them and who reconciled them.', ['finance', 'auditor']],
    'statistics' => ['Statistics by ward and level', 'Aggregated counts and amounts. Contains no personal data.', ['admin', 'auditor', 'committee', 'approver', 'finance']],
    'risk_flags' => ['Risk flags', 'Duplicate and risk flags raised and how they were resolved.', ['admin', 'auditor']],
    'audit' => ['Audit trail', 'The full hash-chained audit log for the selected cycle period.', ['auditor']],
    'sms' => ['SMS log', 'Messages sent to applicants and their delivery status.', ['admin', 'auditor']],
];

function reports_allowed(string $name): bool
{
    return isset(REPORTS[$name]) && Auth::has(...REPORTS[$name][2]);
}

function reports_index(): void
{
    Auth::require('admin', 'auditor', 'finance', 'approver', 'committee');
    $cycles = DB::all('SELECT id, name FROM application_cycles ORDER BY opens_at DESC');
    $recent = DB::all("SELECT l.created_at, l.entity_id AS report, JSON_UNQUOTE(JSON_EXTRACT(l.details, '$.format')) AS format, JSON_UNQUOTE(JSON_EXTRACT(l.details, '$.rows')) AS nrows, u.full_name FROM audit_logs l LEFT JOIN users u ON u.id = l.user_id WHERE l.action = 'report_download' ORDER BY l.id DESC LIMIT 15");
    $list = array_filter(REPORTS, fn($r, $k) => reports_allowed($k), ARRAY_FILTER_USE_BOTH);
    render('reports/index', ['title' => 'Reports', 'list' => $list, 'cycles' => $cycles, 'recent' => $recent]);
}

function reports_download(string $name): void
{
    Auth::require('admin', 'auditor', 'finance', 'approver', 'committee');
    if (!reports_allowed($name)) {
        Audit::log('security', 'report_denied', 'report', $name);
        abort(403);
    }
    $format = input('format') === 'xls' ? 'xls' : 'csv';
    $cycle = input_int('cycle') ?? (int)(latest_cycle()['id'] ?? 0);
    $c = [$cycle];
    $baseJoin = 'FROM applications a JOIN students s ON s.id = a.student_id JOIN wards w ON w.id = s.ward_id LEFT JOIN institutions i ON i.id = a.institution_id';
    switch ($name) {
        case 'applications':
            $h = ['Reference', 'Student', 'Gender', 'Ward', 'Institution', 'Level', 'Class', 'Status', 'Requested', 'Recommended', 'Approved', 'Paid', 'Continuing', 'Submitted'];
            $rows = DB::rows("SELECT a.reference, CONCAT(s.first_name,' ',s.last_name), s.gender, w.name, i.name, a.level, a.class_year, a.status, a.amount_requested, a.amount_recommended, a.amount_approved, a.amount_paid, IF(a.is_continuation,'Yes','No'), a.submitted_at $baseJoin WHERE a.cycle_id = ? AND a.status NOT IN ('draft','withdrawn') ORDER BY a.reference", $c);
            break;
        case 'verification':
            $h = ['Reference', 'Student', 'Ward', 'Status', 'Documents verified', 'Documents rejected', 'Field visit required', 'Visit date', 'Visit outcome', 'Visiting officer', 'Open flags'];
            $rows = DB::rows("SELECT a.reference, CONCAT(s.first_name,' ',s.last_name), w.name, a.status,
                (SELECT COUNT(*) FROM documents d WHERE d.application_id = a.id AND d.status = 'verified'),
                (SELECT COUNT(*) FROM documents d WHERE d.application_id = a.id AND d.status = 'rejected'),
                IF(a.field_visit_required,'Yes','No'), f.visit_date, f.outcome, u.full_name,
                (SELECT COUNT(*) FROM risk_flags r WHERE r.application_id = a.id AND r.status = 'open')
                $baseJoin LEFT JOIN field_visits f ON f.id = (SELECT MAX(id) FROM field_visits WHERE application_id = a.id) LEFT JOIN users u ON u.id = f.officer_id
                WHERE a.cycle_id = ? AND a.status NOT IN ('draft','withdrawn') ORDER BY a.reference", $c);
            break;
        case 'committee':
            $h = ['Reference', 'Student', 'Ward', 'Stage', 'Decision', 'Amount', 'Need score', 'Officer', 'Comment', 'Date'];
            $rows = DB::rows("SELECT * FROM (
                SELECT a.reference, CONCAT(s.first_name,' ',s.last_name) st, w.name wn, 'Committee' stage, r.decision, r.recommended_amount amt, r.need_score, u.full_name, r.comment, r.created_at dt $baseJoin JOIN committee_reviews r ON r.application_id = a.id JOIN users u ON u.id = r.member_id WHERE a.cycle_id = ?
                UNION ALL
                SELECT a.reference, CONCAT(s.first_name,' ',s.last_name), w.name, 'Approval', p.decision, p.amount, NULL, u.full_name, p.comment, p.created_at $baseJoin JOIN approvals p ON p.application_id = a.id JOIN users u ON u.id = p.approver_id WHERE a.cycle_id = ?
            ) x ORDER BY x.reference, x.dt", [$cycle, $cycle]);
            break;
        case 'payment_schedule':
            $h = ['Batch', 'Batch status', 'Reference', 'Student', 'Admission no.', 'Institution', 'Bank', 'Branch', 'Account name', 'Account no.', 'Amount', 'Payment status'];
            $rows = DB::rows("SELECT b.reference, b.status, a.reference, CONCAT(s.first_name,' ',s.last_name), a.admission_no, i.name, i.bank_name, i.bank_branch, i.account_name, i.account_no, p.amount, p.status
                FROM payments p JOIN payment_batches b ON b.id = p.batch_id JOIN applications a ON a.id = p.application_id JOIN students s ON s.id = a.student_id JOIN institutions i ON i.id = p.institution_id
                WHERE b.cycle_id = ? AND p.status <> 'removed' ORDER BY b.id, i.name", $c);
            break;
        case 'reconciliation':
            $h = ['Batch', 'Application', 'Institution', 'Amount', 'Status', 'Method', 'Payment reference', 'Paid on', 'Recorded by', 'Reconciliation', 'Reconciled by', 'Reconciled at', 'Note'];
            $rows = DB::rows("SELECT b.reference, a.reference, i.name, p.amount, p.status, p.payment_method, p.payment_reference, p.paid_on, r.full_name, p.reconciliation_status, x.full_name, p.reconciled_at, p.reconciliation_note
                FROM payments p JOIN payment_batches b ON b.id = p.batch_id JOIN applications a ON a.id = p.application_id JOIN institutions i ON i.id = p.institution_id
                LEFT JOIN users r ON r.id = p.recorded_by LEFT JOIN users x ON x.id = p.reconciled_by WHERE b.cycle_id = ? AND p.status IN ('paid','failed') ORDER BY b.id, p.id", $c);
            break;
        case 'statistics':
            $h = ['Ward', 'Level', 'Applications', 'Approved', 'Requested total', 'Approved total', 'Paid total'];
            $rows = DB::rows("SELECT w.name, COALESCE(a.level,'-'), COUNT(*),
                SUM(a.status IN ('approved','partially_approved','ready_for_payment','payment_processing','disbursed','closed','payment_failed')),
                COALESCE(SUM(a.amount_requested),0), COALESCE(SUM(a.amount_approved),0), COALESCE(SUM(a.amount_paid),0)
                $baseJoin WHERE a.cycle_id = ? AND a.status NOT IN ('draft','withdrawn') GROUP BY w.name, a.level ORDER BY w.name, a.level", $c);
            break;
        case 'risk_flags':
            $h = ['Reference', 'Code', 'Severity', 'Details', 'Status', 'Resolved by', 'Resolution', 'Raised', 'Resolved'];
            $rows = DB::rows("SELECT a.reference, f.code, f.severity, f.details, f.status, u.full_name, f.resolution_note, f.created_at, f.resolved_at
                FROM risk_flags f JOIN applications a ON a.id = f.application_id LEFT JOIN users u ON u.id = f.resolved_by WHERE a.cycle_id = ? ORDER BY f.id", $c);
            break;
        case 'audit':
            $cy = DB::one('SELECT opens_at FROM application_cycles WHERE id = ?', $c);
            $h = ['ID', 'Time', 'User', 'Category', 'Action', 'Entity', 'Entity ID', 'Details', 'IP', 'Previous hash', 'Hash'];
            $rows = DB::rows('SELECT l.id, l.created_at, u.full_name, l.category, l.action, l.entity_type, l.entity_id, l.details, l.ip, l.prev_hash, l.hash FROM audit_logs l LEFT JOIN users u ON u.id = l.user_id WHERE l.created_at >= ? ORDER BY l.id LIMIT 100000', [date('Y-m-d', strtotime(($cy['opens_at'] ?? 'now') . ' -60 days'))]);
            break;
        case 'sms':
            $h = ['Time', 'Phone', 'Template', 'Application', 'Status', 'Provider ref', 'Error', 'Message'];
            $rows = DB::rows('SELECT m.created_at, m.phone, m.template_code, a.reference, m.status, m.provider_ref, m.error, m.body FROM sms_messages m LEFT JOIN applications a ON a.id = m.application_id ORDER BY m.id DESC LIMIT 50000');
            break;
        default:
            abort(404);
    }
    Export::send($name . '_' . $cycle, $h, $rows, $format, $name !== 'statistics');
}
