<?php
declare(strict_types=1);

define('BASE_PATH', dirname(__DIR__));
define('APP_PATH', __DIR__);

// ---- .env loader (no external dependencies) ----
(function () {
    $file = BASE_PATH . '/.env';
    if (!is_file($file)) {
        return;
    }
    foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#' || !str_contains($line, '=')) {
            continue;
        }
        [$k, $v] = array_map('trim', explode('=', $line, 2));
        $v = trim($v, "\"'");
        if (getenv($k) === false) {
            putenv("$k=$v");
            $_ENV[$k] = $v;
        }
    }
})();

function env(string $key, ?string $default = null): ?string
{
    $v = getenv($key);
    return ($v === false || $v === '') ? $default : $v;
}

date_default_timezone_set(env('APP_TIMEZONE', 'Africa/Nairobi'));
mb_internal_encoding('UTF-8');

define('APP_DEBUG', env('APP_DEBUG', 'false') === 'true');
// Base path: the site may live at the domain root (/), in a folder (/kitui-west-bursary)
// or be reached through /public. Detected automatically so links and styles always resolve.
(function () {
    $base = '';
    if (PHP_SAPI !== 'cli' && PHP_SAPI !== 'cli-server') {
        $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
        $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        if ($dir !== '' && str_ends_with($dir, '/public') && !str_starts_with($uri . '/', $dir . '/')) {
            $dir = substr($dir, 0, -7); // reached through the project-root .htaccess
        }
        $base = $dir;
    }
    define('BASE_URL', $base);
})();
$__appUrl = env('APP_URL');
// APP_URL is trusted as configured. It is only replaced by the address actually being visited when
// that address is this computer or a private/local network (XAMPP testing). A forged Host header
// from the internet can therefore never redirect QR codes, SMS links or redirects elsewhere.
$__reqHostPort = (string)($_SERVER['HTTP_HOST'] ?? '');
$__reqHost = strtolower(preg_replace('/:\d+$/', '', $__reqHostPort));
$__isLocalHost = $__reqHost === 'localhost' || str_ends_with($__reqHost, '.local') || str_ends_with($__reqHost, '.test')
    || (filter_var($__reqHost, FILTER_VALIDATE_IP) && !filter_var($__reqHost, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE));
if (PHP_SAPI !== 'cli' && preg_match('/^[a-z0-9.\-]+(:\d+)?$/i', $__reqHostPort) && (!$__appUrl || $__isLocalHost)) {
    $__https = ($_SERVER['HTTPS'] ?? '') === 'on';
    $__appUrl = ($__https ? 'https://' : 'http://') . $__reqHostPort . BASE_URL;
}
define('APP_URL', rtrim($__appUrl ?: 'http://localhost:8000', '/'));
unset($__appUrl, $__https, $__reqHost, $__reqHostPort, $__isLocalHost);

// ---- Errors: log everything, never show technical details to users ----
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', BASE_PATH . '/storage/logs/php-error.log');

set_error_handler(function (int $no, string $str, string $file, int $line) {
    if (!(error_reporting() & $no)) {
        return false;
    }
    throw new ErrorException($str, 0, $no, $file, $line);
});

set_exception_handler(function (Throwable $e) {
    $id = bin2hex(random_bytes(4));
    if (!($e instanceof HttpException) || $e->status >= 500) {
        error_log("[$id] " . get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine() . "\n" . $e->getTraceAsString());
    }
    if (!headers_sent()) {
        http_response_code($e instanceof HttpException ? $e->status : 500);
    }
    if (PHP_SAPI === 'cli') {
        fwrite(STDERR, $e->getMessage() . PHP_EOL);
        exit(1);
    }
    if ($e instanceof PDOException && in_array((int)($e->errorInfo[1] ?? $e->getCode()), [2002, 2006, 1044, 1045, 1049, 2054], true)) {
        setup_page('The database is not connected yet', '<p>The website is installed, but it cannot reach its MySQL database.</p><ol>'
            . '<li>Start MySQL (in XAMPP: click <b>Start</b> next to MySQL).</li>'
            . '<li>Create the database and load <code>database/schema.sql</code> (phpMyAdmin → New → name it <code>kwb</code> → Import → choose <code>database/schema.sql</code>).</li>'
            . '<li>Check <code>DB_DATABASE</code>, <code>DB_USERNAME</code> and <code>DB_PASSWORD</code> in the <code>.env</code> file (XAMPP default: user <code>root</code>, empty password).</li>'
            . '<li>Load the starter data: open a terminal in the project folder and run <code>php scripts/seed.php</code>.</li></ol>'
            . '<p class="small">Reference ' . htmlspecialchars($id) . ' — details are in <code>storage/logs/php-error.log</code>.</p>', 503);
    }
    $status = $e instanceof HttpException ? $e->status : 500;
    $message = $e instanceof HttpException ? $e->getMessage() : 'Something went wrong on our side. The problem has been logged with reference ' . $id . '.';
    if (APP_DEBUG && !($e instanceof HttpException)) {
        $message .= ' [' . $e->getMessage() . ' @ ' . basename($e->getFile()) . ':' . $e->getLine() . ']';
    }
    try {
        echo function_exists('with_base') ? with_base(view('public/error', ['status' => $status, 'message' => $message], 'public')) : view('public/error', ['status' => $status, 'message' => $message], 'public');
    } catch (Throwable $inner) {
        echo '<h1>Service unavailable</h1><p>Reference ' . htmlspecialchars($id) . '</p>';
    }
});

/** A self-contained, styled page for installation problems (works even when the database is down). */
function setup_page(string $title, string $html, int $status = 503): never
{
    if (!headers_sent()) {
        http_response_code($status);
        header('Content-Type: text/html; charset=utf-8');
    }
    $css = (defined('BASE_URL') ? BASE_URL : '') . '/assets/css/app.css';
    $logo = (defined('BASE_URL') ? BASE_URL : '') . '/assets/img/logo.svg';
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
        . '<title>Setup — Kitui West Digital Bursary</title><link rel="stylesheet" href="' . htmlspecialchars($css) . '"></head>'
        . '<body class="setup-body"><main class="setup-card"><img src="' . htmlspecialchars($logo) . '" alt="" width="64" height="64">'
        . '<p class="eyebrow">Kitui West Digital Bursary · Setup</p><h1>' . htmlspecialchars($title) . '</h1>' . $html . '</main></body></html>';
    exit;
}

final class HttpException extends RuntimeException
{
    public function __construct(public int $status, string $message)
    {
        parent::__construct($message, $status);
    }
}

require APP_PATH . '/lib/helpers.php';
require APP_PATH . '/lib/DB.php';
require APP_PATH . '/lib/Audit.php';
require APP_PATH . '/lib/Auth.php';
require APP_PATH . '/lib/Totp.php';
require APP_PATH . '/lib/Storage.php';
require APP_PATH . '/lib/Sms.php';
require APP_PATH . '/lib/Workflow.php';
require APP_PATH . '/lib/Seal.php';
require APP_PATH . '/lib/Risk.php';
require APP_PATH . '/lib/Export.php';
require APP_PATH . '/lib/icons.php';
require APP_PATH . '/lib/Crypto.php';
require APP_PATH . '/lib/Installer.php';

if (PHP_SAPI !== 'cli') {
    $secure = str_starts_with(APP_URL, 'https://');
    session_name('kwb_sid');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => BASE_URL === '' ? '/' : BASE_URL . '/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.gc_maxlifetime', '7200');
    session_start();

    // Idle timeout: 30 minutes for staff, 2 hours for applicants
    $idle = (int)($_SESSION['idle_limit'] ?? 7200);
    if (isset($_SESSION['last_seen']) && time() - $_SESSION['last_seen'] > $idle) {
        $_SESSION = [];
        session_regenerate_id(true);
        $_SESSION['flash'][] = ['info', 'Your session expired. Please log in again.'];
    }
    $_SESSION['last_seen'] = time();

    header_remove('X-Powered-By');
    // Private pages must never be cached: on a shared cyber-café computer the Back button
    // would otherwise show the previous person's data after they log out.
    if (!empty($_SESSION['uid'])) {
        header('Cache-Control: no-store, no-cache, must-revalidate, private');
        header('Pragma: no-cache');
    }
    header('Cross-Origin-Opener-Policy: same-origin');
    header('Cross-Origin-Resource-Policy: same-origin');
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(self), geolocation=(self), microphone=()');
    header("Content-Security-Policy: default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; frame-ancestors 'none'; form-action 'self'; base-uri 'self'; object-src 'none'; connect-src 'self'");
    if ($secure) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}
