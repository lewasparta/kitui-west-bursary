<?php
declare(strict_types=1);

/** RFC 6238 TOTP (30s, 6 digits, SHA1) for administrator two-factor authentication. */
final class Totp
{
    private const ALPHA = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

    public static function secret(): string
    {
        $s = '';
        for ($i = 0; $i < 32; $i++) {
            $s .= self::ALPHA[random_int(0, 31)];
        }
        return $s;
    }

    private static function b32decode(string $b): string
    {
        $b = strtoupper(rtrim($b, '='));
        $bits = '';
        foreach (str_split($b) as $c) {
            $p = strpos(self::ALPHA, $c);
            if ($p === false) {
                continue;
            }
            $bits .= str_pad(decbin($p), 5, '0', STR_PAD_LEFT);
        }
        $out = '';
        foreach (str_split($bits, 8) as $byte) {
            if (strlen($byte) === 8) {
                $out .= chr(bindec($byte));
            }
        }
        return $out;
    }

    public static function code(string $secret, ?int $t = null): string
    {
        $counter = intdiv($t ?? time(), 30);
        $bin = pack('N*', 0, $counter);
        $h = hash_hmac('sha1', $bin, self::b32decode($secret), true);
        $o = ord($h[19]) & 0xf;
        $n = ((ord($h[$o]) & 0x7f) << 24) | (ord($h[$o + 1]) << 16) | (ord($h[$o + 2]) << 8) | ord($h[$o + 3]);
        return str_pad((string)($n % 1000000), 6, '0', STR_PAD_LEFT);
    }

    public static function verify(string $secret, string $code): bool
    {
        return self::matchStep($secret, $code) !== null;
    }

    /**
     * Returns the 30-second time step the code belongs to (±1 step for clock drift), or null.
     * Callers store the step and refuse it next time, so a code seen over someone's shoulder
     * or intercepted cannot be used twice.
     */
    public static function matchStep(string $secret, string $code, ?int $lastUsedStep = null): ?int
    {
        $code = preg_replace('/\D/', '', $code);
        if (strlen($code) !== 6 || $secret === '') {
            return null;
        }
        $now = intdiv(time(), 30);
        foreach ([-1, 0, 1] as $w) {
            $step = $now + $w;
            if ($lastUsedStep !== null && $step <= $lastUsedStep) {
                continue;
            }
            if (hash_equals(self::code($secret, $step * 30), $code)) {
                return $step;
            }
        }
        return null;
    }

    public static function uri(string $secret, string $account): string
    {
        return 'otpauth://totp/' . rawurlencode('Kitui West Bursary:' . $account) . '?secret=' . $secret . '&issuer=' . rawurlencode('Kitui West Bursary');
    }
}
