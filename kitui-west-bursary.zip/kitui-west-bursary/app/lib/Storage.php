<?php
declare(strict_types=1);

/**
 * Private file storage. Files are never placed under /public.
 *  - "local": a private directory outside the web root (development / small installs)
 *  - "s3": any S3-compatible private bucket (AWS S3, DigitalOcean Spaces, Cloudflare R2, MinIO)
 */
final class Storage
{
    public const ALLOWED = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'application/pdf' => 'pdf',
    ];

    public static function driver(): string
    {
        return env('STORAGE_DRIVER', 'local') === 's3' ? 's3' : 'local';
    }

    /** Validates by content (magic bytes), not by the file name the user supplied. */
    public static function detectMime(string $path): ?string
    {
        if (class_exists('finfo')) {
            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($path) ?: '';
        } else { // fileinfo extension switched off (some XAMPP installs): read the signature bytes ourselves
            $h = (string)file_get_contents($path, false, null, 0, 12);
            $mime = match (true) {
                str_starts_with($h, "\xFF\xD8\xFF") => 'image/jpeg',
                str_starts_with($h, "\x89PNG\r\n\x1A\n") => 'image/png',
                str_starts_with($h, 'RIFF') && substr($h, 8, 4) === 'WEBP' => 'image/webp',
                str_starts_with($h, '%PDF-') => 'application/pdf',
                default => '',
            };
        }
        if (!isset(self::ALLOWED[$mime])) {
            return null;
        }
        if ($mime === 'application/pdf') {
            $head = (string)file_get_contents($path, false, null, 0, 1024);
            if (!str_starts_with($head, '%PDF-')) {
                return null;
            }
            $body = (string)file_get_contents($path);
            if (preg_match('/\/(JavaScript|JS|Launch|EmbeddedFile)\b/', $body)) {
                return null; // active content is refused
            }
        } else {
            $info = @getimagesize($path);
            // Refuse "decompression bombs": a small file that expands to gigabytes in memory.
            if ($info === false || $info[0] < 1 || $info[1] < 1 || $info[0] * $info[1] > 40_000_000 || $info[0] > 12000 || $info[1] > 12000) {
                return null;
            }
        }
        return $mime;
    }

    /**
     * Resize/re-encode photos. Re-encoding strips EXIF (including GPS) and any embedded payload.
     * Documents (IDs, stamps, signatures) keep a larger size and higher quality so they stay readable.
     */
    public static function optimiseImage(string $path, string $mime, bool $isDocument): string
    {
        if (!function_exists('imagecreatefromstring') || !str_starts_with($mime, 'image/')) {
            return $mime;
        }
        $img = @imagecreatefromstring((string)file_get_contents($path));
        if (!$img) {
            return $mime;
        }
        if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
            $exif = @exif_read_data($path);
            $o = (int)($exif['Orientation'] ?? 1);
            $img = match ($o) { 3 => imagerotate($img, 180, 0), 6 => imagerotate($img, -90, 0), 8 => imagerotate($img, 90, 0), default => $img };
        }
        $maxSide = $isDocument ? 2200 : 1600;
        $quality = $isDocument ? 88 : 78;
        $w = imagesx($img);
        $h = imagesy($img);
        $scale = min(1, $maxSide / max($w, $h));
        if ($scale < 1) {
            $nw = (int)round($w * $scale);
            $nh = (int)round($h * $scale);
            $dst = imagecreatetruecolor($nw, $nh);
            imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255));
            imagecopyresampled($dst, $img, 0, 0, 0, 0, $nw, $nh, $w, $h);
            imagedestroy($img);
            $img = $dst;
        } elseif ($mime === 'image/png') {
            $dst = imagecreatetruecolor($w, $h);
            imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255));
            imagecopy($dst, $img, 0, 0, 0, 0, $w, $h);
            imagedestroy($img);
            $img = $dst;
        }
        imagejpeg($img, $path, $quality);
        imagedestroy($img);
        return 'image/jpeg';
    }

    public static function put(string $key, string $localPath, string $mime): void
    {
        if (self::driver() === 's3') {
            self::s3('PUT', $key, (string)file_get_contents($localPath), $mime);
            return;
        }
        $dest = self::localPath($key);
        if (!is_dir(dirname($dest))) {
            mkdir(dirname($dest), 0750, true);
        }
        if (!rename($localPath, $dest) && !copy($localPath, $dest)) {
            throw new RuntimeException('Could not store file');
        }
        @chmod($dest, 0640);
    }

    public static function read(string $driver, string $key): string
    {
        if ($driver === 's3') {
            return self::s3('GET', $key);
        }
        $p = self::localPath($key);
        if (!is_file($p)) {
            throw new HttpException(404, 'The file is not available.');
        }
        return (string)file_get_contents($p);
    }

    private static function localPath(string $key): string
    {
        if (!preg_match('#^[a-z0-9/_\-.]+$#', $key) || str_contains($key, '..')) {
            throw new InvalidArgumentException('Bad storage key');
        }
        $root = env('STORAGE_LOCAL_PATH', BASE_PATH . '/storage/private');
        return rtrim($root, '/') . '/' . $key;
    }

    /** Minimal AWS Signature V4 client for private S3-compatible buckets. */
    private static function s3(string $method, string $key, string $body = '', string $mime = 'application/octet-stream'): string
    {
        $endpoint = rtrim((string)env('S3_ENDPOINT'), '/');
        $bucket = (string)env('S3_BUCKET');
        $region = env('S3_REGION', 'us-east-1');
        $ak = (string)env('S3_KEY');
        $sk = (string)env('S3_SECRET');
        $host = parse_url($endpoint, PHP_URL_HOST);
        $path = '/' . $bucket . '/' . str_replace('%2F', '/', rawurlencode($key));
        $amzDate = gmdate('Ymd\THis\Z');
        $date = gmdate('Ymd');
        $payloadHash = hash('sha256', $body);
        $headers = ['host' => $host, 'x-amz-content-sha256' => $payloadHash, 'x-amz-date' => $amzDate];
        if ($method === 'PUT') {
            $headers['content-type'] = $mime;
            $headers['x-amz-server-side-encryption'] = 'AES256';
        }
        ksort($headers);
        $canonHeaders = '';
        foreach ($headers as $k => $v) {
            $canonHeaders .= $k . ':' . trim((string)$v) . "\n";
        }
        $signed = implode(';', array_keys($headers));
        $canonical = implode("\n", [$method, $path, '', $canonHeaders, $signed, $payloadHash]);
        $scope = "$date/$region/s3/aws4_request";
        $toSign = "AWS4-HMAC-SHA256\n$amzDate\n$scope\n" . hash('sha256', $canonical);
        $k = hash_hmac('sha256', 'aws4_request', hash_hmac('sha256', 's3', hash_hmac('sha256', $region, hash_hmac('sha256', $date, 'AWS4' . $sk, true), true), true), true);
        $sig = hash_hmac('sha256', $toSign, $k);
        $httpHeaders = ["Authorization: AWS4-HMAC-SHA256 Credential=$ak/$scope, SignedHeaders=$signed, Signature=$sig"];
        foreach ($headers as $hk => $hv) {
            if ($hk !== 'host') {
                $httpHeaders[] = "$hk: $hv";
            }
        }
        $ch = curl_init($endpoint . $path);
        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => $httpHeaders,
            CURLOPT_TIMEOUT => 60,
        ]);
        if ($method === 'PUT') {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        }
        $res = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($res === false || $code >= 300) {
            throw new RuntimeException("Object storage $method failed with HTTP $code");
        }
        return (string)$res;
    }
}
