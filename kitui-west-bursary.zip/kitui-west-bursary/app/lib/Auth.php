<?php
declare(strict_types=1);

final class Auth
{
    private static ?array $user = null;
    private static ?array $roles = null;

    /** Absolute session lifetime, even for an active user (shared cyber-café computers). */
    public const MAX_SESSION = 12 * 3600;

    private static function uaHash(): string
    {
        return substr(hash('sha256', (string)($_SERVER['HTTP_USER_AGENT'] ?? '')), 0, 16);
    }

    /** Staff roles that must use two-step login (configurable in Settings; admin always). */
    public static function twofaRequiredFor(array $roles): bool
    {
        $req = array_filter(array_map('trim', explode(',', setting('twofa_roles', 'admin,approver,finance,auditor'))));
        $req[] = 'admin';
        return (bool)array_intersect($roles, $req);
    }

    /** Signs out every session of a user (after a password change, reset or deactivation). */
    public static function bumpEpoch(int $userId): void
    {
        DB::run('UPDATE users SET session_epoch = session_epoch + 1, password_changed_at = NOW() WHERE id = ?', [$userId]);
        if ((int)($_SESSION['uid'] ?? 0) === $userId) {
            $_SESSION['epoch'] = (int)DB::val('SELECT session_epoch FROM users WHERE id = ?', [$userId]);
            self::$user = null;
        }
    }

    public static function id(): ?int
    {
        return isset($_SESSION['uid']) && empty($_SESSION['pending_2fa']) ? (int)$_SESSION['uid'] : null;
    }

    public static function user(): ?array
    {
        $id = self::id();
        if (!$id) {
            return null;
        }
        if (self::$user === null || (int)self::$user['id'] !== $id) {
            self::$user = DB::one('SELECT id, full_name, phone, email, account_type, ward_id, approval_limit, is_active, totp_enabled, must_change_password, session_epoch FROM users WHERE id = ?', [$id]);
            $why = null;
            if (!self::$user || !self::$user['is_active']) {
                $why = 'account_disabled';
            } elseif ((int)self::$user['session_epoch'] !== (int)($_SESSION['epoch'] ?? -1)) {
                $why = 'signed_out_elsewhere'; // password changed/reset: every other device is signed out
            } elseif (time() - (int)($_SESSION['login_at'] ?? 0) > self::MAX_SESSION) {
                $why = 'session_too_old';
            } elseif (!hash_equals((string)($_SESSION['ua'] ?? ''), self::uaHash())) {
                $why = 'session_device_changed';
                Audit::log('security', 'session_hijack_suspected', 'user', $id, ['ip' => $_SERVER['REMOTE_ADDR'] ?? ''], $id);
            }
            if ($why) {
                self::logout();
                if ($why !== 'account_disabled') {
                    $_SESSION['flash'][] = ['info', 'For your security, please log in again.'];
                }
                return null;
            }
        }
        return self::$user;
    }

    public static function roles(): array
    {
        $id = self::id();
        if (!$id) {
            return [];
        }
        if (self::$roles === null) {
            self::$roles = array_column(DB::all('SELECT r.slug FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = ?', [$id]), 'slug');
        }
        return self::$roles;
    }

    public static function rolesFor(int $userId): array
    {
        return array_column(DB::all('SELECT r.slug FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = ?', [$userId]), 'slug');
    }

    public static function has(string ...$roles): bool
    {
        return (bool)array_intersect($roles, self::roles());
    }

    public static function isStaff(): bool
    {
        return (self::user()['account_type'] ?? '') === 'staff';
    }

    public static function require(string ...$roles): array
    {
        $u = self::user();
        if (!$u) {
            $_SESSION['intended'] = $_SERVER['REQUEST_URI'] ?? '/';
            flash('info', 'Please log in to continue.');
            redirect('/login');
        }
        if ($u['must_change_password'] && !str_starts_with($_SERVER['REQUEST_URI'] ?? '', '/account/password')) {
            flash('info', 'Please set a new password before continuing.');
            redirect('/account/password');
        }
        if ($roles && !self::has(...$roles)) {
            Audit::log('access', 'forbidden', 'route', substr($_SERVER['REQUEST_URI'] ?? '', 0, 40));
            abort(403);
        }
        return $u;
    }

    /** Returns 'ok', '2fa', 'locked' or 'invalid'. */
    public static function attempt(string $phone, string $password): string
    {
        $u = DB::one('SELECT * FROM users WHERE phone = ?', [normalize_phone($phone)]);
        if (!$u || !$u['is_active']) {
            password_verify($password, '$2y$12$abcdefghijklmnopqrstuuJ5Gm1r3n1V2c5sQ3p2t8K9rXc8q9Z3y'); // constant-ish time
            Audit::log('security', 'login_failed', 'user', null, ['phone' => mask_phone(normalize_phone($phone))], null);
            return 'invalid';
        }
        if ($u['locked_until'] && strtotime($u['locked_until']) > time()) {
            Audit::log('security', 'login_locked', 'user', $u['id'], [], null);
            return 'locked';
        }
        if (!password_verify($password, $u['password_hash'])) {
            $fails = (int)$u['failed_logins'] + 1;
            $lock = $fails >= 5 ? date('Y-m-d H:i:s', time() + 15 * 60) : null;
            DB::run('UPDATE users SET failed_logins = ?, locked_until = ? WHERE id = ?', [$lock ? 0 : $fails, $lock, $u['id']]);
            Audit::log('security', $lock ? 'account_locked' : 'login_failed', 'user', $u['id'], ['attempt' => $fails], null);
            return $lock ? 'locked' : 'invalid';
        }
        if (password_needs_rehash($u['password_hash'], self::algo())) {
            DB::run('UPDATE users SET password_hash = ? WHERE id = ?', [self::hashPassword($password), $u['id']]);
        }
        session_regenerate_id(true);
        $_SESSION['uid'] = (int)$u['id'];
        $roles = self::rolesFor((int)$u['id']);
        $needs2fa = $u['account_type'] === 'staff' && (self::twofaRequiredFor($roles) || $u['totp_enabled']);
        if ($needs2fa) {
            $_SESSION['pending_2fa'] = true;
            $_SESSION['pending_2fa_at'] = time();
            return '2fa';
        }
        self::complete((int)$u['id']);
        return 'ok';
    }

    public static function complete(int $userId): void
    {
        unset($_SESSION['pending_2fa'], $_SESSION['pending_2fa_at']);
        session_regenerate_id(true);
        $_SESSION['uid'] = $userId;
        $_SESSION['epoch'] = (int)DB::val('SELECT session_epoch FROM users WHERE id = ?', [$userId]);
        $_SESSION['login_at'] = time();
        $_SESSION['ua'] = self::uaHash();
        self::$user = null;
        self::$roles = null;
        $type = DB::val('SELECT account_type FROM users WHERE id=?', [$userId]);
        $_SESSION['idle_limit'] = $type === 'staff' ? 1800 : 3600;
        DB::run('UPDATE users SET failed_logins = 0, locked_until = NULL, last_login_at = NOW() WHERE id = ?', [$userId]);
        Audit::log('security', 'login', 'user', $userId, [], $userId);
    }

    public static function logout(): void
    {
        if (isset($_SESSION['uid']) && empty($_SESSION['pending_2fa'])) {
            Audit::log('security', 'logout', 'user', (int)$_SESSION['uid']);
        }
        $_SESSION = [];
        session_regenerate_id(true);
        self::$user = null;
        self::$roles = null;
    }

    private static function algo(): string|int|null
    {
        return defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_DEFAULT;
    }

    public static function hashPassword(string $p): string
    {
        return password_hash($p, self::algo());
    }

    private const COMMON = ['password', 'passw0rd', 'qwerty', 'kitui', 'bursary', 'welcome', 'letmein', 'admin', 'kenya', 'nairobi',
        'iloveyou', 'monkey', 'football', 'arsenal', 'manutd', 'chelsea', 'jesus', 'mungu', 'baraka', 'changeme', 'secret', 'default'];

    /** @param array $personal name/phone/ID values the password must not contain */
    public static function passwordProblems(string $p, array $personal = []): ?string
    {
        if (strlen($p) < 10) {
            return 'Use at least 10 characters.';
        }
        if (!preg_match('/[A-Za-z]/', $p) || !preg_match('/\d/', $p)) {
            return 'Use both letters and numbers.';
        }
        $lower = strtolower($p);
        foreach (self::COMMON as $c) {
            if (str_contains($lower, $c)) {
                return 'That password is too easy to guess. Avoid words like "' . $c . '".';
            }
        }
        if (preg_match('/^(.)\1+$/', $p) || preg_match('/(0123|1234|2345|3456|4567|5678|6789|abcd|qwer|asdf)/i', $p) && strlen(preg_replace('/[^a-z]/i', '', $p)) < 4) {
            return 'Avoid simple sequences like 1234 or abcd.';
        }
        foreach ($personal as $bit) {
            $bit = strtolower(preg_replace('/\s+/', '', (string)$bit));
            if (strlen($bit) >= 4 && (str_contains($lower, $bit) || str_contains($lower, substr($bit, -6)))) {
                return 'Do not use your name, phone number or ID number in your password.';
            }
        }
        return null;
    }

    public static function homeFor(): string
    {
        $u = self::user();
        if (!$u) {
            return '/login';
        }
        return $u['account_type'] === 'staff' ? '/staff' : '/portal';
    }
}
