<?php
declare(strict_types=1);

/**
 * SMS notifications. Every message is written to sms_messages first (the notification log),
 * then handed to the provider. SMS_DRIVER=log records without sending (development);
 * SMS_DRIVER=africastalking sends through Africa's Talking.
 */
final class Sms
{
    public static function template(string $code, string $phone, array $vars = [], ?int $applicationId = null): void
    {
        $tpl = DB::one('SELECT body FROM sms_templates WHERE code = ? AND is_active = 1', [$code]);
        if (!$tpl) {
            return; // template switched off by the administrator
        }
        $body = $tpl['body'];
        $vars += ['url' => APP_URL];
        foreach ($vars as $k => $v) {
            $body = str_replace('{' . $k . '}', (string)$v, $body);
        }
        self::send($phone, mb_substr($body, 0, 480), $code, $applicationId, $code === 'password_reset');
    }

    /** True when messages are only logged, not delivered (no SMS provider configured). */
    public static function testMode(): bool
    {
        return env('SMS_DRIVER', 'log') !== 'africastalking';
    }

    /**
     * @param bool $secret the message carries a one-time code: the stored copy is masked so nobody
     *                     reading the SMS log or its export can use it to take over an account.
     */
    public static function send(string $phone, string $body, ?string $code = null, ?int $applicationId = null, bool $secret = false): void
    {
        $id = DB::insert('sms_messages', [
            'phone' => normalize_phone($phone), 'body' => $secret ? preg_replace(['/((?:code|password) is:?\s*)\S+/i', '/\b\d{4,8}\b/'], ['$1••••••', '••••••'], $body) : $body, 'template_code' => $code,
            'application_id' => $applicationId, 'status' => 'queued',
        ]);
        $driver = env('SMS_DRIVER', 'log');
        if ($driver !== 'africastalking') {
            DB::run("UPDATE sms_messages SET status='logged', sent_at=NOW() WHERE id=?", [$id]);
            return;
        }
        try {
            $to = '+254' . substr(normalize_phone($phone), 1);
            $fields = ['username' => env('AT_USERNAME'), 'to' => $to, 'message' => $body];
            if ($from = env('AT_SENDER_ID')) {
                $fields['from'] = $from;
            }
            $ch = curl_init(env('AT_ENDPOINT', 'https://api.africastalking.com/version1/messaging'));
            curl_setopt_array($ch, [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => http_build_query($fields),
                CURLOPT_HTTPHEADER => ['apiKey: ' . env('AT_API_KEY'), 'Accept: application/json'],
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 15,
            ]);
            $res = curl_exec($ch);
            $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            $json = is_string($res) ? json_decode($res, true) : null;
            $rec = $json['SMSMessageData']['Recipients'][0] ?? null;
            if ($http < 300 && $rec && in_array($rec['status'] ?? '', ['Success', 'Sent'], true)) {
                DB::run("UPDATE sms_messages SET status='sent', provider_ref=?, sent_at=NOW() WHERE id=?", [substr((string)$rec['messageId'], 0, 80), $id]);
            } else {
                DB::run("UPDATE sms_messages SET status='failed', error=? WHERE id=?", [substr('HTTP ' . $http . ' ' . ($rec['status'] ?? 'no response'), 0, 255), $id]);
            }
        } catch (Throwable $e) {
            DB::run("UPDATE sms_messages SET status='failed', error=? WHERE id=?", [substr($e->getMessage(), 0, 255), $id]);
        }
    }
}
