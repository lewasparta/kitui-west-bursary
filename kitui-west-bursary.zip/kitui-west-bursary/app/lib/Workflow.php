<?php
declare(strict_types=1);

/**
 * Application workflow with separation of duties.
 * A staff member may perform only ONE duty on any single application: whoever checks documents
 * cannot verify, review, approve, pay or reconcile that same application, and so on.
 */
final class Workflow
{
    /** duty => [roles allowed, statuses the duty can act on] */
    public const DUTIES = [
        'doc_check' => [['doc_officer'], ['submitted']],
        'verification' => [['ward_officer'], ['verification', 'field_verification']],
        'committee' => [['committee'], ['committee_review']],
        'approval' => [['approver'], ['recommended', 'approved', 'partially_approved', 'ready_for_payment']],
        'payment_prep' => [['finance'], ['approved', 'partially_approved', 'ready_for_payment', 'payment_failed']],
        'payment_authorize' => [['finance'], ['ready_for_payment']],
        'payment_record' => [['finance'], ['payment_processing']],
        'reconcile' => [['auditor', 'finance'], ['disbursed']],
        'audit_sample' => [['auditor'], ['verification', 'field_verification', 'committee_review', 'recommended', 'approved', 'partially_approved', 'ready_for_payment', 'payment_processing', 'disbursed', 'closed', 'not_approved']],
    ];

    public const DUTY_NAMES = [
        'applicant' => 'Applicant', 'doc_check' => 'Document check', 'verification' => 'Verification',
        'committee' => 'Committee review', 'approval' => 'Approval', 'payment_prep' => 'Payment preparation',
        'payment_authorize' => 'Payment authorisation', 'payment_record' => 'Payment confirmation',
        'reconcile' => 'Reconciliation', 'audit_sample' => 'Secondary audit', 'system' => 'System',
    ];

    public static function app(int $id): array
    {
        $a = DB::one('SELECT a.*, s.first_name, s.middle_name, s.last_name, s.ward_id, s.gender, s.date_of_birth, s.birth_cert_no, s.upi_no,
                s.sub_location, s.village, s.has_disability, w.name AS ward_name, i.name AS institution_name,
                g.full_name AS guardian_name, g.phone AS guardian_phone, g.national_id AS guardian_nid, g.occupation AS guardian_occupation,
                u.phone AS applicant_phone, u.full_name AS applicant_name, c.name AS cycle_name, c.year AS cycle_year
            FROM applications a
            JOIN users u ON u.id = a.applicant_user_id
            JOIN application_cycles c ON c.id = a.cycle_id
            LEFT JOIN students s ON s.id = a.student_id
            LEFT JOIN wards w ON w.id = s.ward_id
            LEFT JOIN institutions i ON i.id = a.institution_id
            LEFT JOIN guardians g ON g.id = a.guardian_id
            WHERE a.id = ?', [$id]);
        if (!$a) {
            abort(404);
        }
        return $a;
    }

    /** Returns null if the user may act, otherwise the reason they may not. */
    public static function blockReason(array $app, string $duty, ?int $userId = null): ?string
    {
        $userId ??= Auth::id();
        [$roles, $statuses] = self::DUTIES[$duty];
        $userRoles = Auth::rolesFor($userId);
        if (!array_intersect($roles, $userRoles)) {
            return 'Your role does not include ' . strtolower(self::DUTY_NAMES[$duty]) . '.';
        }
        if (!in_array($app['status'], $statuses, true)) {
            return 'This application is not at a stage where ' . strtolower(self::DUTY_NAMES[$duty]) . ' can happen.';
        }
        if ((int)$app['applicant_user_id'] === $userId) {
            return 'You cannot act on an application you submitted.';
        }
        $me = DB::one('SELECT phone, national_id, ward_id FROM users WHERE id = ?', [$userId]);
        if ($me && ($me['phone'] === ($app['guardian_phone'] ?? null) || ($me['national_id'] && $me['national_id'] === ($app['guardian_nid'] ?? null)))) {
            return 'Your phone or ID number matches this household. The application has been locked for you.';
        }
        // Separation of duties
        // The officer who prepared a payment may also record the bank confirmation; authorisation must be someone else.
        $compatible = in_array($duty, ['payment_prep', 'payment_record'], true) ? ['payment_prep', 'payment_record'] : [$duty];
        $ph = implode(',', array_fill(0, count($compatible), '?'));
        $other = DB::val("SELECT duty FROM application_events WHERE application_id = ? AND user_id = ? AND duty NOT IN ('applicant','system',$ph) LIMIT 1", array_merge([$app['id'], $userId], $compatible));
        if ($other) {
            return 'Separation of duties: you already handled "' . (self::DUTY_NAMES[$other] ?? $other) . '" on this application, so another officer must do this step.';
        }
        if ($duty === 'verification' && $me && $me['ward_id'] && (int)$me['ward_id'] !== (int)$app['ward_id']) {
            return 'This student is outside your assigned ward.';
        }
        if (in_array($duty, ['doc_check', 'verification', 'committee', 'approval', 'audit_sample'], true)) {
            $coi = DB::one('SELECT has_conflict FROM coi_declarations WHERE user_id = ? AND application_id = ?', [$userId, $app['id']]);
            if (!$coi) {
                return 'coi_required';
            }
            if ((int)$coi['has_conflict'] === 1) {
                return 'You declared a conflict of interest on this application, so you cannot act on it.';
            }
        }
        return null;
    }

    public static function assertCan(array $app, string $duty): void
    {
        $r = self::blockReason($app, $duty);
        if ($r === 'coi_required') {
            flash('info', 'Declare any conflict of interest before working on this application.');
            redirect('/staff/applications/' . $app['id']);
        }
        if ($r !== null) {
            Audit::log('access', 'sod_block', 'application', $app['id'], ['duty' => $duty, 'reason' => $r]);
            abort(403, $r);
        }
    }

    /** Record an event without changing status (comments, sub-steps). */
    public static function event(int $appId, string $duty, string $action, ?string $comment = null, bool $visible = false, ?string $from = null, ?string $to = null, ?int $userId = null): void
    {
        DB::insert('application_events', [
            'application_id' => $appId, 'user_id' => $userId ?? Auth::id(), 'duty' => $duty, 'action' => $action,
            'from_status' => $from, 'to_status' => $to, 'comment' => $comment, 'visible_to_applicant' => $visible ? 1 : 0,
        ]);
    }

    /** Atomic, version-checked status change. Throws if someone else changed the application first. */
    public static function move(array $app, string $duty, string $action, string $to, ?string $comment = null, array $extra = [], bool $visible = true): void
    {
        DB::tx(function () use ($app, $duty, $action, $to, $comment, $extra, $visible) {
            $sets = array_merge(['status' => $to], $extra);
            $cols = [];
            $vals = [];
            foreach ($sets as $k => $v) {
                $cols[] = "`$k` = ?";
                $vals[] = $v;
            }
            $vals[] = $app['id'];
            $vals[] = $app['version'];
            $n = DB::run('UPDATE applications SET ' . implode(', ', $cols) . ', version = version + 1 WHERE id = ? AND version = ?', $vals)->rowCount();
            if ($n !== 1) {
                throw new HttpException(409, 'Another officer updated this application while you were working. Open it again to see the latest version.');
            }
            self::event((int)$app['id'], $duty, $action, $comment, $visible, $app['status'], $to);
            Audit::log('workflow', $action, 'application', $app['id'], ['from' => $app['status'], 'to' => $to, 'duty' => $duty] + array_map(fn($v) => (string)$v, $extra));
        });
        self::notifyStatus((int)$app['id'], $to, $comment);
    }

    public static function notifyStatus(int $appId, string $status, ?string $comment = null): void
    {
        $a = self::app($appId);
        $name = trim($a['first_name'] . ' ' . $a['last_name']);
        $ref = $a['reference'];
        $link = '/portal/applications/' . $appId;
        $map = [
            'submitted' => ['submitted', 'Application received', "We received application $ref for $name."],
            'returned' => ['returned', 'Action needed on your application', "Application $ref needs attention: " . ($comment ?? '')],
            'verification' => ['verification', 'Documents checked', "Documents for $ref passed checks. Verification is under way."],
            'approved' => ['approved', 'Bursary approved', "Application $ref was approved for " . money($a['amount_approved']) . '.'],
            'partially_approved' => ['approved', 'Bursary approved', "Application $ref was approved for " . money($a['amount_approved']) . '.'],
            'not_approved' => ['not_approved', 'Application not approved', "Application $ref was not approved this cycle." . ($comment ? ' Reason: ' . $comment : '')],
            'disbursed' => ['paid', 'Payment made', money($a['amount_paid']) . " for $ref was paid to " . $a['institution_name'] . '.'],
        ];
        if (!isset($map[$status])) {
            notify_user((int)$a['applicant_user_id'], 'Status update: ' . status_label($status), "Application $ref is now at: " . status_label($status) . '.', $link);
            return;
        }
        [$tpl, $title, $body] = $map[$status];
        notify_user((int)$a['applicant_user_id'], $title, $body, $link);
        $payref = $status === 'disbursed' ? (string)DB::val("SELECT payment_reference FROM payments WHERE application_id=? AND status='paid' ORDER BY id DESC LIMIT 1", [$appId]) : '';
        Sms::template($tpl, $a['applicant_phone'], [
            'ref' => $ref, 'student' => $name, 'reason' => mb_substr((string)$comment, 0, 120),
            'amount' => number_format((float)($status === 'disbursed' ? $a['amount_paid'] : $a['amount_approved'])),
            'institution' => $a['institution_name'], 'payref' => $payref,
        ], $appId);
    }

    public static function history(int $appId, bool $applicantView = false): array
    {
        $sql = 'SELECT e.*, u.full_name AS actor FROM application_events e LEFT JOIN users u ON u.id = e.user_id WHERE e.application_id = ?' . ($applicantView ? ' AND e.visible_to_applicant = 1' : '') . ' ORDER BY e.id';
        return DB::all($sql, [$appId]);
    }

    /** Applicant-facing "what to do next". */
    public static function nextStep(array $a): string
    {
        return match ($a['status']) {
            'draft' => 'Finish the remaining steps and submit before the closing date.',
            'returned' => 'Read the officer’s note, update your application and submit it again.',
            'submitted' => 'No action needed. An officer is checking your documents.',
            'verification' => 'No action needed. Your details are being verified.',
            'field_verification' => 'An officer may visit your home. Keep your phone on.',
            'committee_review', 'recommended' => 'No action needed. The committee is reviewing your application.',
            'approved', 'partially_approved', 'ready_for_payment', 'payment_processing' => 'No action needed. Payment goes directly to the institution.',
            'disbursed' => 'Payment is complete. Download your support statement if you need it.',
            'not_approved' => 'You may apply again in a future cycle.',
            default => 'No action needed.',
        };
    }
}
