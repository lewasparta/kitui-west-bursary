<?php
declare(strict_types=1);

/**
 * Official sheets (receipts, recommendation forms, award letters, support statements) are
 * issued ONLY by the system. Each carries a unique verification code, an HMAC-SHA256 seal over
 * its exact contents and a QR code pointing to the public verification page.
 * A sheet typed up or edited in a cyber café will either have no valid code, or show different
 * details from the official record displayed when the code is checked.
 */
final class Seal
{
    public const KINDS = [
        'application_receipt' => 'Application receipt',
        'recommendation_form' => 'Chief recommendation form',
        'award_letter' => 'Bursary award letter',
        'support_statement' => 'Student support statement',
    ];

    private static function key(): string
    {
        $k = env('APP_SEAL_KEY', '');
        if (strlen($k) < 32) {
            throw new RuntimeException('APP_SEAL_KEY is missing or too short. Set a 64-character random value in .env.');
        }
        return $k;
    }

    public static function sign(string $code, string $kind, array $payload): string
    {
        $canon = json_encode(Audit::canon($payload), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return hash_hmac('sha256', $code . '|' . $kind . '|' . $canon, self::key());
    }

    private static function newCode(): string
    {
        $alpha = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no 0/O/1/I confusion
        do {
            $c = '';
            for ($i = 0; $i < 12; $i++) {
                $c .= $alpha[random_int(0, 31)];
            }
            $code = 'KWV-' . substr($c, 0, 4) . '-' . substr($c, 4, 4) . '-' . substr($c, 8, 4);
        } while (DB::val('SELECT 1 FROM issued_documents WHERE code = ?', [$code]));
        return $code;
    }

    /** Issue (or re-use) a sealed document. A changed payload revokes the old sheet. */
    public static function issue(int $appId, string $kind, array $payload): array
    {
        return DB::tx(function () use ($appId, $kind, $payload) {
            $existing = DB::all('SELECT * FROM issued_documents WHERE application_id = ? AND kind = ? AND revoked_at IS NULL FOR UPDATE', [$appId, $kind]);
            foreach ($existing as $doc) {
                $old = json_decode($doc['payload'], true);
                if (Audit::canon($old) == Audit::canon($payload)) {
                    return $doc;
                }
                DB::run('UPDATE issued_documents SET revoked_at = NOW(), revoked_reason = ? WHERE id = ?', ['Replaced by a newer version', $doc['id']]);
                Audit::log('report', 'document_revoked', 'issued_document', $doc['code'], ['reason' => 'superseded']);
            }
            $code = self::newCode();
            $sig = self::sign($code, $kind, $payload);
            $id = DB::insert('issued_documents', [
                'code' => $code, 'application_id' => $appId, 'kind' => $kind,
                'payload' => json_encode($payload, JSON_UNESCAPED_UNICODE), 'signature' => $sig, 'issued_by' => Auth::id(),
            ]);
            Audit::log('report', 'document_issued', 'issued_document', $code, ['kind' => $kind, 'application_id' => $appId]);
            return DB::one('SELECT * FROM issued_documents WHERE id = ?', [$id]);
        });
    }

    /** Returns ['state' => valid|revoked|tampered|unknown, 'doc' => ?array] */
    public static function verify(string $code): array
    {
        $code = strtoupper(trim($code));
        $doc = DB::one('SELECT * FROM issued_documents WHERE code = ?', [$code]);
        if (!$doc) {
            // A code that does not exist is the typical sign of a forged sheet: record it for the auditor.
            Audit::log('security', 'sheet_verify_failed', 'issued_document', mb_substr(preg_replace('/[^A-Z0-9\-]/', '', $code), 0, 40), [], null);
            return ['state' => 'unknown', 'doc' => null];
        }
        DB::run('UPDATE issued_documents SET verify_count = verify_count + 1 WHERE id = ?', [$doc['id']]);
        $payload = json_decode($doc['payload'], true) ?? [];
        if (!hash_equals($doc['signature'], self::sign($doc['code'], $doc['kind'], $payload))) {
            Audit::log('security', 'seal_mismatch', 'issued_document', $code, [], null);
            return ['state' => 'tampered', 'doc' => $doc];
        }
        return ['state' => $doc['revoked_at'] ? 'revoked' : 'valid', 'doc' => $doc];
    }

    /** Short fingerprint printed on the sheet (first 16 hex chars of the seal). */
    public static function fingerprint(array $doc): string
    {
        return strtoupper(implode(' ', str_split(substr($doc['signature'], 0, 16), 4)));
    }
}
