<?php
declare(strict_types=1);

function e(mixed $v): string
{
    return htmlspecialchars((string)($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function url(string $path = '', array $query = []): string
{
    $u = BASE_URL . '/' . ltrim($path, '/');
    return $query ? $u . '?' . http_build_query($query) : $u;
}

function abs_url(string $path = ''): string
{
    return APP_URL . '/' . ltrim($path, '/');
}

function asset(string $path): string
{
    $file = BASE_PATH . '/public/assets/' . $path;
    $v = is_file($file) ? substr((string)filemtime($file), -6) : '1';
    return BASE_URL . '/assets/' . $path . '?v=' . $v;
}

function view(string $template, array $data = [], ?string $layout = 'app'): string
{
    $file = APP_PATH . '/views/' . $template . '.php';
    if (!is_file($file)) {
        throw new RuntimeException("View not found: $template");
    }
    extract($data, EXTR_SKIP);
    ob_start();
    try {
        include $file;
        $content = ob_get_clean();
    } catch (Throwable $e) {
        ob_end_clean();
        throw $e;
    }
    if ($layout === null) {
        return $content;
    }
    ob_start();
    try {
        include APP_PATH . '/views/layouts/' . $layout . '.php';
        return ob_get_clean();
    } catch (Throwable $e) {
        ob_end_clean();
        throw $e;
    }
}

function render(string $template, array $data = [], ?string $layout = 'app'): never
{
    echo with_base(view($template, $data, $layout));
    exit;
}

function partial(string $name, array $data = []): string
{
    return view('partials/' . $name, $data, null);
}

function redirect(string $to): never
{
    if (BASE_URL !== '' && str_starts_with($to, '/') && !str_starts_with($to, '//') && !str_starts_with($to, BASE_URL . '/')) {
        $to = BASE_URL . $to;
    }
    header('Location: ' . $to, true, 303);
    exit;
}

function back(string $fallback = '/'): never
{
    $ref = $_SERVER['HTTP_REFERER'] ?? '';
    $host = parse_url(APP_URL, PHP_URL_HOST);
    if ($ref && parse_url($ref, PHP_URL_HOST) === $host) {
        redirect($ref);
    }
    redirect($fallback);
}

function abort(int $status, string $message = ''): never
{
    $defaults = [403 => 'You do not have permission to do that.', 404 => 'That page could not be found.', 419 => 'Your form expired. Please go back, refresh the page and try again.', 429 => 'Too many attempts. Please wait a few minutes and try again.'];
    throw new HttpException($status, $message ?: ($defaults[$status] ?? 'Request could not be completed.'));
}

function flash(string $type, string $msg): void
{
    $_SESSION['flash'][] = [$type, $msg];
}

function take_flash(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

function old(string $key, mixed $default = ''): string
{
    return e($_SESSION['old'][$key] ?? $default);
}

function keep_old(): void
{
    $data = $_POST;
    unset($data['password'], $data['password_confirmation'], $data['_csrf'], $data['pin']);
    $_SESSION['old'] = $data;
}

function clear_old(): void
{
    unset($_SESSION['old']);
}

// ---- CSRF ----
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check(): void
{
    $sent = $_POST['_csrf'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!is_string($sent) || !hash_equals(csrf_token(), $sent)) {
        // 403, not 419: Apache (XAMPP, cPanel) turns unknown status codes into "500 Internal Server Error".
        if (isset($_SERVER['HTTP_X_CSRF_TOKEN']) || str_contains((string)($_SERVER['HTTP_ACCEPT'] ?? ''), 'application/json')) {
            json_out(['ok' => false, 'error' => 'Your session expired. Reload the page and try again.'], 403);
        }
        abort(403, 'This form expired or was opened in another window. Go back, reload the page and try again.');
    }
}

// ---- Input ----
function input(string $key, mixed $default = null): mixed
{
    $v = $_POST[$key] ?? $_GET[$key] ?? $default;
    if (is_array($v)) {
        return $default; // scalar fields never accept arrays (tampered requests); list fields read $_POST directly
    }
    return is_string($v) ? trim($v) : $v;
}

function input_int(string $key): ?int
{
    $v = input($key);
    return ($v === null || $v === '' || !is_numeric($v)) ? null : (int)$v;
}

function input_money(string $key): ?float
{
    $v = str_replace([',', ' '], '', (string)input($key, ''));
    return ($v === '' || !is_numeric($v)) ? null : round((float)$v, 2);
}

/**
 * Minimal validator. Rules: required, max:N, min:N, phone, email, date, numeric, in:a|b, nid
 * Returns array of field => message.
 */
function validate(array $data, array $rules, array $labels = []): array
{
    $errors = [];
    foreach ($rules as $field => $ruleStr) {
        $v = $data[$field] ?? null;
        $v = is_string($v) ? trim($v) : $v;
        $label = $labels[$field] ?? ucfirst(str_replace('_', ' ', $field));
        foreach (explode('|', $ruleStr) as $rule) {
            [$name, $arg] = array_pad(explode(':', $rule, 2), 2, null);
            $empty = ($v === null || $v === '');
            if ($name === 'required' && $empty) {
                $errors[$field] = "$label is required.";
                break;
            }
            if ($empty) {
                continue;
            }
            $ok = match ($name) {
                'max' => mb_strlen((string)$v) <= (int)$arg,
                'min' => mb_strlen((string)$v) >= (int)$arg,
                'phone' => (bool)preg_match('/^(?:\+?254|0)(7|1)\d{8}$/', preg_replace('/\s+/', '', (string)$v)),
                'email' => filter_var($v, FILTER_VALIDATE_EMAIL) !== false,
                'date' => (bool)DateTime::createFromFormat('Y-m-d', (string)$v),
                'numeric' => is_numeric(str_replace(',', '', (string)$v)),
                'in' => in_array((string)$v, explode(',', (string)$arg), true),
                'nid' => (bool)preg_match('/^\d{6,10}$/', (string)$v),
                default => true,
            };
            if (!$ok) {
                $errors[$field] = match ($name) {
                    'max' => "$label must be at most $arg characters.",
                    'min' => "$label must be at least $arg characters.",
                    'phone' => "$label must be a valid Kenyan mobile number, e.g. 0712345678.",
                    'email' => "$label must be a valid email address.",
                    'date' => "$label must be a valid date.",
                    'numeric' => "$label must be a number.",
                    'in' => "Choose a valid option for $label.",
                    'nid' => "$label must be 6 to 10 digits.",
                    default => "$label is invalid.",
                };
                break;
            }
        }
    }
    return $errors;
}

function normalize_phone(string $p): string
{
    $p = preg_replace('/\D+/', '', $p);
    if (str_starts_with($p, '254')) {
        $p = '0' . substr($p, 3);
    }
    return $p;
}

function field_error(array $errors, string $field): string
{
    return isset($errors[$field]) ? '<p class="field-error" id="err-' . e($field) . '">' . e($errors[$field]) . '</p>' : '';
}

// ---- Formatting ----
function money(mixed $v): string
{
    return $v === null ? '—' : 'KES ' . number_format((float)$v, 0);
}

function fmt_date(?string $d, string $f = 'j M Y'): string
{
    return $d ? date($f, strtotime($d)) : '—';
}

function now(): string
{
    return date('Y-m-d H:i:s');
}

function client_ip(): string
{
    return substr($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0', 0, 45);
}

function mask_name(string $first, string $last): string
{
    return $first . ' ' . mb_substr($last, 0, 1) . '.';
}

function mask_phone(?string $p): string
{
    return $p ? substr($p, 0, 4) . '***' . substr($p, -2) : '—';
}

function status_label(string $s): string
{
    return [
        'draft' => 'Draft', 'submitted' => 'Submitted — document check', 'returned' => 'Action needed',
        'verification' => 'Verification', 'field_verification' => 'Field verification',
        'committee_review' => 'Committee review', 'recommended' => 'Awaiting approval',
        'approved' => 'Approved', 'partially_approved' => 'Partially approved', 'not_approved' => 'Not approved',
        'ready_for_payment' => 'Ready for payment', 'payment_processing' => 'Payment processing',
        'disbursed' => 'Paid to institution', 'payment_failed' => 'Payment failed — being re-processed',
        'closed' => 'Closed', 'withdrawn' => 'Withdrawn',
    ][$s] ?? ucfirst(str_replace('_', ' ', $s));
}

function status_badge(string $s): string
{
    $tone = match ($s) {
        'approved', 'partially_approved', 'disbursed', 'closed', 'verified', 'paid', 'reconciled', 'resolved', 'confirmed', 'cleared' => 'ok',
        'returned', 'payment_failed', 'rejected', 'failed', 'discrepancy', 'high' => 'bad',
        'not_approved', 'withdrawn', 'superseded' => 'muted',
        'draft' => 'draft',
        default => 'progress',
    };
    return '<span class="badge badge-' . $tone . '">' . e(status_label($s)) . '</span>';
}

function level_label(?string $l): string
{
    return ['secondary' => 'Secondary school', 'tvet' => 'TVET / Polytechnic', 'college' => 'College', 'university' => 'University', 'special' => 'Special needs school', 'all' => 'All levels'][$l ?? ''] ?? '—';
}

function t(string $key, array $vars = []): string
{
    static $lang = null;
    if ($lang === null) {
        $code = $_SESSION['lang'] ?? env('APP_LOCALE', 'en');
        $file = BASE_PATH . '/lang/' . preg_replace('/[^a-z]/', '', $code) . '.php';
        $lang = is_file($file) ? require $file : [];
        if ($code !== 'en') {
            $lang += require BASE_PATH . '/lang/en.php';
        }
    }
    $s = $lang[$key] ?? $key;
    foreach ($vars as $k => $v) {
        $s = str_replace('{' . $k . '}', (string)$v, $s);
    }
    return $s;
}

function setting(string $key, string $default = ''): string
{
    static $cache = null;
    if ($cache === null) {
        try {
            $cache = array_column(DB::all('SELECT skey, svalue FROM settings'), 'svalue', 'skey');
        } catch (Throwable) {
            $cache = [];
        }
    }
    return $cache[$key] ?? $default;
}

function current_cycle(): ?array
{
    return DB::one("SELECT * FROM application_cycles WHERE status='open' AND NOW() BETWEEN opens_at AND closes_at ORDER BY opens_at DESC LIMIT 1");
}

function latest_cycle(): ?array
{
    return DB::one("SELECT * FROM application_cycles WHERE status IN ('open','closed') ORDER BY opens_at DESC LIMIT 1");
}

function paginate(string $countSql, string $sql, array $params, int $perPage = 20): array
{
    $page = max(1, (int)($_GET['page'] ?? 1));
    $total = (int)DB::val($countSql, $params);
    $pages = max(1, (int)ceil($total / $perPage));
    $page = min($page, $pages);
    $rows = DB::all($sql . ' LIMIT ' . $perPage . ' OFFSET ' . (($page - 1) * $perPage), $params);
    return ['rows' => $rows, 'page' => $page, 'pages' => $pages, 'total' => $total];
}

/** Sliding window rate limit stored in MySQL (works across PHP workers). */
function rate_limit(string $action, int $max, int $windowSeconds, ?string $key = null): void
{
    $bucket = substr($action . ':' . ($key ?? client_ip()), 0, 120);
    $now = time();
    $row = DB::one('SELECT hits, window_start FROM rate_limits WHERE bucket = ?', [$bucket]);
    if (!$row || $now - (int)$row['window_start'] > $windowSeconds) {
        DB::run('REPLACE INTO rate_limits (bucket, hits, window_start) VALUES (?, 1, ?)', [$bucket, $now]);
        return;
    }
    if ((int)$row['hits'] >= $max) {
        Audit::log('security', 'rate_limited', 'rate_limit', $action, ['bucket' => $bucket]);
        abort(429);
    }
    DB::run('UPDATE rate_limits SET hits = hits + 1 WHERE bucket = ?', [$bucket]);
}

function notify_user(int $userId, string $title, string $body, ?string $link = null): void
{
    DB::run('INSERT INTO notifications (user_id, title, body, link) VALUES (?,?,?,?)', [$userId, $title, $body, $link]);
}

function next_sequence(string $name, int $year): int
{
    // Must be called inside a transaction; row lock guarantees unique references.
    DB::run('INSERT IGNORE INTO sequences (name, year, value) VALUES (?, ?, 0)', [$name, $year]);
    $v = (int)DB::val('SELECT value FROM sequences WHERE name=? AND year=? FOR UPDATE', [$name, $year]) + 1;
    DB::run('UPDATE sequences SET value=? WHERE name=? AND year=?', [$v, $name, $year]);
    return $v;
}

function json_out(array $data, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function is_post(): bool
{
    return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
}

function selected(mixed $a, mixed $b): string
{
    return (string)$a === (string)$b ? ' selected' : '';
}

function checked(mixed $v): string
{
    return $v ? ' checked' : '';
}

/** Prefix root-relative links in rendered HTML with the base path (sites installed in a folder). */
function with_base(string $html): string
{
    if (BASE_URL === '') {
        return $html;
    }
    $b = BASE_URL;
    return preg_replace_callback('/\b(href|src|action|data-[a-z-]+)="(\/(?!\/)[^"]*)"/', function ($m) use ($b) {
        return str_starts_with($m[2], $b . '/') || $m[2] === $b ? $m[0] : $m[1] . '="' . $b . $m[2] . '"';
    }, $html);
}

/** Current request path without the installation folder (for highlighting menu items). */
function current_path(): string
{
    $p = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
    if (BASE_URL !== '' && str_starts_with($p, BASE_URL)) {
        $p = substr($p, strlen(BASE_URL)) ?: '/';
    }
    if (str_starts_with($p, '/public/')) {
        $p = substr($p, 7);
    }
    return $p === '/' ? '/' : rtrim($p, '/');
}

/** Request from this computer or the local network (XAMPP testing), never from the internet. */
function is_local_request(): bool
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    return $ip === '127.0.0.1' || $ip === '::1'
        || (filter_var($ip, FILTER_VALIDATE_IP) && !filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE));
}
