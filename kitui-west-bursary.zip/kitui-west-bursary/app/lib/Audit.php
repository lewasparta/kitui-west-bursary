<?php
declare(strict_types=1);

/**
 * Append-only audit trail. Each row carries the SHA-256 of the previous row, so any
 * deletion or edit made directly in the database breaks the chain and is detected by verify().
 * The database also refuses UPDATE/DELETE on audit_logs via triggers.
 */
final class Audit
{
    public static function log(string $category, string $action, ?string $entityType = null, int|string|null $entityId = null, array $details = [], ?int $userId = null): void
    {
        $userId ??= Auth::id();
        $details = self::canon($details);
        $json = json_encode($details, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $ts = (new DateTimeImmutable())->format('Y-m-d H:i:s.v');

        DB::tx(function () use ($category, $action, $entityType, $entityId, $json, $userId, $ts) {
            DB::run("INSERT IGNORE INTO settings (skey, svalue) VALUES ('audit_last_hash', ?)", [str_repeat('0', 64)]);
            // Row lock serialises writers so the chain never forks.
            $prev = (string)DB::val("SELECT svalue FROM settings WHERE skey='audit_last_hash' FOR UPDATE");
            $row = [
                'user_id' => $userId,
                'category' => $category,
                'action' => $action,
                'entity_type' => $entityType,
                'entity_id' => $entityId === null ? null : (string)$entityId,
                'details' => $json,
                'ip' => PHP_SAPI === 'cli' ? 'cli' : client_ip(),
                'user_agent' => PHP_SAPI === 'cli' ? 'cli' : substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255),
                'prev_hash' => $prev,
                'created_at' => $ts,
            ];
            $row['hash'] = self::hash($row);
            DB::insert('audit_logs', $row);
            DB::run("UPDATE settings SET svalue=? WHERE skey='audit_last_hash'", [$row['hash']]);
        });
    }

    public static function hash(array $r): string
    {
        $details = is_string($r['details']) ? (json_decode($r['details'], true) ?? []) : ($r['details'] ?? []);
        $details = json_encode(self::canon($details), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return hash('sha256', implode('|', [
            $r['prev_hash'], (string)$r['user_id'], $r['category'], $r['action'],
            (string)$r['entity_type'], (string)$r['entity_id'], $details, $r['ip'], substr((string)$r['created_at'], 0, 23),
        ]));
    }

    /** Sort keys and stringify scalars so the JSON is stable after MySQL normalisation. */
    public static function canon(array $a): array
    {
        ksort($a);
        foreach ($a as $k => $v) {
            $a[$k] = is_array($v) ? self::canon($v) : ($v === null ? null : (is_bool($v) ? ($v ? '1' : '0') : (string)$v));
        }
        return $a;
    }

    /** Returns [ok(bool), checked(int), firstBrokenId(?int)] */
    public static function verify(): array
    {
        $prev = str_repeat('0', 64);
        $checked = 0;
        $lastId = 0;
        do {
            $rows = DB::all('SELECT * FROM audit_logs WHERE id > ? ORDER BY id LIMIT 2000', [$lastId]);
            foreach ($rows as $r) {
                if ($r['prev_hash'] !== $prev || self::hash($r) !== $r['hash']) {
                    return [false, $checked, (int)$r['id']];
                }
                $prev = $r['hash'];
                $lastId = (int)$r['id'];
                $checked++;
            }
        } while (count($rows) === 2000);
        $tip = DB::val("SELECT svalue FROM settings WHERE skey='audit_last_hash'");
        if ($checked > 0 && $tip !== $prev) {
            return [false, $checked, null];
        }
        return [true, $checked, null];
    }
}
