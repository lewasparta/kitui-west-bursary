<?php
declare(strict_types=1);

/** Authenticated encryption (AES-256-GCM) for secrets stored in the database, keyed from APP_KEY. */
final class Crypto
{
    private const PREFIX = 'enc1:';

    private static function key(string $purpose): string
    {
        $k = (string)env('APP_KEY', '');
        if (strlen($k) < 32) {
            throw new RuntimeException('APP_KEY must be set (64 hex characters).');
        }
        return hash_hmac('sha256', $purpose, $k, true);
    }

    public static function encrypt(string $plain, string $purpose): string
    {
        $iv = random_bytes(12);
        $tag = '';
        $c = openssl_encrypt($plain, 'aes-256-gcm', self::key($purpose), OPENSSL_RAW_DATA, $iv, $tag);
        return self::PREFIX . base64_encode($iv . $tag . $c);
    }

    /** Decrypts; values stored before encryption existed are returned unchanged (and get encrypted on next save). */
    public static function decrypt(?string $stored, string $purpose): ?string
    {
        if ($stored === null || $stored === '') {
            return $stored;
        }
        if (!str_starts_with($stored, self::PREFIX)) {
            return $stored;
        }
        $raw = base64_decode(substr($stored, strlen(self::PREFIX)), true);
        if ($raw === false || strlen($raw) < 29) {
            return null;
        }
        $p = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', self::key($purpose), OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16));
        return $p === false ? null : $p;
    }

    public static function isEncrypted(?string $v): bool
    {
        return $v !== null && str_starts_with($v, self::PREFIX);
    }
}
