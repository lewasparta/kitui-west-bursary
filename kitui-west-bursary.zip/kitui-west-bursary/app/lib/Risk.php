<?php
declare(strict_types=1);

/** Automated duplicate/risk checks. Flags inform officers; they never reject an application on their own. */
final class Risk
{
    public static function flag(int $appId, string $code, string $severity, string $details): void
    {
        DB::run('INSERT INTO risk_flags (application_id, code, severity, details) VALUES (?,?,?,?)
                 ON DUPLICATE KEY UPDATE details = VALUES(details), severity = VALUES(severity)', [$appId, $code, $severity, mb_substr($details, 0, 500)]);
    }

    public static function scan(int $appId): array
    {
        $a = Workflow::app($appId);
        $cycle = (int)$a['cycle_id'];

        foreach (['birth_cert_no' => 'birth certificate number', 'upi_no' => 'NEMIS/UPI number'] as $col => $label) {
            if (!empty($a[$col])) {
                $refs = DB::all("SELECT a.reference FROM applications a JOIN students s ON s.id = a.student_id
                                 WHERE s.$col = ? AND a.cycle_id = ? AND a.id <> ? AND a.status NOT IN ('draft','withdrawn')", [$a[$col], $cycle, $appId]);
                if ($refs) {
                    self::flag($appId, 'DUP_' . strtoupper($col), 'high', "Same $label as " . implode(', ', array_column($refs, 'reference')));
                }
            }
        }

        $same = DB::all("SELECT a.reference FROM applications a JOIN students s ON s.id = a.student_id
                         WHERE s.first_name = ? AND s.last_name = ? AND s.date_of_birth = ? AND a.cycle_id = ? AND a.id <> ? AND a.status NOT IN ('draft','withdrawn')",
            [$a['first_name'], $a['last_name'], $a['date_of_birth'], $cycle, $appId]);
        if ($same) {
            self::flag($appId, 'DUP_NAME_DOB', 'medium', 'Same name and date of birth as ' . implode(', ', array_column($same, 'reference')));
        }

        $max = (int)DB::val('SELECT max_applications_per_guardian FROM application_cycles WHERE id = ?', [$cycle]);
        $n = (int)DB::val("SELECT COUNT(*) FROM applications a JOIN guardians g ON g.id = a.guardian_id
                           WHERE g.phone = ? AND a.cycle_id = ? AND a.status NOT IN ('draft','withdrawn')", [$a['guardian_phone'], $cycle]);
        if ($max > 0 && $n > $max) {
            self::flag($appId, 'GUARDIAN_VOLUME', 'medium', "Guardian phone appears on $n applications this cycle (limit $max).");
        }

        // Identical files on a DIFFERENT student's application (re-used documents of the same student are expected)
        $dupDocs = DB::all("SELECT DISTINCT COALESCE(a2.reference, CONCAT('draft #', a2.id)) AS reference FROM documents d1
                            JOIN applications a1 ON a1.id = d1.application_id
                            JOIN documents d2 ON d2.sha256 = d1.sha256 AND d2.application_id <> d1.application_id
                            JOIN applications a2 ON a2.id = d2.application_id AND (a2.student_id IS NULL OR a2.student_id <> a1.student_id)
                            WHERE d1.application_id = ? AND d1.status <> 'superseded' AND d2.status <> 'superseded'", [$appId]);
        if ($dupDocs) {
            self::flag($appId, 'DUP_DOCUMENT', 'high', 'An identical file was uploaded on ' . implode(', ', array_column($dupDocs, 'reference')));
        }

        $staff = DB::val("SELECT full_name FROM users WHERE account_type='staff' AND (phone = ? OR (national_id IS NOT NULL AND national_id = ?)) LIMIT 1", [$a['guardian_phone'], $a['guardian_nid']]);
        if ($staff) {
            self::flag($appId, 'STAFF_LINK', 'high', 'Guardian phone or ID matches a staff account. The system blocks that officer from acting on it.');
        }

        if ($a['amount_requested'] !== null && $a['fee_balance'] !== null && (float)$a['amount_requested'] > (float)$a['fee_balance']) {
            self::flag($appId, 'OVER_BALANCE', 'low', 'Requested amount is higher than the declared fee balance.');
        }

        $age = (int)date_diff(date_create($a['date_of_birth']), date_create())->y;
        $range = ['secondary' => [11, 24], 'tvet' => [15, 40], 'college' => [16, 40], 'university' => [16, 40], 'special' => [4, 30]][$a['level']] ?? [4, 60];
        if ($age < $range[0] || $age > $range[1]) {
            self::flag($appId, 'AGE_LEVEL', 'low', "Student age ($age) is unusual for " . level_label($a['level']) . '.');
        }

        return DB::all('SELECT * FROM risk_flags WHERE application_id = ?', [$appId]);
    }

    /** Random sampling for field visits and secondary audits (rates set per cycle). */
    public static function sample(int $appId): void
    {
        $a = DB::one('SELECT a.id, c.field_verification_rate, c.secondary_audit_rate FROM applications a JOIN application_cycles c ON c.id = a.cycle_id WHERE a.id = ?', [$appId]);
        $high = (int)DB::val("SELECT COUNT(*) FROM risk_flags WHERE application_id = ? AND severity = 'high' AND status = 'open'", [$appId]);
        $field = $high > 0 || random_int(1, 100) <= (int)$a['field_verification_rate'];
        $audit = random_int(1, 100) <= (int)$a['secondary_audit_rate'];
        DB::run('UPDATE applications SET field_visit_required = ?, secondary_audit = ? WHERE id = ?', [$field ? 1 : 0, $audit ? 1 : 0, $appId]);
    }
}
