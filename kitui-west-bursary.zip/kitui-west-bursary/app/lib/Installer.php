<?php
declare(strict_types=1);

/**
 * One-click installation: writes .env with fresh secret keys, creates the database,
 * loads the schema (including triggers) and the starter data, and locks itself.
 */
final class Installer
{
    public const LOCK = '/storage/installed.lock';

    public static function installed(): bool
    {
        return is_file(BASE_PATH . self::LOCK);
    }

    public static function markInstalled(): void
    {
        @file_put_contents(BASE_PATH . self::LOCK, 'Installed ' . date('c') . "\n");
    }

    /** An existing, working installation (e.g. set up from the command line) is adopted without re-installing. */
    public static function adoptExisting(): bool
    {
        if (!is_file(BASE_PATH . '/.env')) {
            return false;
        }
        try {
            if ((int)DB::val('SELECT COUNT(*) FROM roles') > 0) {
                self::markInstalled();
                return true;
            }
        } catch (Throwable) {
        }
        return false;
    }

    public const SCHEMA_VERSION = 2;

    /** Brings an existing database up to date. Idempotent; runs once per version. */
    public static function migrate(): void
    {
        $v = (int)setting('schema_version', '1');
        if ($v >= self::SCHEMA_VERSION) {
            return;
        }
        $has = fn(string $t, string $c) => (bool)DB::val('SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?', [$t, $c]);
        if ($v < 2) {
            DB::run('ALTER TABLE users MODIFY totp_secret VARCHAR(255) NULL');
            foreach ([
                'totp_last_step' => 'BIGINT NULL', 'session_epoch' => 'INT UNSIGNED NOT NULL DEFAULT 0',
                'phone_verified_at' => 'DATETIME NULL', 'password_changed_at' => 'DATETIME NULL',
            ] as $col => $def) {
                if (!$has('users', $col)) {
                    DB::run("ALTER TABLE users ADD COLUMN $col $def");
                }
            }
            // Repair: family accounts must carry the role matching their account type.
            DB::run("INSERT INTO user_roles (user_id, role_id) SELECT u.id, r.id FROM users u JOIN roles r ON r.slug = u.account_type
                WHERE u.account_type IN ('parent','student') AND NOT EXISTS (SELECT 1 FROM user_roles x WHERE x.user_id = u.id)");
            // Existing accounts were created before phone verification existed.
            DB::run('UPDATE users SET phone_verified_at = created_at WHERE phone_verified_at IS NULL');
            // Encrypt any authenticator secrets stored in plain text.
            foreach (DB::all("SELECT id, totp_secret FROM users WHERE totp_secret IS NOT NULL AND totp_secret NOT LIKE 'enc1:%'") as $r) {
                DB::run('UPDATE users SET totp_secret = ? WHERE id = ?', [Crypto::encrypt($r['totp_secret'], 'totp'), $r['id']]);
            }
            $demo = (bool)DB::val("SELECT 1 FROM users WHERE phone = '0700000009' AND full_name LIKE '%(Finance)%'");
            DB::run("INSERT IGNORE INTO settings (skey, svalue) VALUES ('twofa_roles', ?)", [$demo ? 'admin' : 'admin,approver,finance,auditor']);
        }
        DB::run("INSERT INTO settings (skey, svalue) VALUES ('schema_version', ?) ON DUPLICATE KEY UPDATE svalue = VALUES(svalue)", [(string)self::SCHEMA_VERSION]);
        Audit::log('config', 'schema_migrated', 'setting', 'schema_version', ['from' => (string)$v, 'to' => (string)self::SCHEMA_VERSION], null);
    }

    public static function serverPdo(string $host, string $port, string $user, string $pass): PDO
    {
        return new PDO("mysql:host=$host;port=$port;charset=utf8mb4", $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 5,
        ]);
    }

    /** Runs a .sql file, honouring DELIMITER blocks used for triggers. */
    public static function runSqlFile(PDO $pdo, string $file): int
    {
        $delim = ';';
        $buf = '';
        $n = 0;
        foreach (preg_split('/\R/', (string)file_get_contents($file)) as $line) {
            $t = trim($line);
            if ($buf === '' && ($t === '' || str_starts_with($t, '--'))) {
                continue;
            }
            if (preg_match('/^DELIMITER\s+(\S+)$/i', $t, $m)) {
                $delim = $m[1];
                continue;
            }
            $buf .= $line . "\n";
            if (str_ends_with(rtrim($line), $delim)) {
                $sql = trim(substr(rtrim($buf), 0, -strlen($delim)));
                if ($sql !== '') {
                    $pdo->exec($sql);
                    $n++;
                }
                $buf = '';
            }
        }
        if (trim($buf) !== '') {
            $pdo->exec($buf);
            $n++;
        }
        return $n;
    }

    public static function envContent(array $v): string
    {
        $key = bin2hex(random_bytes(32));
        $seal = bin2hex(random_bytes(32));
        return "# Written by the installer on " . date('j M Y H:i') . ". Keep this file private and backed up.\n"
            . "# APP_SEAL_KEY signs official sheets: never change or lose it.\n"
            . "APP_URL={$v['url']}\nAPP_DEBUG=false\nAPP_TIMEZONE=Africa/Nairobi\nAPP_LOCALE=en\n"
            . "APP_KEY=$key\nAPP_SEAL_KEY=$seal\n\n"
            . "DB_HOST={$v['host']}\nDB_PORT={$v['port']}\nDB_DATABASE={$v['db']}\nDB_USERNAME={$v['user']}\nDB_PASSWORD={$v['pass']}\n\n"
            . "STORAGE_DRIVER=local\nSMS_DRIVER=log\n"
            . "# To send real SMS: SMS_DRIVER=africastalking and fill AT_USERNAME, AT_API_KEY, AT_SENDER_ID\n";
    }

    /** Loads configuration into this request so the rest of installation can use DB:: and Audit::. */
    public static function loadEnv(string $content): void
    {
        foreach (preg_split('/\R/', $content) as $line) {
            if ($line === '' || $line[0] === '#' || !str_contains($line, '=')) {
                continue;
            }
            [$k, $val] = explode('=', $line, 2);
            putenv("$k=$val");
            $_ENV[$k] = $val;
        }
    }

    /** Starter data: wards, institutions, an open cycle, FAQs, mentorship; optionally demo accounts. */
    public static function seed(bool $demo): void
    {
        if ($demo) {
            DB::run("UPDATE settings SET svalue = 'admin' WHERE skey = 'twofa_roles'");
        }
        $year = (int)date('Y');
        DB::tx(function () use ($demo, $year) {
            $wards = [];
            foreach ([['Mutonguni', 'MTG'], ['Kauwi', 'KAU'], ['Matinyani', 'MAT'], ['Kwa Mutonga/Kithumula', 'KMK']] as [$n, $c]) {
                $wards[$c] = DB::insert('wards', ['name' => $n, 'code' => $c]);
            }
        
            $inst = [
                ['Matinyani Secondary School', 'secondary', 'Kitui', 'Equity Bank', 'Kitui', 'Matinyani Secondary School', '0480291234501'],
                ['Mutonguni Secondary School', 'secondary', 'Kitui', 'KCB', 'Kitui', 'Mutonguni Secondary School BOM', '1102345678'],
                ['Kauwi Girls Secondary School', 'secondary', 'Kitui', 'Co-operative Bank', 'Kitui', 'Kauwi Girls Secondary School', '01129876543200'],
                ['Kitui School', 'secondary', 'Kitui', 'KCB', 'Kitui', 'Kitui School', '1100456789'],
                ['St. Angela\'s Mumbuni Girls', 'secondary', 'Machakos', 'Equity Bank', 'Machakos', 'St Angelas Mumbuni Girls', '0600293456789'],
                ['Kitui National Polytechnic', 'tvet', 'Kitui', 'KCB', 'Kitui', 'Kitui National Polytechnic', '1105678901'],
                ['Mutonguni Vocational Training Centre', 'tvet', 'Kitui', 'Equity Bank', 'Kitui', 'Mutonguni VTC', '0480298765400'],
                ['Kenya Medical Training College — Kitui', 'college', 'Kitui', 'KCB', 'Kitui', 'KMTC Kitui Campus', '1107890123'],
                ['Kitui Teachers Training College', 'college', 'Kitui', 'National Bank', 'Kitui', 'Kitui TTC', '01003045678900'],
                ['South Eastern Kenya University', 'university', 'Kitui', 'KCB', 'Kitui', 'South Eastern Kenya University', '1109012345'],
                ['University of Nairobi', 'university', 'Nairobi', 'Standard Chartered', 'Harambee Avenue', 'University of Nairobi', '0102034567890'],
                ['Machakos University', 'university', 'Machakos', 'Equity Bank', 'Machakos', 'Machakos University', '0600291122334'],
                ['Kitui School for the Deaf', 'special', 'Kitui', 'KCB', 'Kitui', 'Kitui School for the Deaf', '1101122334'],
            ];
            foreach ($inst as $i) {
                DB::insert('institutions', array_combine(['name', 'level', 'county', 'bank_name', 'bank_branch', 'account_name', 'account_no'], $i));
            }
        
            $cycle = DB::insert('application_cycles', [
                'name' => "$year Bursary Cycle", 'year' => $year, 'opens_at' => date('Y-m-d H:i:s', strtotime('-20 days')),
                'closes_at' => date('Y-m-d 23:59:59', strtotime('+60 days')), 'status' => 'open',
                'field_verification_rate' => 20, 'secondary_audit_rate' => 10, 'max_applications_per_guardian' => 5,
                'notes' => "Open to needy students whose family lives in Kitui West Constituency and who are enrolled in a recognised secondary school, TVET, college or university.\nPriority is given to orphans, students with disabilities and households with no regular income.\nAwards are paid directly to the institution, never in cash.",
            ]);
            foreach ([['secondary', 5000, 40000], ['tvet', 5000, 35000], ['college', 5000, 40000], ['university', 10000, 50000], ['special', 5000, 60000]] as [$l, $mn, $mx]) {
                DB::insert('cycle_levels', ['cycle_id' => $cycle, 'level' => $l, 'min_amount' => $mn, 'max_amount' => $mx]);
            }
            $dt = array_column(DB::all('SELECT id, code FROM document_types'), 'id', 'code');
            foreach ([['school_id', 'all', 1], ['admission', 'all', 1], ['fee_statement', 'all', 1], ['chief_letter', 'all', 1], ['birth_cert', 'secondary', 1], ['death_cert', 'all', 0], ['other', 'all', 0]] as [$c, $l, $r]) {
                DB::insert('cycle_documents', ['cycle_id' => $cycle, 'document_type_id' => $dt[$c], 'level' => $l, 'is_required' => $r]);
            }
            foreach ($wards as $w) {
                DB::insert('cycle_ward_budgets', ['cycle_id' => $cycle, 'ward_id' => $w, 'amount' => 2500000]);
            }
        
            $faqs = [
                ['Who can apply?', 'Students whose family lives in Kitui West Constituency and who are enrolled in a recognised secondary school, TVET, college or university. The exact rules for each cycle are on the Eligibility page.'],
                ['Does it cost anything to apply?', 'No. Applying is free. Nobody — officer, chief or cyber café — may charge you or ask for anything in return. Report any such request through Report a Concern.'],
                ['Can I apply on my phone?', 'Yes. The form is designed for basic smartphones and slow connections. Your answers save automatically so you can continue later.'],
                ['Why must the chief’s form be printed from this system?', 'Each form carries a unique code and QR that the office checks. Forms typed, edited or made elsewhere fail that check, which protects genuine applicants from forgeries.'],
                ['How is the money paid?', 'Directly to the school, college or university account. Bursaries are never paid in cash or to a parent’s phone.'],
                ['How do I know my letter is genuine?', 'Every official sheet has a verification code and QR. Enter the code at the Verify page (or scan the QR) to see the details held by the office.'],
                ['My child applied last year. Do I start again?', 'No. Choose “Apply again” for that student. Verified details are reused and you only confirm what changed.'],
                ['Can I report corruption without giving my name?', 'Yes. Reports can be anonymous. You receive a tracking reference and PIN to follow up.'],
            ];
            foreach ($faqs as $n => [$q, $a]) {
                DB::insert('faqs', ['question' => $q, 'answer' => $a, 'sort_order' => $n]);
            }
            DB::insert('announcements', ['title' => "$year bursary applications are open", 'body' => "Applications for the $year cycle are now open online. Apply early, upload clear photos of the school ID and fee statement, and print the chief’s recommendation form from the system.\n\nApplying is free. Report anyone asking for money.", 'is_published' => 1, 'published_at' => date('Y-m-d H:i:s', strtotime('-19 days'))]);
        
            $progs = [
                ['career', 'Career pathways clinic', 'Meet professionals from Kitui and beyond and learn how to choose subjects, courses and careers.'],
                ['scholarship', 'KUCCPS, HELB & scholarship guidance', 'Step-by-step help with university and TVET placement, HELB loans and scholarship applications.'],
                ['digital_skills', 'Digital skills bootcamp', 'Practical computer, internet safety and online work skills for students and school leavers.'],
                ['financial_literacy', 'Money smart', 'Budgeting, saving and avoiding debt traps for students and parents.'],
                ['entrepreneurship', 'Youth enterprise lab', 'Turning ideas into small businesses: records, pricing and access to youth funds.'],
                ['leadership', 'Student leadership forum', 'Integrity, public speaking and community service for student leaders.'],
                ['academic', 'Exam readiness sessions', 'Study skills and revision support ahead of national examinations.'],
            ];
            foreach ($progs as $i => [$c, $t, $d]) {
                $pid = DB::insert('mentorship_programs', ['category' => $c, 'title' => $t, 'description' => $d]);
                if ($i < 4) {
                    DB::insert('mentorship_events', ['program_id' => $pid, 'title' => $t . ' — ' . ['Matinyani', 'Kauwi', 'Mutonguni', 'Kithumula'][$i],
                        'venue' => ['Matinyani Social Hall', 'Kauwi Market Grounds Hall', 'Mutonguni Secondary School', 'Kithumula Chief’s Camp'][$i],
                        'starts_at' => date('Y-m-d 10:00:00', strtotime('+' . (10 + $i * 7) . ' days')), 'capacity' => 80]);
                }
            }
        
            if ($demo) {
                $pass = Auth::hashPassword('Demo@2026pass');
                $staff = [
                    ['Grace Mwende (Admin)', '0700000001', ['admin'], null, null],
                    ['Peter Musyoka (Documents)', '0700000002', ['doc_officer'], null, null],
                    ['Ruth Kalekye (Ward – Matinyani)', '0700000003', ['ward_officer'], 'MAT', null],
                    ['Joseph Kioko (Ward – Mutonguni)', '0700000004', ['ward_officer'], 'MTG', null],
                    ['Esther Mutua (Committee)', '0700000005', ['committee'], null, null],
                    ['Daniel Nzioka (Committee)', '0700000006', ['committee'], null, null],
                    ['Mary Wanza (Approver)', '0700000007', ['approver'], null, 60000],
                    ['Samuel Kilonzo (Approver)', '0700000008', ['approver'], null, 150000],
                    ['Faith Ndinda (Finance)', '0700000009', ['finance'], null, null],
                    ['John Mutinda (Finance)', '0700000010', ['finance'], null, null],
                    ['Alice Mbithe (Auditor)', '0700000011', ['auditor'], null, null],
                ];
                foreach ($staff as $i => [$name, $phone, $roles, $ward, $limit]) {
                    $uid = DB::insert('users', ['full_name' => $name, 'phone' => $phone, 'national_id' => (string)(20000000 + $i), 'password_hash' => $pass,
                        'account_type' => 'staff', 'ward_id' => $ward ? $wards[$ward] : null, 'approval_limit' => $limit]);
                    foreach ($roles as $r) {
                        DB::run('INSERT INTO user_roles (user_id, role_id) SELECT ?, id FROM roles WHERE slug = ?', [$uid, $r]);
                    }
                }
                $pid = DB::insert('users', ['full_name' => 'Janet Mueni', 'phone' => '0711000001', 'national_id' => '30111222', 'password_hash' => $pass, 'account_type' => 'parent', 'phone_verified_at' => now()]);
                DB::run("INSERT INTO user_roles (user_id, role_id) SELECT ?, id FROM roles WHERE slug = 'parent'", [$pid]);
            }
            Audit::log('config', 'initial_seed', null, null, ['demo' => $demo ? 'yes' : 'no'], null);
        });
    }
}
