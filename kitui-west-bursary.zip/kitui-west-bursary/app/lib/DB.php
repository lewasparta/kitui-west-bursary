<?php
declare(strict_types=1);

final class DB
{
    private static ?PDO $pdo = null;

    public static function pdo(): PDO
    {
        if (self::$pdo === null) {
            $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
                env('DB_HOST', '127.0.0.1'), env('DB_PORT', '3306'), env('DB_DATABASE', 'kwb'));
            $opts = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_STRINGIFY_FETCHES => false,
            ];
            if ($ca = env('DB_SSL_CA')) {
                $opts[PDO::MYSQL_ATTR_SSL_CA] = $ca;
            }
            self::$pdo = new PDO($dsn, env('DB_USERNAME', 'kwb'), env('DB_PASSWORD', ''), $opts);
            self::$pdo->exec("SET time_zone = '" . (new DateTime())->format('P') . "', sql_mode = 'STRICT_ALL_TABLES,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION'");
        }
        return self::$pdo;
    }

    public static function run(string $sql, array $params = []): PDOStatement
    {
        $st = self::pdo()->prepare($sql);
        $st->execute(array_values($params) === $params ? $params : $params);
        return $st;
    }

    public static function all(string $sql, array $params = []): array
    {
        return self::run($sql, $params)->fetchAll();
    }

    /** Rows as positional arrays (reports: duplicate column names must not collapse). */
    public static function rows(string $sql, array $params = []): array
    {
        return self::run($sql, $params)->fetchAll(PDO::FETCH_NUM);
    }

    public static function one(string $sql, array $params = []): ?array
    {
        $r = self::run($sql, $params)->fetch();
        return $r === false ? null : $r;
    }

    public static function val(string $sql, array $params = []): mixed
    {
        $r = self::run($sql, $params)->fetchColumn();
        return $r === false ? null : $r;
    }

    public static function insert(string $table, array $data): int
    {
        $cols = array_keys($data);
        foreach ($cols as $c) {
            if (!preg_match('/^[a-z_][a-z0-9_]*$/', $c)) {
                throw new InvalidArgumentException('Bad column');
            }
        }
        $sql = 'INSERT INTO `' . $table . '` (`' . implode('`,`', $cols) . '`) VALUES (' . implode(',', array_fill(0, count($cols), '?')) . ')';
        self::run($sql, array_values($data));
        return (int)self::pdo()->lastInsertId();
    }

    public static function update(string $table, array $data, string $where, array $whereParams): int
    {
        $sets = [];
        foreach (array_keys($data) as $c) {
            if (!preg_match('/^[a-z_][a-z0-9_]*$/', $c)) {
                throw new InvalidArgumentException('Bad column');
            }
            $sets[] = "`$c` = ?";
        }
        return self::run('UPDATE `' . $table . '` SET ' . implode(', ', $sets) . ' WHERE ' . $where, array_merge(array_values($data), $whereParams))->rowCount();
    }

    /** Runs $fn inside a transaction; nested calls join the outer transaction. */
    public static function tx(callable $fn): mixed
    {
        $pdo = self::pdo();
        if ($pdo->inTransaction()) {
            return $fn();
        }
        $pdo->beginTransaction();
        try {
            $r = $fn();
            $pdo->commit();
            return $r;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }
}
