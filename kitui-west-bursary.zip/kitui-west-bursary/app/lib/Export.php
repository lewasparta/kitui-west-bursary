<?php
declare(strict_types=1);

/** CSV and Excel (SpreadsheetML, opens natively in Excel/LibreOffice) exports. Every export is audit-logged. */
final class Export
{
    public static function send(string $name, array $headers, array $rows, string $format, bool $sensitive = true): never
    {
        Audit::log('report', 'report_download', 'report', $name, ['format' => $format, 'rows' => count($rows), 'sensitive' => $sensitive ? 'yes' : 'no']);
        $file = preg_replace('/[^a-z0-9_\-]/i', '_', $name) . '_' . date('Ymd_His');
        header('Cache-Control: no-store, private');
        if ($format === 'xls') {
            header('Content-Type: application/vnd.ms-excel');
            header('Content-Disposition: attachment; filename="' . $file . '.xls"');
            echo self::xml($name, $headers, $rows);
            exit;
        }
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $file . '.csv"');
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, $headers);
        foreach ($rows as $r) {
            fputcsv($out, array_map([self::class, 'safeCell'], array_values($r)));
        }
        fclose($out);
        exit;
    }

    /** Prevent spreadsheet formula injection (=, +, -, @ at the start of a cell). */
    public static function safeCell(mixed $v): string
    {
        $v = (string)($v ?? '');
        return ($v !== '' && in_array($v[0], ['=', '+', '-', '@', "\t", "\r"], true) && !is_numeric($v)) ? "'" . $v : $v;
    }

    private static function xml(string $title, array $headers, array $rows): string
    {
        $x = '<?xml version="1.0" encoding="UTF-8"?><?mso-application progid="Excel.Sheet"?>'
            . '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">'
            . '<Styles><Style ss:ID="h"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#0B5132" ss:Pattern="Solid"/></Style></Styles>'
            . '<Worksheet ss:Name="' . e(mb_substr($title, 0, 30)) . '"><Table><Row>';
        foreach ($headers as $h) {
            $x .= '<Cell ss:StyleID="h"><Data ss:Type="String">' . e($h) . '</Data></Cell>';
        }
        $x .= '</Row>';
        foreach ($rows as $r) {
            $x .= '<Row>';
            foreach ($r as $v) {
                $num = is_int($v) || is_float($v) || (is_string($v) && preg_match('/^-?\d+(\.\d+)?$/', $v) && strlen($v) < 12);
                $x .= '<Cell><Data ss:Type="' . ($num ? 'Number' : 'String') . '">' . e($num ? $v : self::safeCell($v)) . '</Data></Cell>';
            }
            $x .= '</Row>';
        }
        return $x . '</Table></Worksheet></Workbook>';
    }
}
