# Kitui West Digital Bursary
**Transparent Support. Brighter Futures.**

A complete bursary and student support platform for Kitui West: online applications, document and field verification, committee review, authorised approval, payment batches with maker-checker, reconciliation, mentorship, anonymous concern reporting, SMS notifications, a public transparency dashboard, and a tamper-evident audit trail.

Built with plain PHP 8.2+ and MySQL 8 or MariaDB 10.4+ (the database that comes with XAMPP), with no framework and no Composer dependencies, so it runs on ordinary hosting and is easy for a county ICT team to maintain.

---

## 1. What is in the box

| Area | Where |
|---|---|
| Public website (Home, About, How it works, Eligibility, Application period, FAQs, Announcements, Transparency, Contact, Report a concern, Verify a document) | `app/controllers/public.php`, `app/views/public/` |
| Family portal: 7-step wizard with autosave, resumable uploads, multiple students, continued support, messages, support history | `app/controllers/applicant.php` |
| Staff workflow: document check, verification, field visits with GPS and homestead photos, committee, approval, amendments, risk flags, secondary audits | `app/controllers/staff.php`, `app/lib/Workflow.php`, `app/lib/Risk.php` |
| Finance: ready for payment, batch, authorise (different officer), paid/failed with bank reference, reconcile | `app/controllers/finance.php` |
| Audit: chain integrity check, full application reconstruction, log search/export, concerns | `app/controllers/audit.php`, `app/lib/Audit.php` |
| Sealed official sheets (receipt, chief recommendation form, award letter, support statement) | `app/lib/Seal.php`, `app/controllers/sheets.php` |
| Reports (Excel/CSV), every download logged | `app/controllers/reports.php` |
| Administration: users/roles/limits, wards, institutions, cycles, amount bands, required documents, budgets, SMS templates, announcements, FAQs, mentorship | `app/controllers/admin.php` |
| Database schema with constraints and protective triggers | `database/schema.sql` |

## 2. Quick start on Windows with XAMPP: three steps

1. Start **Apache** and **MySQL** in the XAMPP Control Panel.
2. Unzip this folder into `C:\xampp\htdocs\`.
3. Open **http://localhost/kitui-west-bursary/** and press **Install now**.

That is all. The installer creates the settings file (`.env`) with new secret keys, creates the database, loads the tables and the Kitui West starter data, and then disappears for good. You don't need phpMyAdmin, a command line, or to edit any files.

- **Demo accounts:** leave "Include demo accounts" ticked to try every role. The password is `Demo@2026pass`, and the logins are listed on the finish screen and in the table below.
- **Database settings:** XAMPP's defaults (user `root`, no password) are already filled in. Change them only if your MySQL has a password.
- **Your own administrator:** optionally, create one on the same screen.
- **If something is wrong:** for example, if MySQL isn't started, the installer says exactly that in plain words.

The folder can have any name. The site also works at the root of a domain and on cPanel hosting, and links and styles adjust automatically. On Windows, back up from phpMyAdmin (**Export**) and copy `storage/private`. The `.sh` backup scripts are for Linux servers.

## 2b. Quick start on Linux (command line)

The browser installer works here too. The manual route is:

```bash
# Requirements: PHP 8.2+ with pdo_mysql, gd, mbstring, curl; MySQL 8.0+ or MariaDB 10.4+
mysql -uroot -e "CREATE DATABASE kwb CHARACTER SET utf8mb4; CREATE USER 'kwb'@'localhost' IDENTIFIED BY 'change-me'; GRANT ALL ON kwb.* TO 'kwb'@'localhost';"
mysql -uroot kwb < database/schema.sql

cp .env.example .env
#   set APP_URL=http://localhost:8000, DB_PASSWORD, and generate two keys:
php -r "echo bin2hex(random_bytes(32)), PHP_EOL;"   # -> APP_KEY
php -r "echo bin2hex(random_bytes(32)), PHP_EOL;"   # -> APP_SEAL_KEY

php scripts/seed.php                 # wards, institutions, open cycle, FAQs, mentorship, demo users
php -S localhost:8000 -t public public/index.php
```

Open http://localhost:8000.

### Demo accounts
All demo accounts use the password `Demo@2026pass`. Log in with the phone number.

| Phone | Role |
|---|---|
| 0700000001 | Administrator (must set up two-step login on first sign-in, e.g. Google Authenticator) |
| 0700000002 | Document officer |
| 0700000003 | Ward officer, Matinyani |
| 0700000004 | Ward officer, Mutonguni |
| 0700000005, 0700000006 | Committee members |
| 0700000007 | Approver, limit KES 60,000 |
| 0700000008 | Approver, limit KES 150,000 |
| 0700000009, 0700000010 | Finance officers (two are needed: one prepares, the other authorises) |
| 0700000011 | Auditor |
| 0711000001 | Parent |

Or register a new parent account from the Login page.

**Walk the full journey:**
1. As a parent: apply for a student in Matinyani ward, print the chief's form, upload documents, and submit.
2. As 0700000002: declare no conflict, verify each document, then pass the document check.
3. As 0700000003: verify, optionally require a field visit (add a photo and GPS), then send to committee.
4. As 0700000005: recommend an amount.
5. As 0700000007: approve.
6. As 0700000009: mark ready for payment and create a batch.
7. As 0700000010: authorise the batch.
8. As 0700000009: record it paid with the bank reference.
9. As 0700000011: reconcile.

The parent receives in-app messages and SMS (see Admin, then SMS log) at each stage and can download the award letter and support statement.

**Do not use the demo data in production.** Run `php scripts/seed.php --no-demo`, then `php scripts/create-admin.php "Full Name" 07XXXXXXXX`.

## 2c. Troubleshooting: error #1813 "Tablespace … exists"

This is a known XAMPP/MariaDB problem, not an error in `schema.sql`. When an earlier import was interrupted or repeated, or after a crash, or when the `mysql\data` folder was copied, MariaDB can leave orphan table files in `C:\xampp\mysql\data\kwb\`. It then refuses to create those tables again. phpMyAdmin shows this as **#1813**; newer MariaDB shows **errno 184 "Tablespace already exists"**.

- **Easiest fix: use the installer.** Open the site and press **Install now**. It notices the leftover files, installs into a clean database (`kwb_2`), writes that name into `.env`, and tells you it did so. Nothing is deleted.
- **If you import by hand in phpMyAdmin:** create a **new, empty** database (for example `kwb2`), import `database/schema.sql` into it once, and set `DB_DATABASE=kwb2` in `.env`.
- **To clear the leftovers (optional):**
  1. In the XAMPP Control Panel, **Stop** MySQL.
  2. Delete the folder `C:\xampp\mysql\data\kwb`. Only do this if it holds nothing you need.
  3. **Start** MySQL again.
- **Avoid it next time:**
  - Import `schema.sql` only once, into an empty database.
  - Always stop MySQL from the Control Panel before shutting down the computer.
  - Never copy the `mysql\data` folder between computers. To move data, use phpMyAdmin **Export / Import**.

## 3. The official sheets: why a cyber-café copy fails

Paper can always be retyped or edited, so the protection is not the paper itself. It is that **every genuine sheet can be checked against the office's records in seconds**:

- Sheets are only issued by the system, only to the logged-in owner, and only at the right stage. For example, the award letter exists only after an authorised approval. No blank forms exist anywhere, so there is nothing to photocopy and fill in.
- Each sheet carries a unique code (`KWV-XXXX-XXXX-XXXX`), a QR code and a seal fingerprint. The seal is an HMAC-SHA256 signature of the sheet's content made with `APP_SEAL_KEY`, which never leaves the server.
- Anyone (a chief, a school bursar, an officer) can scan the QR or enter the code at `/verify`. They see the name, reference, amount and status held by the office. The result is one of: genuine, replaced by a newer version, or not found / altered.
- The database refuses any change to an issued sheet's content (trigger). If an amount is later amended, the old sheet is automatically revoked and shows as superseded.
- The printed design (green and gold guilloche security pattern, watermark, microtext) makes casual photocopy fraud obvious. The verification check is what is decisive.

**Office rule to adopt:** no chief's form, award letter or statement is accepted unless its code verifies. Every check is counted (auditors see the count on each application), and codes that do not exist or fail the seal are logged as security events for the auditor.

## 4. Controls built in (anti-corruption)

- **One person, one step.** Nobody can do two different duties on the same application (document check, verification, committee, approval, payment authorisation, reconciliation). This is checked on every action, not just hidden in menus.
- **No self-dealing.** Officers whose phone or ID number matches the household are blocked from the file.
- **Conflict-of-interest declaration** is required before acting on any application.
- **Approval limits** are set per approver, and **ward budgets** cannot be overspent.
- **Maker-checker** applies to payment batches (enforced by a database CHECK). The payment recorder cannot reconcile their own payment (database CHECK).
- **No payment without confirmation.** An application can never be marked paid without a bank reference, date and officer (database CHECK). A confirmed payment cannot be altered (trigger).
- **Controlled amendments.** Post-approval amount changes need a second approver.
- **Risk detection.** Duplicate birth certificate / UPI, name and date-of-birth matches, identical documents across students, a guardian with many applications, links to staff, fee-balance and age-level anomalies.
- **Random sampling.** A configurable percentage of applications gets field visits and independent secondary audits.
- **Immutable audit trail.** Every action is hash-chained; editing or deleting rows is blocked by triggers, and `/audit` re-verifies the whole chain. Auditors can reconstruct any application: every event, document, view, decision, payment and message.
- **Privacy.** Documents are stored privately and every view is logged. The transparency page publishes only aggregates and hides small groups. Homestead photos are never shown to finance or the public.

## 4b. Security protections and going live

**Before real use, open Administration → Security checklist.** It checks this installation live and says in plain words what to fix. Items marked **Fix now** must be cleared before families use the site; a demo install will show several.

Protections in place:

- **Accounts:**
  - Phone numbers are verified by SMS code at registration.
  - Passwords are hashed with Argon2id.
  - Weak passwords are refused (common words, sequences, the person's own name, phone or ID).
  - Accounts lock for 15 minutes after 5 wrong attempts.
  - Login and password-reset requests are rate-limited per IP and per phone (at most 3 reset SMS per phone per hour).
- **Sessions:**
  - Cookies are HttpOnly and SameSite, and Secure under HTTPS.
  - Session IDs are regenerated at login.
  - Idle sessions end after 30 minutes for staff and 60 for families, and every session ends after 12 hours.
  - A password change or reset signs out every other device.
  - A session cookie replayed from another browser is rejected and logged.
  - Private pages are never cached, which protects shared cyber-café computers.
- **Two-step login:**
  - Always required for administrators.
  - Settings can require it for approvers, finance and auditors. This is on by default for production installs; demo installs require it only for the admin.
  - Authenticator secrets are encrypted (AES-256-GCM).
  - A code cannot be reused.
  - The password-to-code step expires after 5 minutes.
- **Requests:**
  - CSRF tokens on every form.
  - Prepared statements for all SQL.
  - Output escaping in every page.
  - Tampered array inputs are rejected.
  - A strict Content-Security-Policy and frame blocking; the PHP version is not advertised.
  - A forged Host header cannot change links, QR codes or SMS URLs.
- **Documents:**
  - Kept in private storage and checked by content, not by file name.
  - PDFs with scripts are refused; images are re-encoded, which strips hidden data.
  - "Image bombs" are refused.
  - Uploads are limited per application and per day.
  - Every view is logged; documents are served sandboxed and never cached.
- **Data:**
  - SMS logs and exports mask one-time codes and temporary passwords.
  - The transparency page shows aggregates only.
  - The privacy notice follows Kenya's Data Protection Act, 2019 (`/privacy`).
- **Installation:**
  - The installer runs once, then locks.
  - Opened from the internet (rather than on the server itself), it demands a one-time code from `storage/install-code.txt`.
  - Older databases upgrade themselves automatically.

Every protection above is exercised by an automated attack test. It covers forged form tokens, other families' records, role boundaries, session theft, brute force, SMS flooding, code replay, weak passwords, disguised PHP files, scripted PDFs, image bombs, file exposure, headers, the Host header and stored script injection. The latest run had zero failures.

## 5. Production deployment

Recommended: **PHP-FPM server + managed MySQL 8 + private S3-compatible bucket + separate backup location + Africa's Talking SMS + HTTPS.**

1. **Server:** Ubuntu 24.04 with `nginx php8.3-fpm php8.3-mysql php8.3-gd php8.3-mbstring php8.3-curl`.
   - Deploy the code to `/var/www/kwb`.
   - Run `chown -R www-data: /var/www/kwb/storage`.
   - Make `.env` readable only by www-data: `chmod 640 .env`.
2. **Web server:** use `deploy/nginx.conf`. Only `public/` is web-visible.
   - Get a certificate with `certbot --nginx`.
   - Set `APP_URL=https://...`. Secure cookies and HSTS switch on automatically.
   On shared cPanel hosting, upload the whole folder. The included `.htaccess` files route visitors into `public/` and block `app/`, `storage/` and `.env`.
3. **Database:** managed MySQL 8 (or MariaDB 10.4+) with TLS (`DB_SSL_CA`), daily provider snapshots and point-in-time recovery.
   - Load `database/schema.sql` once.
   - The schema uses triggers. On managed MySQL, set the parameter `log_bin_trust_function_creators = 1` if loading or restoring as a non-SUPER user.
4. **Documents:** set `STORAGE_DRIVER=s3` and point it at a **private** bucket (block all public access). Only the app's key should be able to read it.
5. **SMS:**
   - Set `SMS_DRIVER=africastalking` with your username, API key and approved sender ID.
   - Every message is logged under Admin, then SMS log, and templates are editable.
6. **Keys:**
   - Generate `APP_KEY` and `APP_SEAL_KEY` once.
   - Store a copy of `.env` in a sealed, offline place. **Losing `APP_SEAL_KEY` means existing sheets can no longer be verified.**
7. **Cron:** install `deploy/crontab.txt` (hourly cleanup, daily encrypted backup, daily audit-chain check).
8. **First admin:**
   - Run `php scripts/seed.php --no-demo`.
   - Run `php scripts/create-admin.php "Name" 07XXXXXXXX`.
   - Log in, change the password, and set up two-step login.
   - Create staff users (the auditor role must be held by someone independent) and configure the cycle, amount bands, required documents and ward budgets.

## 6. Backups and restore

- **Daily backup:** `scripts/backup.sh` writes an encrypted (AES-256) database dump, plus local documents if you use local storage, and SHA-256 checksums. Retention is 30 days.
  - Put a passphrase in `/etc/kwb-backup.pass` (`chmod 600`).
  - Set `BACKUP_RCLONE_REMOTE` to also copy each backup to a separate account or bucket. Keep at least one copy off the main server.
- **Restore:** `scripts/restore.sh storage/backups/db-XXXX.sql.gz.enc [storage/backups/files-XXXX.tar.gz.enc]`. It asks you to type RESTORE, loads the backup, then verifies the audit chain.
- **Test restores** onto a spare database at least once per cycle.
- **S3 documents:** enable versioning on the bucket and replicate it to a second bucket or region.

## 7. Configuration, not code

- Eligibility levels, minimum and maximum awards, required documents per level, opening and closing dates, field-visit and audit sampling rates, ward budgets, approval limits and SMS wording are all set under **Administration**.
- Every configuration change is audit-logged with its before and after values.

## 8. Languages

- All interface strings pass through `t()` with dictionaries in `lang/en.php` and `lang/sw.php`.
- The Kiswahili switch is in the site footer.
- Extend `lang/sw.php` to translate further screens.

## 9. Honest notes

- **PDF:** official sheets and reports print to PDF from the browser ("Print / Save PDF" button). The layout is designed for A4. Excel and CSV exports are native.
- **OCR is not included.** Officers verify each document by eye. The system never rejects anyone automatically. An OCR service can be added later as an advisory hint only, next to the document review.
- **SMS in testing:** with `SMS_DRIVER=log` messages are recorded but not sent.
- **Two-step login:** mandatory for administrators and recommended for all staff; staff are prompted on their dashboard.

## 10. Checks run before release

The one-click installer was tested from nothing: no `.env`, no database, MariaDB root with an empty password (the XAMPP defaults), under Apache in a subfolder. The whole suite below was then run on the site it produced.

Everything below was run on **both** MySQL 8 and MariaDB 10.11, under PHP's built-in server and under **Apache with the site in a subfolder** (the XAMPP layout), opened both as `/kitui-west-bursary/` and `/kitui-west-bursary/public/`.


- **Automated end-to-end test** of the complete journey:
  - application, uploads and submission;
  - document check, verification, field visit, committee and approval;
  - batch creation, authorisation, payment recording and reconciliation;
  - notifications, sealed sheets and verification.
- **Separation-of-duties refusals:** maker authorising, recorder reconciling, authoriser reconciling.
- **Crawl of every page as the public and all nine roles:** no errors and no dead links.
- **Database protection tests:** audit and event rows cannot be edited, sealed sheets and paid payments cannot be altered.
- **Backup and restore:** encrypted backup restored into an empty database with the audit chain intact.
