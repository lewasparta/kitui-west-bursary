-- =====================================================================
-- KITUI WEST DIGITAL BURSARY — database schema (MySQL 8.0+)
-- "Transparent Support. Brighter Futures."
-- =====================================================================
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------- Reference data -------------------------------------------
CREATE TABLE roles (
  id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(40) NOT NULL UNIQUE,
  name VARCHAR(80) NOT NULL,
  is_staff TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE wards (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL UNIQUE,
  code VARCHAR(10) NOT NULL UNIQUE,
  is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE institutions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  level ENUM('secondary','tvet','college','university','special') NOT NULL,
  county VARCHAR(60) NULL,
  bank_name VARCHAR(80) NULL,
  bank_branch VARCHAR(80) NULL,
  account_name VARCHAR(160) NULL,
  account_no VARCHAR(40) NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_inst (name, level)
) ENGINE=InnoDB;

-- ---------- Users & access -------------------------------------------
CREATE TABLE users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(120) NOT NULL,
  phone VARCHAR(15) NOT NULL UNIQUE,
  email VARCHAR(160) NULL UNIQUE,
  national_id VARCHAR(20) NULL,
  password_hash VARCHAR(255) NOT NULL,
  account_type ENUM('parent','student','staff') NOT NULL,
  ward_id INT UNSIGNED NULL,
  approval_limit DECIMAL(12,2) NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  totp_secret VARCHAR(255) NULL,            -- AES-256-GCM encrypted with a key derived from APP_KEY
  totp_enabled TINYINT(1) NOT NULL DEFAULT 0,
  totp_last_step BIGINT NULL,               -- last accepted code window; blocks code replay
  session_epoch INT UNSIGNED NOT NULL DEFAULT 0, -- bumped on password change/reset: signs out every other device
  phone_verified_at DATETIME NULL,
  password_changed_at DATETIME NULL,
  failed_logins SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  locked_until DATETIME NULL,
  must_change_password TINYINT(1) NOT NULL DEFAULT 0,
  last_login_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_users_ward FOREIGN KEY (ward_id) REFERENCES wards(id),
  CONSTRAINT chk_limit CHECK (approval_limit IS NULL OR approval_limit >= 0)
) ENGINE=InnoDB;

CREATE TABLE user_roles (
  user_id INT UNSIGNED NOT NULL,
  role_id TINYINT UNSIGNED NOT NULL,
  granted_by INT UNSIGNED NULL,
  granted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, role_id),
  CONSTRAINT fk_ur_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_ur_role FOREIGN KEY (role_id) REFERENCES roles(id)
) ENGINE=InnoDB;

CREATE TABLE password_resets (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL UNIQUE,
  expires_at DATETIME NOT NULL,
  used_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_pr_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE rate_limits (
  bucket VARCHAR(120) PRIMARY KEY,
  hits INT UNSIGNED NOT NULL,
  window_start INT UNSIGNED NOT NULL
) ENGINE=InnoDB;

CREATE TABLE settings (
  skey VARCHAR(60) PRIMARY KEY,
  svalue TEXT NOT NULL,
  updated_by INT UNSIGNED NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE sequences (
  name VARCHAR(30) NOT NULL,
  year SMALLINT UNSIGNED NOT NULL,
  value INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (name, year)
) ENGINE=InnoDB;

-- ---------- Cycles & configurable rules ------------------------------
CREATE TABLE application_cycles (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  year SMALLINT UNSIGNED NOT NULL,
  opens_at DATETIME NOT NULL,
  closes_at DATETIME NOT NULL,
  status ENUM('draft','open','closed','archived') NOT NULL DEFAULT 'draft',
  field_verification_rate TINYINT UNSIGNED NOT NULL DEFAULT 20,
  secondary_audit_rate TINYINT UNSIGNED NOT NULL DEFAULT 10,
  max_applications_per_guardian TINYINT UNSIGNED NOT NULL DEFAULT 5,
  notes TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_cycle_dates CHECK (closes_at > opens_at),
  CONSTRAINT chk_rates CHECK (field_verification_rate <= 100 AND secondary_audit_rate <= 100)
) ENGINE=InnoDB;

CREATE TABLE cycle_levels (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  cycle_id INT UNSIGNED NOT NULL,
  level ENUM('secondary','tvet','college','university','special') NOT NULL,
  min_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  max_amount DECIMAL(12,2) NOT NULL,
  is_eligible TINYINT(1) NOT NULL DEFAULT 1,
  UNIQUE KEY uq_cycle_level (cycle_id, level),
  CONSTRAINT fk_cl_cycle FOREIGN KEY (cycle_id) REFERENCES application_cycles(id) ON DELETE CASCADE,
  CONSTRAINT chk_cl_amt CHECK (max_amount >= min_amount AND min_amount >= 0)
) ENGINE=InnoDB;

CREATE TABLE document_types (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(40) NOT NULL UNIQUE,
  name VARCHAR(120) NOT NULL,
  description VARCHAR(255) NULL,
  staff_only TINYINT(1) NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE cycle_documents (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  cycle_id INT UNSIGNED NOT NULL,
  document_type_id INT UNSIGNED NOT NULL,
  level ENUM('all','secondary','tvet','college','university','special') NOT NULL DEFAULT 'all',
  is_required TINYINT(1) NOT NULL DEFAULT 1,
  UNIQUE KEY uq_cd (cycle_id, document_type_id, level),
  CONSTRAINT fk_cd_cycle FOREIGN KEY (cycle_id) REFERENCES application_cycles(id) ON DELETE CASCADE,
  CONSTRAINT fk_cd_type FOREIGN KEY (document_type_id) REFERENCES document_types(id)
) ENGINE=InnoDB;

CREATE TABLE cycle_ward_budgets (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  cycle_id INT UNSIGNED NOT NULL,
  ward_id INT UNSIGNED NOT NULL,
  amount DECIMAL(14,2) NOT NULL,
  UNIQUE KEY uq_budget (cycle_id, ward_id),
  CONSTRAINT fk_b_cycle FOREIGN KEY (cycle_id) REFERENCES application_cycles(id) ON DELETE CASCADE,
  CONSTRAINT fk_b_ward FOREIGN KEY (ward_id) REFERENCES wards(id),
  CONSTRAINT chk_budget CHECK (amount >= 0)
) ENGINE=InnoDB;

-- ---------- People ----------------------------------------------------
CREATE TABLE students (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NULL UNIQUE,
  first_name VARCHAR(60) NOT NULL,
  middle_name VARCHAR(60) NULL,
  last_name VARCHAR(60) NOT NULL,
  gender ENUM('female','male') NOT NULL,
  date_of_birth DATE NOT NULL,
  birth_cert_no VARCHAR(30) NULL,
  upi_no VARCHAR(30) NULL,
  ward_id INT UNSIGNED NOT NULL,
  sub_location VARCHAR(80) NOT NULL,
  village VARCHAR(80) NOT NULL,
  has_disability TINYINT(1) NOT NULL DEFAULT 0,
  created_by INT UNSIGNED NOT NULL,
  verified_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_student_bc (birth_cert_no),
  KEY idx_student_upi (upi_no),
  KEY idx_student_name (last_name, first_name, date_of_birth),
  CONSTRAINT fk_st_user FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_st_ward FOREIGN KEY (ward_id) REFERENCES wards(id),
  CONSTRAINT fk_st_creator FOREIGN KEY (created_by) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE guardians (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NULL,
  full_name VARCHAR(120) NOT NULL,
  phone VARCHAR(15) NOT NULL,
  national_id VARCHAR(20) NULL,
  occupation VARCHAR(80) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_g_phone (phone),
  KEY idx_g_nid (national_id),
  CONSTRAINT fk_g_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE student_guardians (
  student_id INT UNSIGNED NOT NULL,
  guardian_id INT UNSIGNED NOT NULL,
  relationship VARCHAR(40) NOT NULL,
  PRIMARY KEY (student_id, guardian_id),
  CONSTRAINT fk_sg_s FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  CONSTRAINT fk_sg_g FOREIGN KEY (guardian_id) REFERENCES guardians(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- Applications ---------------------------------------------
CREATE TABLE applications (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reference VARCHAR(20) NULL UNIQUE,
  cycle_id INT UNSIGNED NOT NULL,
  applicant_user_id INT UNSIGNED NOT NULL,
  student_id INT UNSIGNED NULL,
  guardian_id INT UNSIGNED NULL,
  guardian_relationship VARCHAR(40) NULL,
  institution_id INT UNSIGNED NULL,
  level ENUM('secondary','tvet','college','university','special') NULL,
  class_year VARCHAR(30) NULL,
  admission_no VARCHAR(40) NULL,
  annual_fees DECIMAL(12,2) NULL,
  fee_balance DECIMAL(12,2) NULL,
  amount_requested DECIMAL(12,2) NULL,
  amount_recommended DECIMAL(12,2) NULL,
  amount_approved DECIMAL(12,2) NULL,
  amount_paid DECIMAL(12,2) NOT NULL DEFAULT 0,
  household_size TINYINT UNSIGNED NULL,
  siblings_in_school TINYINT UNSIGNED NULL,
  parental_status ENUM('both_parents','single_parent','partial_orphan','total_orphan','other') NULL,
  income_band ENUM('none','below_5k','5k_15k','15k_30k','above_30k') NULL,
  special_circumstances TEXT NULL,
  status ENUM('draft','submitted','returned','verification','field_verification','committee_review',
              'recommended','approved','partially_approved','not_approved','ready_for_payment',
              'payment_processing','disbursed','payment_failed','closed','withdrawn') NOT NULL DEFAULT 'draft',
  wizard_step TINYINT UNSIGNED NOT NULL DEFAULT 1,
  draft_data JSON NULL,
  student_access_code CHAR(8) NULL,
  return_reason TEXT NULL,
  field_visit_required TINYINT(1) NOT NULL DEFAULT 0,
  secondary_audit TINYINT(1) NOT NULL DEFAULT 0,
  is_continuation TINYINT(1) NOT NULL DEFAULT 0,
  previous_application_id INT UNSIGNED NULL,
  declaration_at DATETIME NULL,
  declaration_ip VARCHAR(45) NULL,
  submitted_at DATETIME NULL,
  decided_at DATETIME NULL,
  version INT UNSIGNED NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_cycle_student (cycle_id, student_id),
  KEY idx_app_status (status, cycle_id),
  KEY idx_app_user (applicant_user_id),
  CONSTRAINT fk_a_cycle FOREIGN KEY (cycle_id) REFERENCES application_cycles(id),
  CONSTRAINT fk_a_user FOREIGN KEY (applicant_user_id) REFERENCES users(id),
  CONSTRAINT fk_a_student FOREIGN KEY (student_id) REFERENCES students(id),
  CONSTRAINT fk_a_guardian FOREIGN KEY (guardian_id) REFERENCES guardians(id),
  CONSTRAINT fk_a_inst FOREIGN KEY (institution_id) REFERENCES institutions(id),
  CONSTRAINT fk_a_prev FOREIGN KEY (previous_application_id) REFERENCES applications(id),
  CONSTRAINT chk_amounts CHECK (
    (amount_requested IS NULL OR amount_requested >= 0) AND
    (amount_recommended IS NULL OR amount_recommended >= 0) AND
    (amount_approved IS NULL OR amount_approved >= 0) AND amount_paid >= 0)
) ENGINE=InnoDB;

CREATE TABLE application_events (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  application_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NULL,
  duty VARCHAR(30) NOT NULL,
  action VARCHAR(40) NOT NULL,
  from_status VARCHAR(30) NULL,
  to_status VARCHAR(30) NULL,
  comment TEXT NULL,
  visible_to_applicant TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  KEY idx_ev_app (application_id, created_at),
  KEY idx_ev_user_app (user_id, application_id, duty),
  CONSTRAINT fk_ev_app FOREIGN KEY (application_id) REFERENCES applications(id),
  CONSTRAINT fk_ev_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE field_visits (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  application_id INT UNSIGNED NOT NULL,
  officer_id INT UNSIGNED NOT NULL,
  visit_date DATE NOT NULL,
  gps_lat DECIMAL(9,6) NULL,
  gps_lng DECIMAL(9,6) NULL,
  household_observation TEXT NOT NULL,
  findings TEXT NOT NULL,
  outcome ENUM('confirmed','concerns','not_confirmed') NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_fv_app (application_id),
  CONSTRAINT fk_fv_app FOREIGN KEY (application_id) REFERENCES applications(id),
  CONSTRAINT fk_fv_off FOREIGN KEY (officer_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE documents (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  application_id INT UNSIGNED NOT NULL,
  document_type_id INT UNSIGNED NOT NULL,
  field_visit_id INT UNSIGNED NULL,
  storage_driver VARCHAR(10) NOT NULL,
  storage_key VARCHAR(255) NOT NULL,
  original_name VARCHAR(200) NOT NULL,
  mime VARCHAR(80) NOT NULL,
  size_bytes INT UNSIGNED NOT NULL,
  sha256 CHAR(64) NOT NULL,
  status ENUM('pending','verified','rejected','superseded') NOT NULL DEFAULT 'pending',
  rejection_reason VARCHAR(255) NULL,
  uploaded_by INT UNSIGNED NOT NULL,
  verified_by INT UNSIGNED NULL,
  verified_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_doc_app (application_id, document_type_id, status),
  KEY idx_doc_hash (sha256),
  CONSTRAINT fk_d_app FOREIGN KEY (application_id) REFERENCES applications(id),
  CONSTRAINT fk_d_type FOREIGN KEY (document_type_id) REFERENCES document_types(id),
  CONSTRAINT fk_d_fv FOREIGN KEY (field_visit_id) REFERENCES field_visits(id),
  CONSTRAINT fk_d_up FOREIGN KEY (uploaded_by) REFERENCES users(id),
  CONSTRAINT fk_d_ver FOREIGN KEY (verified_by) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE upload_sessions (
  token CHAR(32) PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  application_id INT UNSIGNED NOT NULL,
  document_type_id INT UNSIGNED NOT NULL,
  field_visit_id INT UNSIGNED NULL,
  file_name VARCHAR(200) NOT NULL,
  total_size INT UNSIGNED NOT NULL,
  received INT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_us_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_us_app FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE coi_declarations (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  application_id INT UNSIGNED NOT NULL,
  has_conflict TINYINT(1) NOT NULL,
  details VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_coi (user_id, application_id),
  CONSTRAINT fk_coi_u FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_coi_a FOREIGN KEY (application_id) REFERENCES applications(id)
) ENGINE=InnoDB;

CREATE TABLE risk_flags (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  application_id INT UNSIGNED NOT NULL,
  code VARCHAR(40) NOT NULL,
  severity ENUM('low','medium','high') NOT NULL,
  details VARCHAR(500) NOT NULL,
  status ENUM('open','cleared','confirmed') NOT NULL DEFAULT 'open',
  resolved_by INT UNSIGNED NULL,
  resolution_note VARCHAR(500) NULL,
  resolved_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_flag (application_id, code),
  KEY idx_flag_status (status, severity),
  CONSTRAINT fk_rf_app FOREIGN KEY (application_id) REFERENCES applications(id),
  CONSTRAINT fk_rf_user FOREIGN KEY (resolved_by) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE committee_reviews (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  application_id INT UNSIGNED NOT NULL,
  member_id INT UNSIGNED NOT NULL,
  decision ENUM('recommend','return','not_recommend') NOT NULL,
  recommended_amount DECIMAL(12,2) NULL,
  need_score TINYINT UNSIGNED NULL,
  comment TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_cr_app (application_id),
  CONSTRAINT fk_cr_app FOREIGN KEY (application_id) REFERENCES applications(id),
  CONSTRAINT fk_cr_mem FOREIGN KEY (member_id) REFERENCES users(id),
  CONSTRAINT chk_score CHECK (need_score IS NULL OR need_score BETWEEN 1 AND 10)
) ENGINE=InnoDB;

CREATE TABLE approvals (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  application_id INT UNSIGNED NOT NULL,
  approver_id INT UNSIGNED NOT NULL,
  decision ENUM('approved','partially_approved','not_approved') NOT NULL,
  amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  comment TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_ap_app (application_id),
  CONSTRAINT fk_ap_app FOREIGN KEY (application_id) REFERENCES applications(id),
  CONSTRAINT fk_ap_user FOREIGN KEY (approver_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE amendments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  application_id INT UNSIGNED NOT NULL,
  requested_by INT UNSIGNED NOT NULL,
  old_amount DECIMAL(12,2) NOT NULL,
  new_amount DECIMAL(12,2) NOT NULL,
  reason TEXT NOT NULL,
  status ENUM('pending','confirmed','rejected') NOT NULL DEFAULT 'pending',
  reviewed_by INT UNSIGNED NULL,
  review_note VARCHAR(255) NULL,
  reviewed_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_am_app FOREIGN KEY (application_id) REFERENCES applications(id),
  CONSTRAINT fk_am_req FOREIGN KEY (requested_by) REFERENCES users(id),
  CONSTRAINT fk_am_rev FOREIGN KEY (reviewed_by) REFERENCES users(id),
  CONSTRAINT chk_am CHECK (new_amount >= 0)
) ENGINE=InnoDB;

-- ---------- Finance ---------------------------------------------------
CREATE TABLE payment_batches (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reference VARCHAR(24) NOT NULL UNIQUE,
  cycle_id INT UNSIGNED NOT NULL,
  status ENUM('draft','authorized','processing','completed','cancelled') NOT NULL DEFAULT 'draft',
  total_amount DECIMAL(14,2) NOT NULL DEFAULT 0,
  created_by INT UNSIGNED NOT NULL,
  authorized_by INT UNSIGNED NULL,
  authorized_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_pb_cycle FOREIGN KEY (cycle_id) REFERENCES application_cycles(id),
  CONSTRAINT fk_pb_c FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_pb_a FOREIGN KEY (authorized_by) REFERENCES users(id),
  CONSTRAINT chk_pb_sod CHECK (authorized_by IS NULL OR authorized_by <> created_by)
) ENGINE=InnoDB;

CREATE TABLE payments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  batch_id INT UNSIGNED NOT NULL,
  application_id INT UNSIGNED NOT NULL,
  institution_id INT UNSIGNED NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  status ENUM('queued','processing','paid','failed','removed') NOT NULL DEFAULT 'queued',
  payment_method ENUM('eft','cheque','rtgs') NULL,
  payment_reference VARCHAR(60) NULL,
  paid_on DATE NULL,
  recorded_by INT UNSIGNED NULL,
  recorded_at DATETIME NULL,
  failure_reason VARCHAR(255) NULL,
  reconciliation_status ENUM('unreconciled','reconciled','discrepancy') NOT NULL DEFAULT 'unreconciled',
  reconciled_by INT UNSIGNED NULL,
  reconciled_at DATETIME NULL,
  reconciliation_note VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_pay_app (application_id),
  KEY idx_pay_batch (batch_id, status),
  CONSTRAINT fk_p_batch FOREIGN KEY (batch_id) REFERENCES payment_batches(id),
  CONSTRAINT fk_p_app FOREIGN KEY (application_id) REFERENCES applications(id),
  CONSTRAINT fk_p_inst FOREIGN KEY (institution_id) REFERENCES institutions(id),
  CONSTRAINT fk_p_rec FOREIGN KEY (recorded_by) REFERENCES users(id),
  CONSTRAINT fk_p_recon FOREIGN KEY (reconciled_by) REFERENCES users(id),
  CONSTRAINT chk_paid_has_ref CHECK (status <> 'paid' OR (payment_reference IS NOT NULL AND paid_on IS NOT NULL AND recorded_by IS NOT NULL)),
  CONSTRAINT chk_pay_amt CHECK (amount > 0),
  CONSTRAINT chk_recon_sod CHECK (reconciled_by IS NULL OR recorded_by IS NULL OR reconciled_by <> recorded_by)
) ENGINE=InnoDB;

-- ---------- Official sealed documents (tamper-evident sheets) --------
CREATE TABLE issued_documents (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(24) NOT NULL UNIQUE,
  application_id INT UNSIGNED NOT NULL,
  kind ENUM('application_receipt','recommendation_form','award_letter','support_statement') NOT NULL,
  payload JSON NOT NULL,
  signature CHAR(64) NOT NULL,
  issued_by INT UNSIGNED NULL,
  issued_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  revoked_at DATETIME NULL,
  revoked_reason VARCHAR(255) NULL,
  verify_count INT UNSIGNED NOT NULL DEFAULT 0,
  KEY idx_id_app (application_id, kind),
  CONSTRAINT fk_idoc_app FOREIGN KEY (application_id) REFERENCES applications(id),
  CONSTRAINT fk_idoc_user FOREIGN KEY (issued_by) REFERENCES users(id)
) ENGINE=InnoDB;

-- ---------- Messaging ------------------------------------------------
CREATE TABLE sms_templates (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(40) NOT NULL UNIQUE,
  name VARCHAR(100) NOT NULL,
  body VARCHAR(480) NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE sms_messages (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  phone VARCHAR(15) NOT NULL,
  body VARCHAR(480) NOT NULL,
  template_code VARCHAR(40) NULL,
  application_id INT UNSIGNED NULL,
  status ENUM('queued','sent','failed','logged') NOT NULL DEFAULT 'queued',
  provider_ref VARCHAR(80) NULL,
  error VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  sent_at DATETIME NULL,
  KEY idx_sms_app (application_id),
  KEY idx_sms_status (status),
  CONSTRAINT fk_sms_app FOREIGN KEY (application_id) REFERENCES applications(id)
) ENGINE=InnoDB;

CREATE TABLE notifications (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  title VARCHAR(140) NOT NULL,
  body VARCHAR(600) NOT NULL,
  link VARCHAR(200) NULL,
  read_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_n_user (user_id, read_at),
  CONSTRAINT fk_n_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- Concerns (whistle-blowing) -------------------------------
CREATE TABLE complaints (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reference VARCHAR(20) NOT NULL UNIQUE,
  pin_hash VARCHAR(255) NOT NULL,
  category ENUM('bribery','fraud','forged_documents','favoritism','false_beneficiary',
                'payment_irregularity','officer_misconduct','conflict_of_interest','other') NOT NULL,
  description TEXT NOT NULL,
  is_anonymous TINYINT(1) NOT NULL DEFAULT 1,
  reporter_name VARCHAR(120) NULL,
  reporter_phone VARCHAR(15) NULL,
  related_reference VARCHAR(40) NULL,
  ward_id INT UNSIGNED NULL,
  status ENUM('received','under_review','investigating','resolved','closed') NOT NULL DEFAULT 'received',
  assigned_to INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_c_status (status),
  CONSTRAINT fk_c_ward FOREIGN KEY (ward_id) REFERENCES wards(id),
  CONSTRAINT fk_c_assignee FOREIGN KEY (assigned_to) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE complaint_updates (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  complaint_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NULL,
  note TEXT NOT NULL,
  is_public TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_cu_c FOREIGN KEY (complaint_id) REFERENCES complaints(id),
  CONSTRAINT fk_cu_u FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- ---------- Mentorship -----------------------------------------------
CREATE TABLE mentorship_programs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category ENUM('career','academic','entrepreneurship','digital_skills','financial_literacy','leadership','scholarship') NOT NULL,
  title VARCHAR(140) NOT NULL,
  description TEXT NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE mentorship_events (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  program_id INT UNSIGNED NOT NULL,
  title VARCHAR(140) NOT NULL,
  venue VARCHAR(140) NOT NULL,
  starts_at DATETIME NOT NULL,
  capacity SMALLINT UNSIGNED NOT NULL DEFAULT 50,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  CONSTRAINT fk_me_p FOREIGN KEY (program_id) REFERENCES mentorship_programs(id)
) ENGINE=InnoDB;

CREATE TABLE event_registrations (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  event_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  registered_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  attended TINYINT(1) NULL,
  attendance_marked_by INT UNSIGNED NULL,
  feedback_rating TINYINT UNSIGNED NULL,
  feedback_comment VARCHAR(500) NULL,
  UNIQUE KEY uq_reg (event_id, user_id),
  CONSTRAINT fk_er_e FOREIGN KEY (event_id) REFERENCES mentorship_events(id),
  CONSTRAINT fk_er_u FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_er_m FOREIGN KEY (attendance_marked_by) REFERENCES users(id),
  CONSTRAINT chk_rating CHECK (feedback_rating IS NULL OR feedback_rating BETWEEN 1 AND 5)
) ENGINE=InnoDB;

-- ---------- Public content -------------------------------------------
CREATE TABLE announcements (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(160) NOT NULL,
  body TEXT NOT NULL,
  is_published TINYINT(1) NOT NULL DEFAULT 0,
  notify_sms TINYINT(1) NOT NULL DEFAULT 0,
  published_at DATETIME NULL,
  created_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_ann_u FOREIGN KEY (created_by) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE faqs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  question VARCHAR(255) NOT NULL,
  answer TEXT NOT NULL,
  sort_order SMALLINT NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

-- ---------- Immutable audit trail (hash-chained) ---------------------
CREATE TABLE audit_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NULL,
  category ENUM('workflow','data','security','access','finance','config','report') NOT NULL,
  action VARCHAR(60) NOT NULL,
  entity_type VARCHAR(40) NULL,
  entity_id VARCHAR(40) NULL,
  details JSON NULL,
  ip VARCHAR(45) NULL,
  user_agent VARCHAR(255) NULL,
  prev_hash CHAR(64) NOT NULL,
  hash CHAR(64) NOT NULL,
  created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  KEY idx_al_entity (entity_type, entity_id),
  KEY idx_al_user (user_id, created_at),
  KEY idx_al_cat (category, created_at)
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;

-- Audit and history tables are append-only. Any UPDATE/DELETE is refused by the database itself.
DELIMITER $$
CREATE TRIGGER trg_audit_no_update BEFORE UPDATE ON audit_logs FOR EACH ROW
BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'audit_logs is append-only'; END$$
CREATE TRIGGER trg_audit_no_delete BEFORE DELETE ON audit_logs FOR EACH ROW
BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'audit_logs is append-only'; END$$
CREATE TRIGGER trg_events_no_update BEFORE UPDATE ON application_events FOR EACH ROW
BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'application_events is append-only'; END$$
CREATE TRIGGER trg_events_no_delete BEFORE DELETE ON application_events FOR EACH ROW
BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'application_events is append-only'; END$$
CREATE TRIGGER trg_idoc_no_delete BEFORE DELETE ON issued_documents FOR EACH ROW
BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'issued_documents cannot be deleted; revoke instead'; END$$
CREATE TRIGGER trg_idoc_payload_locked BEFORE UPDATE ON issued_documents FOR EACH ROW
BEGIN
  IF NEW.payload <> OLD.payload OR NEW.signature <> OLD.signature OR NEW.code <> OLD.code THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'issued document content is sealed';
  END IF;
END$$
CREATE TRIGGER trg_pay_paid_locked BEFORE UPDATE ON payments FOR EACH ROW
BEGIN
  IF OLD.status = 'paid' AND (NEW.amount <> OLD.amount OR NEW.payment_reference <> OLD.payment_reference OR NEW.status <> 'paid') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'a confirmed payment cannot be altered';
  END IF;
END$$
DELIMITER ;

-- ---------- Base reference data (required for the system to run) ----
INSERT INTO roles (slug, name, is_staff) VALUES
 ('parent','Parent / Guardian',0),('student','Student',0),
 ('doc_officer','Document Verification Officer',1),('ward_officer','Ward / Field Officer',1),
 ('committee','Committee Member',1),('approver','Approver',1),('finance','Finance Officer',1),
 ('auditor','Auditor',1),('admin','System Administrator',1);

INSERT INTO document_types (code, name, description, staff_only) VALUES
 ('school_id','Student / school ID card','Clear photo of both sides of the current school or college ID',0),
 ('admission','Admission or registration evidence','Admission letter, registration slip or current term report',0),
 ('fee_statement','Fee statement','Official fee statement showing the balance, stamped by the institution',0),
 ('chief_letter','Chief recommendation','The system-issued recommendation form, signed and stamped by the chief or assistant chief',0),
 ('birth_cert','Birth certificate','Student birth certificate',0),
 ('death_cert','Parent death certificate','Required only where one or both parents are deceased',0),
 ('other','Other supporting document','Any other document the officer asks for',0),
 ('homestead_photo','Homestead photo','Taken by an authorised officer during a field visit',1);

INSERT INTO sms_templates (code, name, body) VALUES
 ('submitted','Application submitted','KWB: Application {ref} for {student} has been received. Track it at {url}.'),
 ('returned','More information needed','KWB: Application {ref} needs attention: {reason}. Log in to update it.'),
 ('verification','Verification update','KWB: Application {ref} has passed document checks and is now under verification.'),
 ('approved','Bursary approved','KWB: Congratulations. Application {ref} was approved for KES {amount}. Payment goes directly to {institution}.'),
 ('not_approved','Not approved','KWB: Application {ref} was not approved this cycle. Reason: {reason}. You may apply in a future cycle.'),
 ('paid','Payment made','KWB: KES {amount} for {ref} has been paid to {institution}. Payment ref {payref}.'),
 ('announcement','Announcement','KWB: {title}. Details at {url}.'),
 ('password_reset','Password reset','KWB: Your password reset code is {code}. It expires in 30 minutes. Do not share it.'),
 ('concern','Concern received','KWB: Your concern {ref} has been received. Keep your PIN safe to track it.');

INSERT INTO settings (skey, svalue) VALUES
 ('site_name','Kitui West Digital Bursary'),
 ('contact_phone','+254 700 000 000'),
 ('contact_email','bursary@kituiwest.go.ke'),
 ('office_address','Kitui West NG-CDF Office, Matinyani'),
 ('max_upload_mb','8'),
 ('privacy_threshold','5'),
 ('twofa_roles','admin,approver,finance,auditor'),
 ('schema_version','2');
